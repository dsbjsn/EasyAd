package com.agent.ad;

/**
 * Created on 2021/9/14 11
 * 平台类型
 *
 * @author xjl
 */
public enum AdPlatform {
    CSJ("csj"),
    YLB("ylb"),
    YLH("ylh"),
    SM("sigmob"),
    MT("mintegral"),
    KS("ks"),
    OW("oneway"),
    GM("gm"),
    YKY("yky"),
    UN_KNOW("un_know");

    String platformString = "";

    AdPlatform(String pPlatformString) {
        platformString = pPlatformString;
    }

    public String getPlatformString() {
        return platformString;
    }

    public void setPlatformString(String pPlatformString) {
        platformString = pPlatformString;
    }
}
