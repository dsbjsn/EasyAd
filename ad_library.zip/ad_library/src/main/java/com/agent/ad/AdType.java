package com.agent.ad;

/**
 * Created on 2021/9/14 11
 * 广告类型
 *
 * @author xjl
 */
public enum AdType {
    REWARD("reward", "激励", 1),
    NATIVE("native", "原生", 2),
    BANNER("banner", "横幅", 3),
    SPLASH("splash", "开屏", 4),
    FULL("full", "全屏", 5),
    INTERACTION("interaction", "插屏", 6),
    DRAW("draw", "Draw信息流", 7),
    UN_KNOW("un_know", "未知", 0);

    int id = 0;
    String type = "";
    String name = "";

    /**
     * @param pType 广告类型
     * @param pName 广告类型名称
     * @param pId   广告类型对应的后台id
     */
    AdType(String pType, String pName, int pId) {
        this.type = pType;
        this.name = pName;
        this.id = pId;
    }

    public String getType() {
        return type;
    }

    public void setType(String pType) {
        type = pType;
    }

    public String getName() {
        return name;
    }

    public void setName(String pName) {
        name = pName;
    }

    public int getId() {
        return id;
    }

    public void setId(int pId) {
        id = pId;
    }
}
