package com.agent.ad.csj;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.MainThread;

import com.bytedance.sdk.openadsdk.AdSlot;
import com.bytedance.sdk.openadsdk.TTAdConstant;
import com.bytedance.sdk.openadsdk.TTAdDislike;
import com.bytedance.sdk.openadsdk.TTAdManager;
import com.bytedance.sdk.openadsdk.TTAdNative;
import com.bytedance.sdk.openadsdk.TTAdSdk;
import com.bytedance.sdk.openadsdk.TTFullScreenVideoAd;
import com.bytedance.sdk.openadsdk.TTFullScreenVideoAd.FullScreenVideoAdInteractionListener;
import com.bytedance.sdk.openadsdk.TTNativeExpressAd;
import com.bytedance.sdk.openadsdk.TTRewardVideoAd;
import com.bytedance.sdk.openadsdk.TTSplashAd;
import com.agent.ad.AdConfig;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.AdManager;
import com.agent.ad.utils.DpiUtils;

import java.util.List;

/**
 * 穿山甲广告控制类
 */
public class TTAdControl {
    private static final String TAG = "CSJ";
    private static TTAdControl instance = null;
    //头条广告
    private TTAdNative mTTAdNative;

    private boolean bannerHadReturn = false;
    private TTNativeExpressAd mBannerAd;

    private TTNativeExpressAd mNativeAd;

    private TTNativeExpressAd mInteractionAd;

    private TTAdControl(Context pContext) {
        TTAdManager ttAdManager = TTAdSdk.getAdManager();
        ttAdManager.requestPermissionIfNecessary(pContext);
        mTTAdNative = ttAdManager.createAdNative(pContext);
    }

    //安全线程单例
    public static TTAdControl getInstance() {
        if (instance == null) {
            synchronized (TTAdControl.class) {
                if (instance == null) {
                    instance = new TTAdControl(AdConfig.getInstance().getContext());

                }
            }
        }
        return instance;
    }


    /**
     * 加载穿山甲视频广告
     *
     * @param pAdBean 广告位信息
     */
    public void loadRewardVideoAd(final AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        String adId = pAdBean.getAdId();

        TTAdNative.RewardVideoAdListener listener = new TTAdNative.RewardVideoAdListener() {
            @Override
            public void onError(int i, String s) {
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onRewardVideoAdLoad(TTRewardVideoAd ttRewardVideoAd) {
                TTRewardVideoAd.RewardAdInteractionListener listener = new TTRewardVideoAd.RewardAdInteractionListener() {
                    @Override
                    public void onAdShow() {
                        Log.i(TAG, "reward onAdShow");
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }

                    @Override
                    public void onAdVideoBarClick() {
                        Log.i(TAG, "reward onAdVideoBarClick");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    @Override
                    public void onAdClose() {
                        Log.i(TAG, "reward onAdClose");
                        //关闭后再次加载广告
                        AdManager.getInstance().onAdClosedHandler(pAdBean);
                    }

                    @Override
                    public void onVideoComplete() {
                        Log.i(TAG, "reward onVideoComplete");
                    }

                    @Override
                    public void onVideoError() {
                        Log.e(TAG, "reward onVideoError");
                        AdManager.getInstance().recordIsGetReward(false);
                    }

                    @Override
                    public void onRewardVerify(boolean pB, int pI, String pS, int pI1, String pS1) {
                        Log.i(TAG, "reward onRewardVerify " + pB);
                        AdManager.getInstance().recordIsGetReward(pB);
                    }

                    @Override
                    public void onSkippedVideo() {
                        Log.i(TAG, "reward onSkippedVideo");
                    }
                };
                ttRewardVideoAd.setRewardAdInteractionListener(listener);
                AdManager.getInstance().onAdCacheHandler(ttRewardVideoAd, pAdBean);
            }

            @Override
            public void onRewardVideoCached() {
            }

            @Override
            public void onRewardVideoCached(TTRewardVideoAd pTTRewardVideoAd) {

            }
        };

        //step4:创建广告请求参数AdSlot,具体参数含义参考文档
        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(adId)
                .setExpressViewAcceptedSize(500, 500)
                .setUserID(AdConfig.getInstance().getInstance().getToken())
                .setRewardName("coin")
                .setRewardAmount(1)
                .setExtraParam(AdConfig.getInstance().getInstance().getToken())
                .setMediaExtra(AdConfig.getInstance().getInstance().getToken())
                .setOrientation(TTAdConstant.VERTICAL)
                .build();

        //step5:请求广告
        mTTAdNative.loadRewardVideoAd(adSlot, listener);
    }


    /**
     * 加载穿山甲全屏视频广告
     *
     * @param pAdBean 广告位信息
     */
    public void loadFullVideoAd(final AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "full 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        String adId = pAdBean.getAdId();

        TTAdNative.FullScreenVideoAdListener listener = new TTAdNative.FullScreenVideoAdListener() {
            @Override
            public void onError(int i, String s) {
                Log.e(TAG, "full onError" + i + " | " + s);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onFullScreenVideoAdLoad(TTFullScreenVideoAd pTTFullScreenVideoAd) {
                Log.i(TAG, "full onFullScreenVideoAdLoad");
                AdManager.getInstance().onAdCacheHandler(pTTFullScreenVideoAd, pAdBean);
                pTTFullScreenVideoAd.setFullScreenVideoAdInteractionListener(new FullScreenVideoAdInteractionListener() {
                    @Override
                    public void onAdShow() {
                        Log.i(TAG, "full onAdShow");
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }

                    @Override
                    public void onAdVideoBarClick() {
                        Log.i(TAG, "full onAdVideoBarClick");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    @Override
                    public void onAdClose() {
                        Log.i(TAG, "full onAdClose");
                        AdManager.getInstance().onAdClosedHandler(pAdBean);
                    }

                    @Override
                    public void onVideoComplete() {
                        Log.i(TAG, "full onVideoComplete");
                    }

                    @Override
                    public void onSkippedVideo() {
                        Log.i(TAG, "full onSkippedVideo");
                    }
                });
            }

            @Override
            public void onFullScreenVideoCached() {
                Log.i(TAG, "full onFullScreenVideoCached");
            }

            @Override
            public void onFullScreenVideoCached(TTFullScreenVideoAd pTTFullScreenVideoAd) {

            }
        };


        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(adId)
                .setSupportDeepLink(true)
                .setAdCount(1)
                .setExpressViewAcceptedSize(DpiUtils.getWidth(), DpiUtils.getHeight())
                .build();

        //step5:请求广告
        mTTAdNative.loadFullScreenVideoAd(adSlot, listener);
    }


    /**
     * 销毁banner广告
     */
    public void destroyBanner() {
        if (mBannerAd != null) {
            mBannerAd.destroy();
            mBannerAd = null;
        }
    }

    /**
     * 显示banner广告
     *
     * @param pAdBean 广告信息
     */
    public void showBanner(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "banner 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(pAdBean.getAdId())
                .setExpressViewAcceptedSize(600, 100)
                .setSupportDeepLink(true)
                .setAdCount(3)
                .build();

        bannerHadReturn = false;

        mTTAdNative.loadBannerExpressAd(adSlot, new TTAdNative.NativeExpressAdListener() {
            //请求失败回调
            @Override
            public void onError(int code, String message) {
                Log.e(TAG, "banner onError " + code + " | " + message);
                if (!bannerHadReturn) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    destroyBanner();
                    bannerHadReturn = true;
                }
            }

            @Override
            public void onNativeExpressAdLoad(List<TTNativeExpressAd> pList) {
                Log.i(TAG, "banner onNativeExpressAdLoad");
                if (!bannerHadReturn) {
                    AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                    bannerHadReturn = true;
                }

                mBannerAd = pList.get(0);
                mBannerAd.setSlideIntervalTime(30 * 1000);
                mBannerAd.setExpressInteractionListener(new TTNativeExpressAd.ExpressAdInteractionListener() {
                    @Override
                    public void onAdClicked(View view, int type) {
                        Log.i(TAG, "banner onAdClicked");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    @Override
                    public void onAdShow(View view, int type) {
                        Log.i(TAG, "banner onAdShow");
                    }

                    @Override
                    public void onRenderFail(View view, String msg, int code) {
                        Log.e(TAG, "banner onRenderFail " + code + " | " + msg);
                        AdManager.getInstance().onAdClosedHandler(pAdBean);
                    }

                    @Override
                    public void onRenderSuccess(View view, float width, float height) {
                        Log.i(TAG, "banner onRenderSuccess " + width + " | " + height);
                        if (mBannerAd != null) {
                            ViewGroup lViewGroup = (ViewGroup) mBannerAd.getExpressAdView().getParent();
                            if (lViewGroup != null) {
                                lViewGroup.removeView(mBannerAd.getExpressAdView());
                            }

                            AdManager.getInstance().getBannerRootFl().removeAllViews();
                            FrameLayout.LayoutParams lLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                            lLayoutParams.height = DpiUtils.dipTopx(100);

                            AdManager.getInstance().getBannerRootFl().addView(mBannerAd.getExpressAdView(), lLayoutParams);

                            if (AdManager.getInstance().isShowBanner()) {
                                AdManager.getInstance().getBannerRootFl().setVisibility(View.VISIBLE);
                            } else {
                                AdManager.getInstance().getBannerRootFl().setVisibility(View.GONE);
                            }
                        }
                    }
                });

                mBannerAd.setDislikeCallback(pActivity, new TTAdDislike.DislikeInteractionCallback() {
                    @Override
                    public void onShow() {
                    }

                    @Override
                    public void onSelected(int pI, String pS, boolean pB) {
                        AdManager.getInstance().hideBanner();
                    }

                    @Override
                    public void onCancel() {

                    }
                });
                mBannerAd.render();
            }
        });
    }


    /**
     * 销毁原生广告
     */
    public void destroyNative() {
        if (mNativeAd != null) {
            mNativeAd.destroy();
            mNativeAd = null;
        }
    }

    /**
     * 显示信息流广告
     *
     * @param pAdBean 广告信息
     */
    public void showNative(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "native 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }


        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(pAdBean.getAdId())
                .setSupportDeepLink(true)
                .setAdCount(1)
                .setExpressViewAcceptedSize(0, 300)
                .build();

        mTTAdNative.loadNativeExpressAd(adSlot, new TTAdNative.NativeExpressAdListener() {
            //广告请求失败
            @Override
            public void onError(int code, String message) {
                Log.e(TAG, "native onError " + code + " | " + message);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            //广告请求成功
            @Override
            public void onNativeExpressAdLoad(List<TTNativeExpressAd> ads) {
                Log.i(TAG, "native onNativeExpressAdLoad");
                mNativeAd = ads.get(0);
                mNativeAd.setExpressInteractionListener(new TTNativeExpressAd.ExpressAdInteractionListener() {
                    //广告点击回调
                    @Override
                    public void onAdClicked(View view, int type) {
                        Log.i(TAG, "native onAdClicked");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    //广告展示回调
                    @Override
                    public void onAdShow(View view, int type) {
                        Log.i(TAG, "native onAdShow");
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }

                    //广告渲染失败回调
                    @Override
                    public void onRenderFail(View view, String msg, int code) {
                        Log.e(TAG, "native onRenderFail " + code + " | " + msg);
                        AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    }

                    //广告渲染成功回调
                    @Override
                    public void onRenderSuccess(View view, float width, float height) {
                        Log.e(TAG, "native onRenderSuccess " + width + " | " + height);
                        AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                        AdManager.getInstance().getNativeRootFl().removeAllViews();

                        FrameLayout.LayoutParams lLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                        lLayoutParams.height = DpiUtils.dipTopx(280);

                        AdManager.getInstance().getNativeRootFl().addView(mNativeAd.getExpressAdView(), lLayoutParams);

                        if (AdManager.getInstance().isShowNative()) {
                            AdManager.getInstance().getNativeRootFl().setVisibility(View.VISIBLE);
                        } else {
                            AdManager.getInstance().getNativeRootFl().setVisibility(View.GONE);
                        }
                    }
                });
                mNativeAd.setDislikeCallback(pActivity, new TTAdDislike.DislikeInteractionCallback() {
                    @Override
                    public void onShow() {
                    }

                    @Override
                    public void onSelected(int pI, String pS, boolean pB) {
                        Log.e(TAG, "native dismiss");
                        AdManager.getInstance().hideNative();
                    }

                    @Override
                    public void onCancel() {
                    }
                });
                //渲染广告
                mNativeAd.render();
            }
        });
    }


    /**
     * 显示插屏广告
     *
     * @param pAdBean 广告信息
     */
    public void showInteraction(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "interaction 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(pAdBean.getAdId())
                .setSupportDeepLink(true)
                .setAdCount(1)
                .setExpressViewAcceptedSize(DpiUtils.getDPWidth() - 100, 0)
                .build();

        mTTAdNative.loadInteractionExpressAd(adSlot, new TTAdNative.NativeExpressAdListener() {
            //广告请求失败
            @Override
            public void onError(int code, String message) {
                Log.e(TAG, "interaction onError " + code + " | " + message);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            //广告请求成功
            @Override
            public void onNativeExpressAdLoad(List<TTNativeExpressAd> ads) {
                Log.i(TAG, "interaction onNativeExpressAdLoad");
                AdManager.getInstance().onAdCacheHandler(null, pAdBean);

                mInteractionAd = ads.get(0);
                if (mInteractionAd == null) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    return;
                }

                mInteractionAd.render();
                mInteractionAd.setExpressInteractionListener(new TTNativeExpressAd.AdInteractionListener() {
                    @Override
                    public void onAdDismiss() {
                        Log.i(TAG, "interaction onAdDismiss");
                        AdManager.getInstance().onAdClosedHandler(pAdBean);
                    }

                    @Override
                    public void onAdClicked(View pView, int pI) {
                        Log.i(TAG, "interaction onAdClicked");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    @Override
                    public void onAdShow(View pView, int pI) {
                        Log.i(TAG, "interaction onAdShow");
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }

                    @Override
                    public void onRenderFail(View pView, String msg, int code) {
                        Log.e(TAG, "interaction onRenderFail " + code + " | " + msg);
                        AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    }

                    @Override
                    public void onRenderSuccess(View pView, float width, float height) {
                        Log.e(TAG, "interaction onRenderSuccess " + width + " | " + height);
                        if (mInteractionAd != null && pActivity != null && !pActivity.isDestroyed()) {
                            mInteractionAd.showInteractionExpressAd(pActivity);
                        }
                    }
                });
            }
        });
    }

    boolean hadSkip = false;

    /**
     * 显示开屏广告
     *
     * @param pAdBean 广告位信息
     */
    public void showSplash(AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "splash 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(pAdBean.getAdId())
                .setImageAcceptedSize(1080, 1920)
                .build();

        mTTAdNative.loadSplashAd(adSlot, new TTAdNative.SplashAdListener() {
            //请求广告失败
            @Override
            @MainThread
            public void onError(int code, String message) {
                Log.e(TAG, "splash onError " + code + " | " + message);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            //请求广告超时
            @Override
            @MainThread
            public void onTimeout() {
                Log.e(TAG, "splash onTimeout ");
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            //请求广告成功
            @Override
            @MainThread
            public void onSplashAdLoad(TTSplashAd ad) {
                if (ad == null) {
                    return;
                }

                Log.i(TAG, "splash onSplashAdLoad");

                hadSkip = false;
                AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                //获取SplashView
                View view = ad.getSplashView();
                if (view != null && AdManager.getInstance().getSplashFl() != null) {
                    AdManager.getInstance().getSplashFl().removeAllViews();
                    AdManager.getInstance().getSplashFl().addView(view);
                } else {
                    //开发者处理跳转到APP主页面逻辑
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }

                ad.setSplashInteractionListener(new TTSplashAd.AdInteractionListener() {
                    //点击回调
                    @Override
                    public void onAdClicked(View view, int type) {
                        Log.i(TAG, "splash onAdClicked");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    //展示回调
                    @Override
                    public void onAdShow(View view, int type) {
                        Log.i(TAG, "splash onAdShow");
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }

                    //跳过回调
                    @Override
                    public void onAdSkip() {
                        //开发者处理跳转到APP主页面逻辑
                        Log.i(TAG, "splash onAdSkip");
                        AdManager.getInstance().onAdClosedHandler(pAdBean);
                        hadSkip = true;
                    }

                    //超时倒计时结束
                    @Override
                    public void onAdTimeOver() {
                        //开发者处理跳转到APP主页面逻辑
                        Log.i(TAG, "splash onAdTimeOver");
                        if (!hadSkip) {
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                        }
                    }
                });
            }
        }, 3000);
    }


    /**
     * 加载draw模版渲染广告
     *
     * @param pAdBean 广告位信息
     */
    public void loadDrawAd(final AdInfoEntity.AdBean pAdBean) {
        if (!TTAdMgHolder.hadInit) {
            Log.e(TAG, "draw 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        Log.e(TAG, "showDrawAd 333");

        AdSlot adSlot = new AdSlot.Builder()
                .setCodeId(pAdBean.getAdId())
                .setSupportDeepLink(true)
                .setAdCount(1)
                .setIsAutoPlay(false)
                .setExpressViewAcceptedSize(DpiUtils.getDPWidth(), DpiUtils.getDPHeight())
                .build();

        mTTAdNative.loadExpressDrawFeedAd(adSlot, new TTAdNative.NativeExpressAdListener() {
            @Override
            public void onError(int code, String message) {
                Log.e(TAG, "draw onError " + code + " | " + message);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onNativeExpressAdLoad(List<TTNativeExpressAd> pList) {
                Log.i(TAG, "draw onNativeExpressAdLoad");
                if (pList != null && !pList.isEmpty()) {
                    TTNativeExpressAd mDrawAd = pList.get(0);
                    if (mDrawAd == null) {
                        AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    } else {
                        AdManager.getInstance().onAdCacheHandler(mDrawAd, pAdBean);
                    }
                } else {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }
        });
    }
}
