package com.agent.ad.utils;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2020/12/29 09
 *
 * @author xjl
 */
public class AppUtils {
    /**
     * 判断网络是否连接
     *
     * @param context 上下文
     * @return {@code true}: 是<br>{@code false}: 否
     */
    public static boolean isConnected(Context context) {
        NetworkInfo info = getActiveNetworkInfo(context);
        return info != null && info.isConnected();
    }

    /**
     * 获取活动网络信息
     *
     * @param context 上下文
     * @return NetworkInfo
     */
    private static NetworkInfo getActiveNetworkInfo(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo();
    }


    /**
     * 获取版本号
     *
     * @return 当前应用的版本号
     */
    public static int getVersionCode(Context pContext) {
        try {
            PackageManager manager = pContext.getPackageManager();
            return manager.getPackageInfo(pContext.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 1;
    }

    /**
     * 获取版本名称
     *
     * @return 当前应用的版本名称
     */
    public static String getVersionName(Context pContext) {
        try {
            PackageManager manager = pContext.getPackageManager();
            return manager.getPackageInfo(pContext.getPackageName(), 0).versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }


    public static String UpdateAppName = "hbGame.apk";
    public static long downLoadId;
    public static DownloadManager sDownloadManager;
    public static BroadcastReceiver sReceiver;



    /**
     * 获取应用名称
     *
     * @return
     */
    public static String getAppName(Context pContext) {
        PackageManager packageManager =pContext.getPackageManager();
        ApplicationInfo applicationInfo;
        try {
            applicationInfo = packageManager.getApplicationInfo(pContext.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            applicationInfo = null;
        }
        String applicationName = (String) packageManager.getApplicationLabel(applicationInfo);
        return applicationName;
    }

    /**
     * 获取包信息
     *
     * @param context
     * @return
     */
    public static PackageInfo getAppInfo(Context context) {
        PackageInfo packageInfo = null;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return packageInfo;
    }


    /**
     * 设置全屏
     *
     * @param activity
     */
    public static void fullScreen(Activity activity) {
        Window window = activity.getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //5.x开始需要把颜色设置透明，否则导航栏会呈现系统默认的浅灰色
            View decorView = window.getDecorView();
            //两个 flag 要结合使用，表示让应用的主体内容占用系统状态栏的空间
            int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            decorView.setSystemUiVisibility(option);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        } else {
            WindowManager.LayoutParams attributes = window.getAttributes();
            int flagTranslucentStatus = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
            attributes.flags |= flagTranslucentStatus;
            window.setAttributes(attributes);
        }
    }

    public static void hideStatusBar(Activity pActivity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = pActivity.getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            pActivity.getWindow().setAttributes(lp);
            // 设置页面全屏显示
            final View decorView = pActivity.getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
        pActivity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }


    /**
     * Flag只有在使用了FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
     * <p>
     * 并且没有使用 FLAG_TRANSLUCENT_STATUS的时候才有效，也就是只有在状态栏全透明的时候才有效。
     *
     * @param pActivity
     * @param bDark
     */
    public static void setStatusBarMode(Activity pActivity, boolean bDark) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decorView = pActivity.getWindow().getDecorView();
            if (decorView != null) {
                int vis = decorView.getSystemUiVisibility();
                if (bDark) {
                    vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else {
                    vis &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }
                decorView.setSystemUiVisibility(vis);
            }
        }
    }


    /**
     * 跳转到好评
     *
     * @param pContext
     */
    public static void goodPf(Context pContext) {
        String playPackage = "com.android.vending";
        try {
            String currentPackageName = pContext.getPackageName();
            if (currentPackageName != null) {
                Uri currentPackageUri = Uri.parse("market://details?id=" + pContext.getPackageName());
                Intent intent = new Intent(Intent.ACTION_VIEW, currentPackageUri);
                intent.setPackage(playPackage);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                pContext.startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Uri currentPackageUri = Uri.parse("https://play.google.com/store/apps/details?id=" + pContext.getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, currentPackageUri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            pContext.startActivity(intent);
        }
    }

    public static List<PackageInfo> getInstalledApplications(Context pContext) {
        // 获取到包的管理者
        PackageManager packageManager = pContext.getPackageManager();
        // 获取所有的安装程序
        List<PackageInfo> lInstalledPackages = packageManager.getInstalledPackages(0);
        return lInstalledPackages;
    }

    public static PackageInfo getNewApp(Context pContext) {
        if (oldAppInfoList != null && !oldAppInfoList.isEmpty()) {
            List<PackageInfo> newList = getInstalledApplications(pContext);
            if (newList.size() != oldAppInfoList.size()) {
                List<String> oldPackageList = new ArrayList<>();
                List<String> oldAppNameList = new ArrayList<>();
                for (PackageInfo oldInfo : oldAppInfoList) {
                    String packageName2 = oldInfo.packageName;
                    String appName2 = oldInfo.applicationInfo.loadLabel(pContext.getPackageManager()).toString();

                    oldPackageList.add(packageName2);
                    oldAppNameList.add(appName2);
                }


                for (PackageInfo newInfo : newList) {
                    String packageName = newInfo.packageName;
                    String appName = newInfo.applicationInfo.loadLabel(pContext.getPackageManager()).toString();

                    if (oldPackageList.contains(packageName)) {
                        continue;
                    } else {
                        LogUtil.d("新安装的应用:" + appName);
                        return newInfo;
                    }
                }
            }
        }
        return null;
    }


    public static PackageInfo newApp = null;
    private static List<PackageInfo> oldAppInfoList = new ArrayList<>();

    public static void refreshOldList(Context pContext){
        oldAppInfoList = getInstalledApplications(pContext);
        newApp = null;
    }

    public static void getNewInstallApp(Context pContext) {
        newApp = getNewApp(pContext);
    }


    /**
     * 启动app
     *
     * @param pActivity
     * @param appPackageName 应用包名
     */
    public static void startAPP(Activity pActivity, String appPackageName) {
        try {
            Intent intent = pActivity.getPackageManager().getLaunchIntentForPackage(appPackageName);
            pActivity.startActivity(intent);
        } catch (Exception e) {
            LogUtil.d("没有安装");
        }
    }

    /**
     * 检查是否获得权限
     *
     * @param context
     * @param permission
     * @return
     */
    public static boolean checkPermission(Context context, String permission) {
        boolean result = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Class<?> clazz = Class.forName("android.content.Context");
                Method method = clazz.getMethod("checkSelfPermission", String.class);
                int rest = (Integer) method.invoke(context, permission);
                return rest == PackageManager.PERMISSION_GRANTED;
            } catch (Exception e) {
                result = false;
            }
        } else {
            PackageManager pm = context.getPackageManager();
            if (pm.checkPermission(permission, context.getPackageName()) == PackageManager.PERMISSION_GRANTED) {
                result = true;
            }
        }
        return result;
    }

    /**
     * 从Assets读取文件
     *
     * @param pContext
     * @param fileName
     * @return
     */
    public static String getFileFromAssets(Context pContext, String fileName) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            AssetManager assetManager = pContext.getAssets();
            BufferedReader bf = new BufferedReader(new InputStreamReader(assetManager.open(fileName)));
            String line;
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String fileString = stringBuilder.toString();
        return fileString;
    }

    /**
     * 调用系统分享文本
     *
     * @param context
     * @param sharePath
     */
    public static void systemShareUri(Context context, String sharePath) {
        Intent textIntent = new Intent(Intent.ACTION_SEND);
        textIntent.setType("text/plain");
        textIntent.putExtra(Intent.EXTRA_TEXT, sharePath);
        context.startActivity(Intent.createChooser(textIntent, "分享"));
    }


    /**
     * 从手机剪贴板获取信息
     *
     * @param pContext
     * @return
     */
    public static String getStringFromClipboard(Context pContext) {
        ClipboardManager cm = (ClipboardManager) pContext.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null)
            return null;

        if (cm.hasPrimaryClip()) {
            for (int i = 0; i < cm.getPrimaryClip().getItemCount(); i++) {
                CharSequence content = cm.getPrimaryClip().getItemAt(i).coerceToText(pContext);
                String string = content.toString();
                if (string.contains("hbGame#"))
                    return string;
            }
        }
        return null;
    }


    private static LocationManager sLocationManager;
    private static GetLocationCallBack sGetLocationCallBack;

    public interface GetLocationCallBack {
        void address(String country, String admin, String city, String allAddress);
    }
}
