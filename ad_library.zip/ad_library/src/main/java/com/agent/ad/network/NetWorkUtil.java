package com.agent.ad.network;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.agent.ad.AdAction;
import com.agent.ad.AdConfig;
import com.agent.ad.AdManager;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.entity.AdRewardCallBackEntity;
import com.agent.ad.interfaces.ResultCallBack;
import com.agent.ad.utils.AppUtils;
import com.agent.ad.utils.Base64Util;
import com.agent.ad.utils.DeviceIdUtil;
import com.agent.ad.utils.LogUtil;
import com.agent.ad.utils.MD5;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * @author admin
 */
public class NetWorkUtil {
    private static final int MaxLoadTimes = 5;

    public static String w = "";
    public static String h = "";
    public static String os = "";
    public static String os_ver = "";
    public static String model = "";
    public static String webkit = "";

    private static Map getMap() {
        Map<String, String> lMap = new HashMap<>();
        lMap.put("platform", AdConfig.android);
        lMap.put("app_id", AdConfig.getInstance().getApp_id());
        lMap.put("app_secret", AdConfig.getInstance().getApp_secret());
        lMap.put("version", String.valueOf(AppUtils.getVersionCode(AdConfig.getInstance().getContext())));
        lMap.put("phoneId", DeviceIdUtil.getInstance().getPhoneID());
        lMap.put("phone_model", Build.MODEL);
        lMap.put("system_version", String.valueOf(Build.VERSION.SDK_INT));

        lMap.put("w", w);
        lMap.put("h", h);
        lMap.put("os", os);
        lMap.put("os_ver", os_ver);
        lMap.put("model", model);
        lMap.put("webkit", webkit);
        return lMap;
    }

    /**
     * 获取sign
     *
     * @param pMap
     * @return
     */
    public static String getSign(Map pMap) {
        List<Map.Entry<String, Object>> lList = new ArrayList<Map.Entry<String, Object>>(pMap.entrySet());

        //重写集合的排序方法：按字母顺序
        Collections.sort(lList, (o1, o2) -> (o1.getKey().compareTo(o2.getKey())));

        StringBuilder mapString = new StringBuilder();
        String token = "";
        for (Map.Entry<String, Object> lEntry : lList) {
            if (!lEntry.getKey().equals("token")) {
                LogUtil.d("重新排序：" + lEntry.getKey() + " | " + lEntry.getValue());
                mapString.append(lEntry.getValue());
            } else {
                token = String.valueOf(lEntry.getValue());
            }
        }

        if (!TextUtils.isEmpty(token)) {
            LogUtil.d("重新排序：token | " + token);
            mapString.append(token);
        }

        LogUtil.d("md5加密字段：" + mapString);
        String sign = MD5.md5(mapString.toString());
        LogUtil.d("sign：" + sign);
        return sign;
    }

    /**
     * 接口字段加密
     *
     * @param data
     * @return
     */
    public static String java_openssl_encrypt(String data) {
        try {
            String password = "P^39DPPB@MvKKvrR";
            String keyStr = "1234567891012345";
            byte[] key = new byte[32];
            for (int i = 0; i < 32; i++) {
                if (i < password.getBytes().length) {
                    key[i] = password.getBytes()[i];
                } else {
                    key[i] = 0;
                }
            }

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.getIV();
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(keyStr.getBytes()));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
            } else {
                return Base64Util.encode(cipher.doFinal(data.getBytes()));
            }
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException pE) {
            pE.printStackTrace();
        }
        return null;
    }

    /**
     * map 转成接口字段
     *
     * @param pStringMap
     * @return
     */
    public static String map2String(Map<String, String> pStringMap) {
        StringBuilder lStringBuilder = new StringBuilder();
        if (pStringMap != null) {
            for (String key : pStringMap.keySet()) {
                lStringBuilder.append(key).append("=").append(pStringMap.get(key)).append("&");
            }
        }
        String ls = lStringBuilder.toString().substring(0, lStringBuilder.length() - 1);
        Log.d("map2String -->", ls);
        return ls;
    }

    public static RequestBody getBody(String lData) {
        return RequestBody.create(okhttp3.MediaType.parse("application/x-www-form-urlencoded;charset=UTF-8"), lData);
    }

    public static RequestBody getBody(Map lData) {
        return RequestBody.create(okhttp3.MediaType.parse("application/x-www-form-urlencoded;charset=UTF-8"), map2String(lData));
    }


    /**
     * 向服务器上报广告事件
     *
     * @param pAdBean   广告信息
     * @param pAdAction 广告行为
     */
    public static void sendADEvent(AdInfoEntity.AdBean pAdBean, AdAction pAdAction) {
        if (pAdBean == null) {
            LogUtil.e("上报广告事件失败：上报信息为空");
            return;
        }

        if (TextUtils.isEmpty(AdConfig.getInstance().getRootPath())) {
            LogUtil.e("上报广告事件失败：服务器域名未配置");
            return;
        }


        Map<String, String> lMap = getMap();
        lMap.put("adId", pAdBean.getAdId());
        lMap.put("ecpm", String.valueOf(pAdBean.getPrice()));
        lMap.put("t", String.valueOf(pAdBean.getTypeId()));
        lMap.put("p", String.valueOf(pAdBean.getPlatformId()));

        lMap.put("a", pAdAction.getAction());

        lMap.put("uid", AdConfig.getInstance().getUid());
        lMap.put("app_id", AdConfig.getInstance().getApp_id());
        lMap.put("app_secret", AdConfig.getInstance().getApp_secret());
        lMap.put("phoneId", DeviceIdUtil.getInstance().getPhoneID());
        lMap.put("version", String.valueOf(AppUtils.getVersionCode(AdConfig.getInstance().getContext())));

        LogUtil.d("api postADEvent params:" + map2String(lMap));

        String string = java_openssl_encrypt(map2String(lMap));
        Map<String, String> lStringMap = new HashMap<>();
        lStringMap.put("d", string);

        StringBuilder lStringBuilder = new StringBuilder();
        lStringBuilder.append("api 广告事件上报：")
                .append(" 平台：").append(pAdBean.getPlatform())
                .append(" | 类型：").append(pAdBean.getType().getName())
                .append(" | 行为：").append(pAdAction.getName())
                .append(" | adId：").append(pAdBean.getAdId())
                .append(" | ecpm：").append(pAdBean.getPrice());
        LogUtil.d(lStringBuilder);

        Retrofit retrofit = new Retrofit.Builder()
                .client(AdConfig.getInstance().getHttpClient())
                .baseUrl(AdConfig.getInstance().getRootPath())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        NetApi lNetApi = retrofit.create(NetApi.class);
        Call<String> lCall = lNetApi.postAdEvent(lStringMap);
        lCall.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
            }
        });
    }


    /**
     * 当前加载广告配置文件次数
     */
    private static int loadAdJsonTimes = 0;

    /**
     * 获取服务器广告配置文件
     */
    public static void getAdJson(String path) {
        if (TextUtils.isEmpty(path)) {
            LogUtil.e("获取服务器广告配置文件失败：文件路径未配置");
            return;
        }

        if (TextUtils.isEmpty(AdConfig.getInstance().getRootPath())) {
            LogUtil.e("获取服务器广告配置文件失败：服务器域名未配置");
            return;
        }

        loadAdJsonTimes++;
        Retrofit retrofit = new Retrofit.Builder()
                .client(AdConfig.getInstance().getHttpClient())
                .baseUrl(AdConfig.getInstance().getRootPath())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        NetApi lNetApi = retrofit.create(NetApi.class);
        Call<ResponseBody> lCall = lNetApi.getAdJson(AdConfig.getInstance().getAdInfoJsonPath());
        lCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String data = response.body().string();
                        AdInfoEntity lAdInfoEntity = new Gson().fromJson(data, AdInfoEntity.class);
                        AdManager.getInstance().setAdInfo(lAdInfoEntity);
                    } catch (IOException pE) {
                        pE.printStackTrace();
                        AdManager.getInstance().loadLocalAdInfo();
                    }
                } else {
                    if (loadAdJsonTimes <= MaxLoadTimes) {
                        getAdJson(path);
                    } else {
                        AdManager.getInstance().loadLocalAdInfo();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if (loadAdJsonTimes <= MaxLoadTimes) {
                    getAdJson(path);
                } else {
                    AdManager.getInstance().loadLocalAdInfo();
                }
            }
        });
    }

    /**
     * 模拟广告回调
     */
    public static void getRewardAdIsValid(AdInfoEntity.AdBean pAdBean, ResultCallBack pResultCallBack) {
        if (pAdBean == null) {
            LogUtil.e("模拟广告回调失败：广告信息为空");
            return;
        }

        if (TextUtils.isEmpty(AdConfig.getInstance().getRootPath())) {
            LogUtil.e("模拟广告回调失败：服务器域名未配置");
            return;
        }

        Map<String, String> lMap = getMap();
        lMap.put("t_", String.valueOf(System.currentTimeMillis() / 1000));
        lMap.put("p", String.valueOf(pAdBean.getPlatformId()));
        lMap.put("t", String.valueOf(pAdBean.getTypeId()));
        lMap.put("ad_id", pAdBean.getAdId());
        lMap.put("token", AdConfig.getInstance().getToken());

        Retrofit retrofit = new Retrofit.Builder()
                .client(AdConfig.getInstance().getHttpClient())
                .baseUrl(AdConfig.getInstance().getRootPath())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        NetApi lNetApi = retrofit.create(NetApi.class);


        Call<AdRewardCallBackEntity> lCall = lNetApi.rewardCallBack(lMap);
        lCall.enqueue(new Callback<AdRewardCallBackEntity>() {
            @Override
            public void onResponse(Call<AdRewardCallBackEntity> call, Response<AdRewardCallBackEntity> response) {
                if (response.isSuccessful() && response.body() != null) {
                    if (pResultCallBack != null) {
                        if (response.body().isIsValid() != null && response.body().isIsValid()) {
                            pResultCallBack.success();
                        } else {
                            pResultCallBack.fail("");
                        }
                    }
                } else {
                    if (pResultCallBack != null) {
                        pResultCallBack.fail("");
                    }
                }
            }

            @Override
            public void onFailure(Call<AdRewardCallBackEntity> call, Throwable t) {
                if (pResultCallBack != null) {
                    pResultCallBack.fail("");
                }
            }
        });
    }
}
