package com.agent.ad.interfaces;

/**
 * Created on 2021/5/14 16
 *
 * @author xjl
 */
public interface ResultCallBack {
    void success();
    void fail(String msg);
}
