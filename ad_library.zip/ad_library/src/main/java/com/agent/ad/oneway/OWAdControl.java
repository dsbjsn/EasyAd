package com.agent.ad.oneway;

import android.app.Activity;
import android.util.Log;

import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.AdManager;

import mobi.oneway.export.Ad.OWInterstitialAd;
import mobi.oneway.export.Ad.OWRewardedAd;
import mobi.oneway.export.AdListener.OWInterstitialAdListener;
import mobi.oneway.export.AdListener.OWRewardedAdListener;
import mobi.oneway.export.enums.OnewayAdCloseType;
import mobi.oneway.export.enums.OnewaySdkError;

/**
 * Created on 2021/4/23 09
 *
 * @author xjl
 */
public class OWAdControl {
    private static final String TAG = "oneway";
    private volatile static OWAdControl instance = null;

    private OWAdControl() {
    }

    //安全线程单例
    public static OWAdControl getInstance() {
        if (instance == null) {
            synchronized (OWAdControl.class) {
                if (instance == null) {
                    instance = new OWAdControl();
                }
            }
        }
        return instance;
    }

    private OWRewardedAd mOWRewardedAd;

    public void loadRewardVideoAd(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!OWAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        mOWRewardedAd = new OWRewardedAd(pActivity, pAdBean.getAdId(), new OWRewardedAdListener() {
            @Override
            public void onAdReady() {
                Log.i(TAG, "onAdReady");
                 AdManager.getInstance().onAdCacheHandler(mOWRewardedAd, pAdBean);
            }

            @Override
            public void onAdShow(String pS) {
                Log.i(TAG, "onAdShow:" + pS);
                 AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onAdClick(String pS) {
                Log.i(TAG, "onAdClick:" + pS);
                 AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onAdClose(String pS, OnewayAdCloseType pOnewayAdCloseType) {
                Log.i(TAG, "onAdClose:" + pS);
                 AdManager.getInstance().onAdClosedHandler(pAdBean);
                 AdManager.getInstance().recordIsGetReward(true, false);
            }

            @Override
            public void onAdFinish(String pS, OnewayAdCloseType pOnewayAdCloseType, String pS1) {
                Log.i(TAG, "onAdFinish:" + pS);
            }

            @Override
            public void onSdkError(OnewaySdkError pOnewaySdkError, String pS) {
                Log.i(TAG, "onSdkError:" + pS + " | " + pOnewaySdkError.toString());
                 AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        });

        mOWRewardedAd.loadAd();
    }

    private OWInterstitialAd mOWInterstitialAd;

    public void loadFullVideoAd(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!OWAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        mOWInterstitialAd = new OWInterstitialAd(pActivity, pAdBean.getAdId(), new OWInterstitialAdListener() {
            @Override
            public void onAdReady() {
                Log.i(TAG, "full onAdReady");
                 AdManager.getInstance().onAdCacheHandler(mOWInterstitialAd, pAdBean);
            }

            @Override
            public void onAdShow(String pS) {
                Log.i(TAG, "full onAdShow:" + pS);
                 AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onAdClick(String pS) {
                Log.i(TAG, "full onAdClick:" + pS);
                 AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onAdClose(String pS, OnewayAdCloseType pOnewayAdCloseType) {
                Log.i(TAG, "full onAdClose:" + pS);
                 AdManager.getInstance().onAdClosedHandler(pAdBean);
                 AdManager.getInstance().recordIsGetReward(true, false);
            }

            @Override
            public void onAdFinish(String pS, OnewayAdCloseType pOnewayAdCloseType, String pS1) {
                Log.i(TAG, "full onAdFinish:" + pS);
            }

            @Override
            public void onSdkError(OnewaySdkError pOnewaySdkError, String pS) {
                Log.i(TAG, "full onSdkError:" + pS + " | " + pOnewaySdkError.toString());
                 AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        });

        mOWInterstitialAd.loadAd();
    }
}
