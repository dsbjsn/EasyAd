package com.agent.ad;

/**
 * Created on 2021/9/14 11
 *
 * @author xjl
 */
public enum AdAction {
    AD_ACTION_REQ("req", "请求"),
    AD_ACTION_REVEAL("reveal", "展示"),
    AD_ACTION_CLICK("click", "点击"),
    AD_ACTION_RETURN("return_num", "返回"),
    UN_KNOW("un_know", "未知");

    String action = "";
    String name = "";

    /**
     * @param pAction     事件类型
     * @param pActionName 事件类型名称
     */
    AdAction(String pAction, String pActionName) {
        this.action = pAction;
        this.name = pActionName;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String pAction) {
        action = pAction;
    }

    public String getName() {
        return name;
    }

    public void setName(String pName) {
        name = pName;
    }
}
