package com.agent.ad.sigmob;

import android.app.Activity;
import android.text.TextUtils;

import com.sigmob.windad.WindAdOptions;
import com.sigmob.windad.WindAds;
import com.agent.ad.utils.LogUtil;

public class SIGAdMgHolder {
    private static String AppId_SIG;
    private static String AppKey_SIG;
    public static boolean hadInit = false;

    public static WindAds getInstance() {
        return WindAds.sharedAds();
    }

    public static void init(Activity pActivity, String app_id, String app_key) {
        AppId_SIG = app_id;
        AppKey_SIG = app_key;

        if (TextUtils.isEmpty(AppId_SIG) || TextUtils.isEmpty(AppKey_SIG)) {
            LogUtil.e("自定义中介 sigmob 初始化失败，app id 为空");
        } else {
            doInit(pActivity);
        }
    }

    private static void doInit(Activity pActivity) {
        if (pActivity == null) {
            return;
        }

        hadInit = true;
        WindAds ads = WindAds.sharedAds();
        ads.startWithOptions(pActivity, new WindAdOptions(AppId_SIG, AppKey_SIG, false));
        LogUtil.i("自定义中介 sigmob 初始化");
    }
}
