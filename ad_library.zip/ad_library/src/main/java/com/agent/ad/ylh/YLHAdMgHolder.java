package com.agent.ad.ylh;

import android.content.Context;
import android.text.TextUtils;

import com.qq.e.ads.cfg.MultiProcessFlag;
import com.qq.e.comm.managers.GDTADManager;
import com.agent.ad.utils.LogUtil;

public class YLHAdMgHolder {
    private static String AppId_GDT;
    public static boolean hadInit = false;

    public static void init(Context context, String app_id) {
        AppId_GDT = app_id;
        if (TextUtils.isEmpty(AppId_GDT)) {
            LogUtil.e("自定义中介 ylh 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        MultiProcessFlag.setMultiProcess(true);
        GDTADManager.getInstance().initWith(context, AppId_GDT);
        LogUtil.i("自定义中介 ylh 初始化");
    }
}
