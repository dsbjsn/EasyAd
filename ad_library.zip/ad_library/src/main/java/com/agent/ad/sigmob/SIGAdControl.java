package com.agent.ad.sigmob;

import android.app.Activity;
import android.util.Log;

import com.sigmob.windad.Splash.WindSplashAD;
import com.sigmob.windad.Splash.WindSplashADListener;
import com.sigmob.windad.Splash.WindSplashAdRequest;
import com.sigmob.windad.WindAdError;
import com.sigmob.windad.interstitial.WindInterstitialAd;
import com.sigmob.windad.interstitial.WindInterstitialAdListener;
import com.sigmob.windad.interstitial.WindInterstitialAdRequest;
import com.sigmob.windad.rewardedVideo.WindRewardAdRequest;
import com.sigmob.windad.rewardedVideo.WindRewardInfo;
import com.sigmob.windad.rewardedVideo.WindRewardedVideoAd;
import com.sigmob.windad.rewardedVideo.WindRewardedVideoAdListener;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.AdManager;
import com.agent.ad.ylb.YLBAdControl;

public class SIGAdControl {
    private static final String TAG = "Sigmob";
    private volatile static SIGAdControl instance = null;

    //安全线程单例
    public static SIGAdControl getInstance() {
        if (instance == null) {
            synchronized (YLBAdControl.class) {
                if (instance == null) {
                    instance = new SIGAdControl();
                }
            }
        }
        return instance;
    }

    //加载激励视频
    public void loadRewardVideoAd(Activity pActivity, final AdInfoEntity.AdBean pAdBean) {
        if (!SIGAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        String adId = pAdBean.getAdId();
        WindRewardAdRequest lWindRewardAdRequest= new WindRewardAdRequest(adId, null, null);
        WindRewardedVideoAd windRewardedVideoAd =new WindRewardedVideoAd(pActivity,lWindRewardAdRequest);
        WindRewardedVideoAdListener listener = new WindRewardedVideoAdListener() {
            @Override
            public void onVideoAdLoadSuccess(String s) {
                Log.i(TAG, "reward onVideoAdLoadSuccess " + s);
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdCacheHandler(windRewardedVideoAd, lAdBean);
                }
            }

            @Override
            public void onVideoAdPreLoadSuccess(String s) {
                Log.i(TAG, "reward onVideoAdPreLoadSuccess " + s);
            }

            @Override
            public void onVideoAdPreLoadFail(String s) {
                Log.i(TAG, "reward onVideoAdPreLoadFail " + s);
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdLoadFailHandler(lAdBean);
                }
            }

            @Override
            public void onVideoAdPlayStart(String s) {
                Log.i(TAG, "reward onVideoAdPlayStart " + s);
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdShowHandler(lAdBean);
                }

            }

            @Override
            public void onVideoAdPlayEnd(String s) {
                Log.i(TAG, "reward onVideoAdPlayEnd " + s);
            }

            @Override
            public void onVideoAdClicked(String s) {
                Log.i(TAG, "reward onVideoAdClicked " + s);
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdClickHandler(lAdBean);
                }
            }

            @Override
            public void onVideoAdClosed(WindRewardInfo windRewardInfo, String s) {
                Log.i(TAG, "reward onVideoAdClosed " + s + " | " + windRewardInfo);
                 AdManager.getInstance().recordIsGetReward(true);
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdClosedHandler(lAdBean);
                }
            }

            @Override
            public void onVideoAdLoadError(WindAdError windAdError, String s) {
                Log.e(TAG, "reward onVideoAdLoadError " + s + " | " + windAdError.getErrorCode());
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdLoadFailHandler(lAdBean);
                }
            }

            @Override
            public void onVideoAdPlayError(WindAdError windAdError, String s) {
                Log.e(TAG, "reward onVideoAdPlayError " + s + " | " + windAdError.getErrorCode() + " | " + windAdError.getMessage());
                Log.e(TAG, "reward onVideoAdPlayError " + pAdBean.toString());
                 AdManager.getInstance().recordIsGetReward(false);
                AdInfoEntity.AdBean lAdBean =  AdManager.getInstance().getBeanFormId(s);
                if (lAdBean != null) {
                     AdManager.getInstance().onAdClosedHandler(lAdBean);
                }
            }
        };
        windRewardedVideoAd.setWindRewardedVideoAdListener(listener);
        windRewardedVideoAd.loadAd();
    }

    public void loadFullVideoAd(Activity pActivity, final AdInfoEntity.AdBean pAdBean) {
        if (!SIGAdMgHolder.hadInit) {
            Log.e(TAG, "full 平台未初始化");
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        WindInterstitialAdRequest request = new WindInterstitialAdRequest(pAdBean.getAdId(), null, null);
        WindInterstitialAd windInterstitialAd =new WindInterstitialAd(pActivity, request);

        windInterstitialAd.loadAd();
        windInterstitialAd.setWindInterstitialAdListener(new WindInterstitialAdListener() {
            //仅sigmob渠道有回调，聚合其他平台无次回调
            @Override
            public void onInterstitialAdPreLoadSuccess(String placementId) {
                Log.i(TAG, "full onInterstitialAdPreLoadSuccess " + placementId);
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdCacheHandler(windInterstitialAd, pAdBean);
                }
            }

            @Override
            public void onInterstitialAdPreLoadFail(String placementId) {
                Log.i(TAG, "full onInterstitialAdPreLoadFail " + placementId);
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }

            @Override
            public void onInterstitialAdLoadSuccess(String placementId) {
                Log.i(TAG, "full onInterstitialAdLoadSuccess " + placementId);
            }

            @Override
            public void onInterstitialAdPlayStart(String placementId) {
                Log.i(TAG, "full onInterstitialAdPlayStart " + placementId);
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdShowHandler(pAdBean);
                }
            }

            @Override
            public void onInterstitialAdPlayEnd(final String placementId) {
                Log.i(TAG, "full onInterstitialAdPlayEnd " + placementId);
            }

            @Override
            public void onInterstitialAdClicked(String placementId) {
                Log.i(TAG, "full onInterstitialAdClicked " + placementId);
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdClickHandler(pAdBean);
                }
            }

            @Override
            public void onInterstitialAdClosed(String placementId) {
                Log.i(TAG, "full onInterstitialAdClosed " + placementId);
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdClosedHandler(pAdBean);
                }
            }

            /**
             * 加载广告错误回调
             * WindAdError 插屏错误内容
             * placementId 广告位
             */
            @Override
            public void onInterstitialAdLoadError(WindAdError windAdError, String placementId) {
                Log.e(TAG, "full onInterstitialAdLoadError " + placementId + " | " + windAdError.getErrorCode() + " | " + windAdError.getMessage());
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }

            /**
             * 播放错误回调
             * WindAdError 插屏错误内容
             * placementId 广告位
             */
            @Override
            public void onInterstitialAdPlayError(WindAdError windAdError, String placementId) {
                Log.e(TAG, "full onInterstitialAdPlayError " + placementId + " | " + windAdError.getErrorCode() + " | " + windAdError.getMessage());
//                AdInfoEntity.AdBean lAdBean =  AdConfigManager.getInstance().getFullBeanFormId(placementId);
                if (pAdBean != null) {
                     AdManager.getInstance().onAdClosedHandler(pAdBean);
                }
            }
        });
    }

    public void showSplash(Activity pActivity, final AdInfoEntity.AdBean pAdBean) {
        if (!SIGAdMgHolder.hadInit) {
            Log.e(TAG, "splash 平台未初始化");
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
             AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        WindSplashAdRequest request = new WindSplashAdRequest(pAdBean.getAdId(), null, null);
        request.setDisableAutoHideAd(false);
        request.setFetchDelay(5);
        WindSplashAD lWindSplashAD = new WindSplashAD(pActivity, request, new WindSplashADListener() {
            @Override
            public void onSplashAdSuccessPresent() {
                Log.i(TAG, "splash onSplashAdSuccessPresent");
                 AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                 AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onSplashAdSuccessLoad() {
                Log.i(TAG, "splash onSplashAdSuccessLoad");
            }

            @Override
            public void onSplashAdFailToLoad(WindAdError pWindAdError, String pS) {
                Log.i(TAG, "splash onSplashAdFailToLoad");
                 AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onSplashAdClicked() {
                Log.i(TAG, "splash onSplashAdClicked");
                 AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onSplashClosed() {
                Log.i(TAG, "splash onSplashClosed");
                 AdManager.getInstance().onAdClosedHandler(pAdBean);
            }
        });
        lWindSplashAD.loadAdAndShow(null);
    }
}
