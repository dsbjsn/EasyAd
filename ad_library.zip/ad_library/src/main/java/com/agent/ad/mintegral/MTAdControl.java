package com.agent.ad.mintegral;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.mbridge.msdk.MBridgeConstans;
import com.mbridge.msdk.interstitialvideo.out.InterstitialVideoListener;
import com.mbridge.msdk.interstitialvideo.out.MBInterstitialVideoHandler;
import com.mbridge.msdk.out.BannerAdListener;
import com.mbridge.msdk.out.BannerSize;
import com.mbridge.msdk.out.MBBannerView;
import com.mbridge.msdk.out.MBRewardVideoHandler;
import com.mbridge.msdk.out.MBSplashHandler;
import com.mbridge.msdk.out.MBSplashLoadListener;
import com.mbridge.msdk.out.MBSplashShowListener;
import com.mbridge.msdk.out.RewardVideoListener;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.AdManager;
import com.agent.ad.utils.DpiUtils;

public class MTAdControl {
    private static final String TAG = "mintegral";
    private volatile static MTAdControl instance = null;

    private boolean bannerHadReturn = false;
    private MBBannerView mbBannerView;

    private MTAdControl() {
    }

    //安全线程单例
    public static MTAdControl getInstance() {
        if (instance == null) {
            synchronized (MTAdControl.class) {
                if (instance == null) {
                    instance = new MTAdControl();
                }
            }
        }
        return instance;
    }

    /**
     * 加载激励视频广告
     */
    public void loadRewardVideoAd(Context pContext, final AdInfoEntity.AdBean pAdBean) {
        if (!MTAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        MBRewardVideoHandler lMBRewardVideoHandler = new MBRewardVideoHandler(pContext, pAdBean.getAdGroupId(), pAdBean.getAdId());
        lMBRewardVideoHandler.setRewardVideoListener(new RewardVideoListener() {
            String ownerUnitId = "";

            @Override
            public void onLoadSuccess(String placementId, String unitId) {
                Log.i(TAG, "reward onLoadSuccess:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
                this.ownerUnitId = unitId;
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getBeanFormId(unitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdCacheHandler(lMBRewardVideoHandler, lAdBean);
                }
            }

            @Override
            public void onVideoLoadSuccess(String placementId, String unitId) {
                Log.i(TAG, "reward onVideoLoadSuccess:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
            }

            @Override
            public void onVideoLoadFail(String errorMsg) {
                Log.e(TAG, "reward onVideoLoadFail:" + errorMsg);
                if (pAdBean != null) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }

            @Override
            public void onShowFail(String errorMsg) {
                Log.e(TAG, "reward onShowFail:" + errorMsg);
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getBeanFormId(ownerUnitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdClosedHandler(lAdBean);
                }
            }

            @Override
            public void onAdShow() {
                Log.i(TAG, "reward onAdShow");
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getBeanFormId(ownerUnitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdShowHandler(lAdBean);
                }
            }

            @Override
            public void onAdClose(boolean isCompleteView, String RewardName, float RewardAmout) {
                Log.i(TAG, "reward onAdClose rewardinfo:" + "RewardName:" + RewardName + "RewardAmout:" + RewardAmout + " isCompleteView：" + isCompleteView);
                AdManager.getInstance().recordIsGetReward(isCompleteView);

                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getBeanFormId(ownerUnitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdClosedHandler(lAdBean);
                }
            }

            @Override
            public void onVideoAdClicked(String placementId, String unitId) {
                Log.i(TAG, "reward onVideoAdClicked:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getBeanFormId(placementId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdClickHandler(lAdBean);
                }
            }

            @Override
            public void onVideoComplete(String placementId, String unitId) {
                Log.i(TAG, "reward onVideoComplete:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
            }

            @Override
            public void onEndcardShow(String placementId, String unitId) {
                Log.i(TAG, "reward onEndcardShow:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
            }
        });

        lMBRewardVideoHandler.load();
    }


    /**
     * 加载全屏视频
     *
     * @param pContext
     * @param pAdBean
     */
    public void loadFullVideoAd(Context pContext, AdInfoEntity.AdBean pAdBean) {
        if (!MTAdMgHolder.hadInit) {
            Log.e(TAG, "full 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        MBInterstitialVideoHandler lMBInterstitialHandler = new MBInterstitialVideoHandler(pContext, pAdBean.getAdGroupId(), pAdBean.getAdId());
        lMBInterstitialHandler.setInterstitialVideoListener(new InterstitialVideoListener() {
            String ownerUnitId = "";

            @Override
            public void onLoadSuccess(String placementId, String unitId) {
                Log.i(TAG, "full onLoadSuccess: " + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
                this.ownerUnitId = unitId;
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getFullBeanFormId(unitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdCacheHandler(lMBInterstitialHandler, lAdBean);
                }
            }

            @Override
            public void onVideoLoadSuccess(String placementId, String unitId) {
                Log.i(TAG, "full onVideoLoadSuccess:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
            }

            @Override
            public void onVideoLoadFail(String errorMsg) {
                Log.e(TAG, "full onVideoLoadFail:" + errorMsg);
                if (pAdBean != null) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }

            @Override
            public void onAdShow() {
                Log.i(TAG, "full onAdShow");
                if (pAdBean != null) {
                    AdManager.getInstance().onAdShowHandler(pAdBean);
                }
            }

            @Override
            public void onAdClose(boolean pB) {
                Log.i(TAG, "full onAdClose:" + pB);
                if (pAdBean != null) {
                    AdManager.getInstance().onAdClosedHandler(pAdBean);
                }
            }

            @Override
            public void onShowFail(String unitId) {
                Log.e(TAG, "full onShowFail:" + unitId);
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getFullBeanFormId(unitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdClosedHandler(lAdBean);
                }
            }

            @Override
            public void onVideoAdClicked(String placementId, String unitId) {
                Log.e(TAG, "full onVideoAdClicked:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
                AdInfoEntity.AdBean lAdBean = AdManager.getInstance().getFullBeanFormId(unitId);
                if (lAdBean != null) {
                    AdManager.getInstance().onAdClickHandler(lAdBean);
                }
            }

            @Override
            public void onVideoComplete(String placementId, String unitId) {
                Log.e(TAG, "full onVideoComplete:" + (TextUtils.isEmpty(placementId) ? "" : placementId) + "  " + unitId);
            }

            @Override
            public void onAdCloseWithIVReward(boolean pB, int pI) {
            }

            @Override
            public void onEndcardShow(String pS, String pS1) {
            }
        });
        lMBInterstitialHandler.playVideoMute(MBridgeConstans.REWARD_VIDEO_PLAY_NOT_MUTE);
        lMBInterstitialHandler.setIVRewardEnable(MBridgeConstans.IVREWARD_TYPE_CLOSEMODE, 15);
        lMBInterstitialHandler.load();
    }


    public void destroyBanner() {
        if (mbBannerView != null) {
            mbBannerView = null;
        }
    }

    /**
     * 显示banner
     *
     * @param pContext
     * @param pAdBean  banner广告信息
     */
    public void showBanner(Context pContext, AdInfoEntity.AdBean pAdBean) {
        if (!MTAdMgHolder.hadInit) {
            Log.e(TAG, "banner 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        bannerHadReturn = false;
        mbBannerView = new MBBannerView(pContext);
        mbBannerView.init(new BannerSize(BannerSize.DEV_SET_TYPE, DpiUtils.getWidth(), DpiUtils.dipTopx(100)), pAdBean.getAdGroupId(), pAdBean.getAdId());
        mbBannerView.setAllowShowCloseBtn(false);
        mbBannerView.setRefreshTime(15);
        mbBannerView.setBannerAdListener(new BannerAdListener() {
            @Override
            public void onLoadFailed(String msg) {
                Log.e(TAG, "banner onLoadFailed:" + msg);
                if (!bannerHadReturn) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    destroyBanner();
                    bannerHadReturn = true;
                }
            }

            @Override
            public void onLoadSuccessed() {
                Log.i(TAG, "banner onLoadSuccessed");
                if (!bannerHadReturn) {
                    AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                    bannerHadReturn = true;
                }

                if (mbBannerView == null) {
                    return;
                }

                ViewGroup lViewGroup = (ViewGroup) mbBannerView.getParent();
                if (lViewGroup != null) {
                    lViewGroup.removeView(mbBannerView);
                }

                if (AdManager.getInstance().getBannerRootFl() != null) {
                    AdManager.getInstance().getBannerRootFl().removeAllViews();

                    FrameLayout.LayoutParams lLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    lLayoutParams.height = DpiUtils.dipTopx(100);

                    AdManager.getInstance().getBannerRootFl().addView(mbBannerView, lLayoutParams);

                    if (AdManager.getInstance().isShowBanner()) {
                        AdManager.getInstance().getBannerRootFl().setVisibility(View.VISIBLE);
                    } else {
                        AdManager.getInstance().getBannerRootFl().setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onClick() {
                Log.i(TAG, "onAdClick");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onLeaveApp() {
                Log.i(TAG, "leave app");
            }

            @Override
            public void showFullScreen() {
                Log.i(TAG, "showFullScreen");
            }

            @Override
            public void closeFullScreen() {
                Log.i(TAG, "closeFullScreen");
            }

            @Override
            public void onLogImpression() {
                Log.i(TAG, "onLogImpression");
            }

            @Override
            public void onCloseBanner() {
                Log.i(TAG, "onCloseBanner");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }
        });
        mbBannerView.load();
    }

    /**
     * 显示开屏广告
     *
     * @param pContext
     * @param pAdBean
     */
    boolean isSuccess = false;

    public void showSplash(AdInfoEntity.AdBean pAdBean) {
        if (!MTAdMgHolder.hadInit) {
            Log.e(TAG, "splash 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        MBSplashHandler mbSplashHandler = new MBSplashHandler(pAdBean.getAdGroupId(), pAdBean.getAdId());
        mbSplashHandler.setLoadTimeOut(3000);
        mbSplashHandler.setSplashLoadListener(new MBSplashLoadListener() {
            @Override
            public void onLoadSuccessed(int reqType) {
                Log.i(TAG, "splash LoadSuccessed:" + reqType);
                isSuccess = true;
                AdManager.getInstance().onAdCacheHandler(null, pAdBean);

                if (mbSplashHandler.isReady() && AdManager.getInstance().getSplashFl() != null) {
                    mbSplashHandler.onResume();
                    mbSplashHandler.show(AdManager.getInstance().getSplashFl());
                } else {
                    if (AdManager.getInstance().getSplashFl() != null) {
                        Handler lHandler = new Handler();
                        Runnable lRunnable = new Runnable() {
                            @Override
                            public void run() {
                                if (mbSplashHandler.isReady()) {
                                    mbSplashHandler.onResume();
                                    mbSplashHandler.show(AdManager.getInstance().getSplashFl());
                                } else {
                                    lHandler.postDelayed(this, 500);
                                }
                            }
                        };
                        lHandler.postDelayed(lRunnable, 500);
                    }
                }
            }

            @Override
            public void onLoadFailed(String msg, int reqType) {
                Log.e(TAG, "splash onLoadFailed:" + msg + " | " + reqType);
                if (reqType != 0) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }
        });

        mbSplashHandler.setSplashShowListener(new MBSplashShowListener() {
            @Override
            public void onShowSuccessed() {
                Log.i(TAG, "splash onShowSuccessed");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onShowFailed(String msg) {
                Log.i(TAG, "splash onShowFailed:" + msg);
            }

            @Override
            public void onAdClicked() {
                Log.i(TAG, "splash onAdClicked");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onDismiss(int type) {
                Log.i(TAG, "splash onDismiss:" + type);
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onAdTick(long millisUntilFinished) {
                Log.i(TAG, "splash onAdTick:" + millisUntilFinished);
            }
        });

        AdManager.getInstance().getSplashFl().removeAllViews();
        mbSplashHandler.loadAndShow(AdManager.getInstance().getSplashFl());
    }
}
