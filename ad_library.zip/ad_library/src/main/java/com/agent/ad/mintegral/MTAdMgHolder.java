package com.agent.ad.mintegral;

import android.content.Context;
import android.text.TextUtils;

import com.mbridge.msdk.MBridgeConstans;
import com.mbridge.msdk.MBridgeSDK;
import com.mbridge.msdk.out.MBridgeSDKFactory;
import com.agent.ad.utils.LogUtil;

import java.util.Map;

public class MTAdMgHolder {
    private static String AppId;
    private static String AppKey;
    public static boolean hadInit = false;

    public static MBridgeSDK getInstance() {
        return MBridgeSDKFactory.getMBridgeSDK();
    }

    public static void init(Context context, String app_id, String app_key) {
        AppId = app_id;
        AppKey = app_key;
        if (TextUtils.isEmpty(AppId) || TextUtils.isEmpty(AppKey)) {
            LogUtil.e("自定义中介 mt 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        MBridgeSDK sdk = MBridgeSDKFactory.getMBridgeSDK();
        Map<String, String> map = sdk.getMBConfigurationMap(AppId, AppKey);
        sdk.setConsentStatus(context, MBridgeConstans.IS_SWITCH_ON);
        sdk.init(map, context);
        LogUtil.i("自定义中介 mt 初始化");
    }
}