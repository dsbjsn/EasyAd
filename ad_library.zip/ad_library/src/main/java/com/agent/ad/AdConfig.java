package com.agent.ad;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;


import com.agent.ad.interfaces.ResultCallBack;
import com.agent.ad.network.MyHttpLoggingInterceptor;
import com.agent.ad.network.NetWorkUtil;
import com.agent.ad.utils.SharedPreferencesUtil;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

/**
 * Created on 2021/7/22 10
 * 需要的一些信息
 *
 * @author xjl
 */
public class AdConfig {
    private static final AdConfig sAdConfig = new AdConfig();

    private AdConfig() {
    }

    public static AdConfig getInstance() {
        return sAdConfig;
    }

    public static final String android = "1";

    private AppCompatActivity mActivity;
    /**
     * 是否是测试模式
     */
    private boolean test = false;
    /**
     * 应用id
     */
    private String app_id = "";
    /**
     * 应用密钥
     */
    private String app_secret = "";
    /**
     * 后台获取token
     */
    private String token = "";
    /**
     * 用户id
     */
    private String uid = "";
    /**
     * 广告事件上报的后台地址
     */
    private String rootPath = "";
    /**
     * 广告json获取地址
     */
    private String adInfoJsonPath = "";
    /**
     * 广告本地json获取地址
     */
    private String localAdInfoJsonPath = "";
    /**
     * 激励视频是否需要回调验证
     */
    private boolean rewardNeedVerify = false;


    private ResultCallBack resultCallBack;

    private OkHttpClient mHttpClient;

    public Context getContext() {
        return mActivity.getApplicationContext();
    }

    public AppCompatActivity getActivity() {
        return mActivity;
    }

    public boolean isTest() {
        return test;
    }

    public String getApp_id() {
        return app_id;
    }

    public String getApp_secret() {
        return app_secret;
    }

    public String getToken() {
        return token;
    }

    public String getUid() {
        return uid;
    }

    public String getRootPath() {
        return rootPath;
    }

    public OkHttpClient getHttpClient() {
        return mHttpClient;
    }

    public String getAdInfoJsonPath() {
        return adInfoJsonPath;
    }

    public String getLocalAdInfoJsonPath() {
        return localAdInfoJsonPath;
    }

    public boolean isRewardNeedVerify() {
        return rewardNeedVerify;
    }

    public ResultCallBack getResultCallBack() {
        return resultCallBack;
    }


    public static Builder Builder = new Builder();

    public static class Builder {
        private AppCompatActivity activity;

        private boolean test = false;

        private String app_id = "";
        private String app_secret = "";

        private String token = "";
        private String uid = "";

        private String rootPath = "";
        private String adInfoJsonPath = "";
        private String localAdInfoJsonPath = "";

        private boolean rewardNeedVerify = false;

        private ResultCallBack mResultCallBack = null;

        public Builder with(AppCompatActivity pActivity) {
            this.activity = pActivity;
            return this;
        }

        /**
         * 是否是调试模式
         *
         * @param pTest
         * @return
         */
        public Builder isTest(boolean pTest) {
            this.test = pTest;
            return this;
        }

        /**
         * 设置应用信息
         *
         * @param pAppId
         * @param pAppSecret
         * @return
         */
        public Builder setAppInfo(String pAppId, String pAppSecret) {
            this.app_id = pAppId;
            this.app_secret = pAppSecret;
            return this;
        }

        /**
         * 设置用户信息，上报事件需要
         *
         * @param pToken
         * @param pUid
         * @return
         */
        public Builder setUserInfo(String pToken, String pUid) {
            this.token = pToken;
            this.uid = pUid;
            return this;
        }


        /**
         * 设置后台域名，请求广告和上报广告事件
         *
         * @param pRootPath
         * @return
         */
        public Builder setRootPath(String pRootPath) {
            this.rootPath = pRootPath;
            return this;
        }

        /**
         * 设置广告文件获取路径路径
         *
         * @param pNetInfoJsonPath     后台获取地址
         * @param pLocalAdInfoJsonPath 本地获取路径
         * @return
         */
        public Builder setAdInfoPath(String pNetInfoJsonPath, String pLocalAdInfoJsonPath) {
            this.adInfoJsonPath = pNetInfoJsonPath;
            this.localAdInfoJsonPath = pLocalAdInfoJsonPath;
            return this;
        }

        /**
         * 设置激励视频广告是否需要服务器验证
         *
         * @param pRewardNeedVerify
         * @return
         */
        public Builder isRewardNeedVerify(boolean pRewardNeedVerify) {
            this.rewardNeedVerify = pRewardNeedVerify;
            return this;
        }

        /**
         * 初始化完成回调
         *
         * @param pCallBack
         * @return
         */
        public Builder addCallBack(ResultCallBack pCallBack) {
            this.mResultCallBack = pCallBack;
            return this;
        }

        public void init() {
            sAdConfig.mActivity = this.activity;
            sAdConfig.test = this.test;
            sAdConfig.app_id = this.app_id;
            sAdConfig.app_secret = this.app_secret;
            sAdConfig.uid = this.uid;
            sAdConfig.token = this.token;
            sAdConfig.rootPath = this.rootPath;
            sAdConfig.adInfoJsonPath = this.adInfoJsonPath;
            sAdConfig.localAdInfoJsonPath = this.localAdInfoJsonPath;
            sAdConfig.rewardNeedVerify = this.rewardNeedVerify;
            sAdConfig.resultCallBack = this.mResultCallBack;

            MyHttpLoggingInterceptor loggingInterceptor = new MyHttpLoggingInterceptor(message -> Log.i("api message", message));
            OkHttpClient lClient = new OkHttpClient.Builder()
                    .addInterceptor(loggingInterceptor)
                    .connectTimeout(5, TimeUnit.SECONDS)
                    .readTimeout(5, TimeUnit.SECONDS)
                    .writeTimeout(5, TimeUnit.SECONDS)
                    .build();

            sAdConfig.mHttpClient = lClient;

            SharedPreferencesUtil.init(activity, "ad_tool", Context.MODE_PRIVATE);
            if (!TextUtils.isEmpty(rootPath) && !TextUtils.isEmpty(adInfoJsonPath)) {
                NetWorkUtil.getAdJson(adInfoJsonPath);
            } else if (!TextUtils.isEmpty(localAdInfoJsonPath)) {
                AdManager.getInstance().loadLocalAdInfo();
            } else {
                if (sAdConfig.resultCallBack != null) {
                    sAdConfig.resultCallBack.fail("未找到任何广告json文件");
                }
            }
        }
    }
}
