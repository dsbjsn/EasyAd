package com.agent.ad.ylh;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.qq.e.ads.banner2.UnifiedBannerADListener;
import com.qq.e.ads.banner2.UnifiedBannerView;
import com.qq.e.ads.cfg.VideoOption;
import com.qq.e.ads.interstitial3.ExpressInterstitialAD;
import com.qq.e.ads.interstitial3.ExpressInterstitialAdListener;
import com.qq.e.ads.nativ.MediaView;
import com.qq.e.ads.nativ.NativeADEventListenerWithClickInfo;
import com.qq.e.ads.nativ.NativeADUnifiedListener;
import com.qq.e.ads.nativ.NativeUnifiedAD;
import com.qq.e.ads.nativ.NativeUnifiedADData;
import com.qq.e.ads.nativ.express2.VideoOption2;
import com.qq.e.ads.nativ.widget.NativeAdContainer;
import com.qq.e.ads.rewardvideo.RewardVideoAD;
import com.qq.e.ads.rewardvideo.RewardVideoADListener;
import com.qq.e.ads.rewardvideo.ServerSideVerificationOptions;
import com.qq.e.ads.splash.SplashAD;
import com.qq.e.ads.splash.SplashADListener;
import com.qq.e.comm.constants.AdPatternType;
import com.qq.e.comm.util.AdError;
import com.agent.ad.AdConfig;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.utils.LogUtil;
import com.agent.adlibrary.R;
import com.agent.ad.AdManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.qq.e.comm.constants.AdPatternType.NATIVE_2IMAGE_2TEXT;
import static com.qq.e.comm.constants.AdPatternType.NATIVE_3IMAGE;

public class YLHAdControl {
    private static final String TAG = "YLH";
    private volatile static YLHAdControl instance = null;

    private YLHAdControl() {
    }

    //安全线程单例
    public static YLHAdControl getInstance() {
        if (instance == null) {
            synchronized (YLHAdControl.class) {
                if (instance == null) {
                    instance = new YLHAdControl();
                }
            }
        }
        return instance;
    }

    public Map<String, RewardVideoAD> mADMap = new HashMap<>();
    public Map<String, ExpressInterstitialAD> mFullADMap = new HashMap<>();

    /**
     * 加载优量汇激励视频
     */
    public void loadRewardVideoAd(final AdInfoEntity.AdBean pAdBean) {
        if (!YLHAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (mADMap.containsKey(pAdBean.getAdId())) {
            mADMap.remove(pAdBean.getAdId());
        }

        String adId = pAdBean.getAdId();
        //初始化激励视频广告
        RewardVideoADListener listener = new RewardVideoADListener() {
            @Override
            public void onADLoad() {
                Log.i(TAG, "reward onAdLoaded");
                RewardVideoAD mGDTRewardVideoAd = mADMap.get(pAdBean.getAdId());
                if (mGDTRewardVideoAd != null) {
                    AdManager.getInstance().onAdCacheHandler(mGDTRewardVideoAd, pAdBean);
                } else {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }

            @Override
            public void onVideoCached() {
                Log.i(TAG, "reward onVideoCached");
            }

            @Override
            public void onADShow() {
                Log.i(TAG, "reward onShow");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onADExpose() {
                Log.i(TAG, "reward onExpose");
            }


            @Override
            public void onReward(Map<String, Object> map) {
                Log.i(TAG, "reward onReward");
                AdManager.getInstance().recordIsGetReward(true);
            }

            @Override
            public void onADClick() {
                Log.i(TAG, "reward onClick");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onVideoComplete() {
                Log.i(TAG, "reward onVideoComplete");
            }

            @Override
            public void onADClose() {
                Log.i(TAG, "reward onClose");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onError(AdError adError) {
                String msg = String.format(Locale.getDefault(), "onError, error code: %d, error msg: %s", adError.getErrorCode(), adError.getErrorMsg());
                Log.e(TAG, "reward onError  " + msg);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        };

        RewardVideoAD mGDTRewardVideoAd = new RewardVideoAD(AdConfig.getInstance().getActivity(), adId, listener);

        mADMap.put(pAdBean.getAdId(), mGDTRewardVideoAd);

        ServerSideVerificationOptions lServerSideVerificationOptions = new ServerSideVerificationOptions.Builder()
                .setCustomData(AdConfig.getInstance().getToken())
                .setUserId(AdConfig.getInstance().getToken())
                .build();

        mGDTRewardVideoAd.setServerSideVerificationOptions(lServerSideVerificationOptions);
        mGDTRewardVideoAd.loadAD();
    }

    private boolean bannerHadReturn = false;
    private UnifiedBannerView mBannerView;

    public void destroyBanner() {
        if (mBannerView != null) {
            mBannerView.destroy();
            mBannerView = null;
        }
    }

    /**
     * banner广告
     *
     * @param pAdBean
     */
    public void showBanner(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YLHAdMgHolder.hadInit) {
            Log.e(TAG, "banner 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        bannerHadReturn = false;
        mBannerView = new UnifiedBannerView(pActivity, pAdBean.getAdId(), new UnifiedBannerADListener() {
            @Override
            public void onNoAD(AdError pAdError) {
                Log.e(TAG, "banner onNoAD  " + pAdError.getErrorCode() + " | " + pAdError.getErrorMsg());
                if (!bannerHadReturn) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    destroyBanner();
                    bannerHadReturn = true;
                }
            }

            @Override
            public void onADReceive() {
                Log.i(TAG, "banner onADReceive");
                if (AdManager.getInstance().getBannerRootFl() != null) {
                    if (mBannerView != null && mBannerView.getParent() == null) {
                        if (!bannerHadReturn) {
                            AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                            bannerHadReturn = true;
                        }

                        ViewGroup lViewGroup = (ViewGroup) mBannerView.getParent();
                        if (lViewGroup != null) {
                            lViewGroup.removeView(mBannerView);
                        }

                        AdManager.getInstance().getBannerRootFl().removeAllViews();
                        AdManager.getInstance().getBannerRootFl().addView(mBannerView);
                    }

                    if (AdManager.getInstance().isShowBanner()) {
                        AdManager.getInstance().getBannerRootFl().setVisibility(View.VISIBLE);
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }
                }
            }

            @Override
            public void onADExposure() {
                Log.i(TAG, "banner onADExposure");
            }

            @Override
            public void onADClosed() {
                Log.i(TAG, "banner onADClosed");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onADClicked() {
                Log.i(TAG, "banner onADClicked");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onADLeftApplication() {
                Log.i(TAG, "banner onADLeftApplication");
            }

            @Override
            public void onADOpenOverlay() {
                LogUtil.d("onADOpenOverlay");
            }

            @Override
            public void onADCloseOverlay() {
                LogUtil.d("onADCloseOverlay");
            }
        });

        mBannerView.loadAD();
    }

    /**
     * 显示原生广告
     *
     * @param pAdBean
     */
    public void showNative(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YLHAdMgHolder.hadInit) {
            Log.e(TAG, "native 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        NativeUnifiedAD mAdManager = new NativeUnifiedAD(pActivity, pAdBean.getAdId(), new NativeADUnifiedListener() {
            @Override
            public void onADLoaded(List<NativeUnifiedADData> pList) {
                Log.i(TAG, "native onADLoaded");
                initNativeAd(pActivity, pAdBean, pList.get(0));
                AdManager.getInstance().onAdCacheHandler(null, pAdBean);
            }

            @Override
            public void onNoAD(AdError pAdError) {
                Log.d(TAG, "native onNoAD:" + pAdError.getErrorCode() + " | " + pAdError.getErrorMsg());
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        });

        mAdManager.setVideoPlayPolicy(VideoOption.VideoPlayPolicy.AUTO); // 本次拉回的视频广告，从用户的角度看是自动播放的
        mAdManager.loadData(1);
    }


    /**
     * 初始化原生广告
     *
     * @param pAdBean
     * @param ad
     */
    private void initNativeAd(Activity pActivity, AdInfoEntity.AdBean pAdBean, NativeUnifiedADData ad) {
        if (pActivity == null || pActivity.isDestroyed()) {
            return;
        }

        RelativeLayout rootView = (RelativeLayout) View.inflate(pActivity, R.layout.nativead_layout, null);
        if (rootView == null) {
            return;
        }

        RelativeLayout adContentRL = rootView.findViewById(R.id.native_content_rl);
        AnimationDrawable lAnimationDrawable = (AnimationDrawable) ContextCompat.getDrawable(pActivity, R.drawable.ad_bg_anim);
        adContentRL.setBackground(lAnimationDrawable);
        lAnimationDrawable.start();

        RelativeLayout contentArea = rootView.findViewById(R.id.native_ad_content_image_area);
        TextView titleView = rootView.findViewById(R.id.native_ad_title);
        TextView descView = rootView.findViewById(R.id.native_ad_desc);
        TextView ctaView = rootView.findViewById(R.id.native_ad_install_btn);
        ImageView close = rootView.findViewById(R.id.closeIv);

        titleView.setText(ad.getTitle());
        descView.setText(ad.getDesc());
        ctaView.setText((TextUtils.isEmpty(ad.getCTAText()) ? "立即浏览" : ad.getCTAText()));

        NativeAdContainer lNativeAdContainer = new NativeAdContainer(pActivity);
        lNativeAdContainer.addView(rootView);

        if (AdManager.getInstance().getNativeRootFl() != null) {
            AdManager.getInstance().getNativeRootFl().removeAllViews();
            AdManager.getInstance().getNativeRootFl().addView(lNativeAdContainer);

            if (AdManager.getInstance().isShowNative()) {
                AdManager.getInstance().getNativeRootFl().setVisibility(View.VISIBLE);
            } else {
                AdManager.getInstance().getNativeRootFl().setVisibility(View.GONE);
            }
        }

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(contentArea);
        clickableViews.add(titleView);
        clickableViews.add(descView);
        clickableViews.add(ctaView);
        clickableViews.add(close);

        // 将布局与广告进行绑定
        ad.bindAdToView(pActivity, lNativeAdContainer, null, clickableViews);

        // 设置广告事件监听
        ad.setNativeAdEventListener(new NativeADEventListenerWithClickInfo() {
            @Override
            public void onADClicked(View pView) {
                Log.i(TAG, "native onADClicked");
                if (pView != null) {
                    if (pView.getId() == R.id.closeIv) {
                        AdManager.getInstance().hideNative();
                    } else {
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }
                }
            }

            @Override
            public void onADExposed() {
                Log.i(TAG, "native onADExposed");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onADError(AdError error) {
                Log.i(TAG, "native onADError:" + error.getErrorCode() + " | " + error.getErrorMsg());
            }

            @Override
            public void onADStatusChanged() {
                Log.i(TAG, "native onADStatusChanged");
            }
        });

        if (ad.getAdPatternType() == AdPatternType.NATIVE_VIDEO) {
            Log.i(TAG, "native 视频");
            MediaView lMediaView = new MediaView(pActivity);
            contentArea.addView(lMediaView);
            ad.bindMediaView(lMediaView,
                    new VideoOption.Builder()
                            .setAutoPlayPolicy(VideoOption.AutoPlayPolicy.WIFI)
                            .build(),
                    null);
        } else {
            String imgPath;
            if (ad.getAdPatternType() == NATIVE_2IMAGE_2TEXT) {
                imgPath = ad.getImgUrl();
            } else if (ad.getAdPatternType() == NATIVE_3IMAGE) {
                imgPath = ad.getImgList().get(0);
            } else {
                imgPath = ad.getImgUrl();
            }

            Log.i(TAG, "native 图片");
            RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            lLayoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);

            ImageView imageView = new ImageView(pActivity);
            Glide.with(pActivity).load(imgPath).into(imageView);
            contentArea.addView(imageView, lLayoutParams);
        }
    }

    /**
     * 开屏广告
     *
     * @param pAdBean
     */
    public void showSplash(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YLHAdMgHolder.hadInit) {
            Log.e(TAG, "splash 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }


        SplashAD splashAD = new SplashAD(pActivity, pAdBean.getAdId(), new SplashADListener() {
            @Override
            public void onADDismissed() {
                Log.i(TAG, "splash onADDismissed");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onNoAD(AdError pAdError) {
                Log.e(TAG, "splash onNoAD:" + pAdError.getErrorCode() + " | " + pAdError.getErrorMsg());
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onADPresent() {
                Log.i(TAG, "splash onADPresent");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onADClicked() {
                Log.i(TAG, "splash onADClicked");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onADTick(long pL) {
                Log.i(TAG, "splash onADTick");
            }

            @Override
            public void onADExposure() {
                Log.i(TAG, "splash onADExposure");
            }

            @Override
            public void onADLoaded(long pL) {
                Log.i(TAG, "splash onADLoaded");
                AdManager.getInstance().onAdCacheHandler(null, pAdBean);
            }
        }, 0);
        splashAD.fetchAndShowIn(AdManager.getInstance().getSplashFl());
    }

    /**
     * 全屏广告
     *
     * @param pAdBean
     */
    public void loadFullVideoAd(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YLHAdMgHolder.hadInit) {
            Log.e(TAG, "full 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            Log.e(TAG, "full activity is null");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (mFullADMap.containsKey(pAdBean.getAdId())) {
            mFullADMap.remove(pAdBean.getAdId());
        }

        ExpressInterstitialAD lExpressInterstitialAD = new ExpressInterstitialAD(pActivity, pAdBean.getAdId(), new ExpressInterstitialAdListener() {
            @Override
            public void onAdLoaded() {
                Log.i(TAG, "full onAdLoaded");
                ExpressInterstitialAD lInterstitialAD = mFullADMap.get(pAdBean.getAdId());
                if (lInterstitialAD != null) {
                    AdManager.getInstance().onAdCacheHandler(lInterstitialAD, pAdBean);
                }
            }

            @Override
            public void onRenderSuccess() {

            }

            @Override
            public void onRenderFail() {

            }

            @Override
            public void onVideoCached() {
                Log.i(TAG, "full onVideoCached");

            }

            @Override
            public void onShow() {
                Log.i(TAG, "full onShow");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onExpose() {

            }

            @Override
            public void onClick() {
                Log.i(TAG, "full onADClicked");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onVideoComplete() {

            }

            @Override
            public void onClose() {
                Log.i(TAG, "full onADClosed");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onError(AdError pAdError) {
                Log.e(TAG, "full onNoAD:" + pAdError.getErrorCode() + " | " + pAdError.getErrorMsg());
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        });

        mFullADMap.put(pAdBean.getAdId(), lExpressInterstitialAD);

        VideoOption2.Builder builder = new VideoOption2.Builder();
        VideoOption2 option = builder
                .setAutoPlayMuted(false)
                .setAutoPlayPolicy(VideoOption2.AutoPlayPolicy.ALWAYS)
                .build();

        lExpressInterstitialAD.setVideoOption(option);
        lExpressInterstitialAD.loadFullScreenAD();
    }


    /**
     * 显示插屏广告
     *
     * @param pAdBean
     */

    ExpressInterstitialAD mInterstitialAD;

    public void showInteraction(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YLHAdMgHolder.hadInit) {
            Log.e(TAG, "interaction 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        if (pActivity == null || pActivity.isDestroyed()) {
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        mInterstitialAD = new ExpressInterstitialAD(pActivity, pAdBean.getAdId(), new ExpressInterstitialAdListener() {
            @Override
            public void onAdLoaded() {
                Log.i(TAG, "interaction onAdLoaded");
                AdManager.getInstance().onAdCacheHandler(null, pAdBean);
                mInterstitialAD.showHalfScreenAD(pActivity);
            }

            @Override
            public void onRenderSuccess() {

            }

            @Override
            public void onRenderFail() {

            }

            @Override
            public void onVideoCached() {
                Log.i(TAG, "interaction onVideoCached");
            }

            @Override
            public void onShow() {
                Log.i(TAG, "lExpressInterstitialAD onShow");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onExpose() {

            }

            @Override
            public void onClick() {
                Log.i(TAG, "lExpressInterstitialAD onADClicked");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onVideoComplete() {

            }

            @Override
            public void onClose() {
                Log.i(TAG, "lExpressInterstitialAD onADClosed");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onError(AdError pAdError) {
                Log.e(TAG, "lExpressInterstitialAD onError:" + pAdError.getErrorCode() + " | " + pAdError.getErrorMsg());
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        });

        VideoOption2.Builder builder = new VideoOption2.Builder();
        VideoOption2 option = builder
                .setAutoPlayMuted(false)
                .setAutoPlayPolicy(VideoOption2.AutoPlayPolicy.ALWAYS)
                .build();
        mInterstitialAD.setVideoOption(option);
        mInterstitialAD.loadHalfScreenAD();
    }
}
