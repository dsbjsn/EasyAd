package com.agent.ad.yky;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.tencent.klevin.KlevinConfig;
import com.tencent.klevin.KlevinManager;
import com.tencent.klevin.listener.InitializationListener;

public class YKYAdMgHolder {
    private static final String TAG = "YKYAdMgHolder";
    private static String AppId_YKY;
    public static boolean hadInit = false;

    public static void init(Context context, String app_id) {
        AppId_YKY = app_id;
        if (TextUtils.isEmpty(AppId_YKY)) {
            Log.e(TAG, "自定义中介 yky 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        KlevinConfig.Builder builder = new KlevinConfig.Builder()
                .appId(AppId_YKY)
                .debugMode(false)
                .directDownloadNetworkType(KlevinConfig.NETWORK_STATE_ALL);

        KlevinManager.init(context, builder.build(), new InitializationListener() {
            public void onSuccess() {
                Log.e(TAG, "onSuccess");
            }

            public void onError(int err, String msg) {
                Log.e(TAG, "err=" + err + " " + msg);
            }

            public void onIdentifier(boolean support, String oaid) {
                if (support) {
                    Log.i(TAG, "oaid=" + oaid);
                } else {
                    Log.e(TAG, "not support oaid");
                }
            }
        });
        Log.e(TAG, "自定义中介 yky 初始化");
    }
}
