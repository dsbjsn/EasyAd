package com.agent.ad;

import android.app.Activity;

import com.agent.ad.gromore.GroMoreMgHolder;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.ks.KSAdMgHolder;
import com.agent.ad.mintegral.MTAdMgHolder;
import com.agent.ad.oneway.OWAdMgHolder;
import com.agent.ad.sigmob.SIGAdMgHolder;
import com.agent.ad.csj.TTAdMgHolder;
import com.agent.ad.yky.YKYAdMgHolder;
import com.agent.ad.ylb.YLBAdMgHolder;
import com.agent.ad.ylh.YLHAdMgHolder;

import java.util.List;

/**
 * 初始化广告平台
 */
public class AdPlatformHelper {
    public static void init(Activity pActivity, List<AdInfoEntity.PlatformDataBean> pPlatformDataBeanList) {
        if (pPlatformDataBeanList != null && !pPlatformDataBeanList.isEmpty()) {
            for (AdInfoEntity.PlatformDataBean lBean : pPlatformDataBeanList) {
                switch (lBean.getPlatformType()) {
                    case CSJ:
                        if (AdManager.isCSJOpen) {
                            TTAdMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    case YLH:
                        if (AdManager.isYLHOpen) {
                            YLHAdMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    case YLB:
                        if (AdManager.isYLBOpen) {
                            YLBAdMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    case SM:
                        if (AdManager.isSMOpen) {
                            SIGAdMgHolder.init(pActivity, lBean.getApp_id(), lBean.getApp_key());
                        }
                        break;
                    case MT:
                        if (AdManager.isMTOpen) {
                            MTAdMgHolder.init(pActivity, lBean.getApp_id(), lBean.getApp_key());
                        }
                        break;
                    case OW:
                        if (AdManager.isOWOpen) {
                            OWAdMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    case KS:
                        if (AdManager.isKSOpen) {
                            KSAdMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    case GM:
                        if (AdManager.isGMOpen) {
                            GroMoreMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    case YKY:
                        if (AdManager.isYKYOpen) {
                            YKYAdMgHolder.init(pActivity, lBean.getApp_id());
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
