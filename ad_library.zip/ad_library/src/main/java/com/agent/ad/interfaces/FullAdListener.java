package com.agent.ad.interfaces;

/**
 * Created on 2020/12/28 14
 *
 * @author xjl
 */
public interface FullAdListener extends AdListener {

}
