package com.agent.ad.network;

import com.agent.ad.entity.AdRewardCallBackEntity;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.QueryMap;

/**
 * @author xjl
 */
public interface NetApi {
    /**
     * 获取服务器广告配置文件
     *
     * @return
     */
    @GET("{json_path}")
    Call<ResponseBody> getAdJson(@Path("json_path") String path);

    /**
     * 服务器上报广告事件
     *
     * @return
     */
    @GET("Api/ApiAdPv?")
    Call<String> postAdEvent(@QueryMap Map<String, String> pMap);

    /**
     * 模拟广告回调
     */
    @GET("/Api/ApiReward/?")
    Call<AdRewardCallBackEntity> rewardCallBack(@QueryMap Map<String, String> pMap);
}
