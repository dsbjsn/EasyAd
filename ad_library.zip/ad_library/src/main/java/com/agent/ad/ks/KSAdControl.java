package com.agent.ad.ks;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.kwad.sdk.api.KsAdSDK;
import com.kwad.sdk.api.KsAdVideoPlayConfig;
import com.kwad.sdk.api.KsDrawAd;
import com.kwad.sdk.api.KsFullScreenVideoAd;
import com.kwad.sdk.api.KsFullScreenVideoAd.FullScreenVideoAdInteractionListener;
import com.kwad.sdk.api.KsInterstitialAd;
import com.kwad.sdk.api.KsLoadManager;
import com.kwad.sdk.api.KsNativeAd;
import com.kwad.sdk.api.KsRewardVideoAd;
import com.kwad.sdk.api.KsScene;
import com.kwad.sdk.api.KsSplashScreenAd;
import com.kwad.sdk.api.KsVideoPlayConfig;
import com.kwad.sdk.api.SdkConfig;
import com.agent.ad.AdConfig;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.adlibrary.R;
import com.agent.ad.AdManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2021/4/23 09
 *
 * @author xjl
 */
public class KSAdControl {
    private static final String TAG = "KS";
    private volatile static KSAdControl instance = null;

    private KSAdControl() {
    }

    //安全线程单例
    public static KSAdControl getInstance() {
        if (instance == null) {
            synchronized (KSAdControl.class) {
                if (instance == null) {
                    instance = new KSAdControl();
                }
            }
        }
        return instance;
    }

    /**
     * 加载激励视频
     *
     * @param pAdBean
     */
    public void loadRewardVideoAd(final AdInfoEntity.AdBean pAdBean) {
        if (!KSAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        KsScene.Builder builder = new KsScene.Builder(Long.parseLong(pAdBean.getAdId())).screenOrientation(SdkConfig.SCREEN_ORIENTATION_PORTRAIT);
        Map<String, String> rewardCallbackExtraData = new HashMap<>();
        rewardCallbackExtraData.put("thirdUserId", AdConfig.getInstance().getToken());
        rewardCallbackExtraData.put("extraData", AdConfig.getInstance().getToken());
        builder.rewardCallbackExtraData(rewardCallbackExtraData);

        Log.d("ks 激励回调参数：", rewardCallbackExtraData.toString());

        KsScene scene = builder.build();
        KsAdSDK.getLoadManager().loadRewardVideoAd(scene, new KsLoadManager.RewardVideoAdListener() {
            @Override
            public void onError(int code, String msg) {
                Log.e(TAG, "reward onError:" + code + " | " + msg);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onRequestResult(int pI) {
                Log.i(TAG, "reward onRequestResult:" + pI);
            }

            @Override
            public void onRewardVideoAdLoad(@Nullable List<KsRewardVideoAd> pList) {
                Log.i(TAG, "reward onRewardVideoAdLoad:");
                KsRewardVideoAd lKsRewardVideoAd = pList.get(0);
                if (lKsRewardVideoAd != null) {
                    AdManager.getInstance().onAdCacheHandler(lKsRewardVideoAd, pAdBean);

                    lKsRewardVideoAd.setRewardAdInteractionListener(new KsRewardVideoAd.RewardAdInteractionListener() {
                        @Override
                        public void onAdClicked() {
                            Log.i(TAG, "reward onAdClicked");
                            AdManager.getInstance().onAdClickHandler(pAdBean);
                        }

                        @Override
                        public void onPageDismiss() {
                            Log.i(TAG, "reward onPageDismiss");
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                        }

                        @Override
                        public void onVideoPlayError(int pI, int pI1) {
                            Log.e(TAG, "reward onVideoPlayError:" + pI + " | " + pI1);
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                            AdManager.getInstance().recordIsGetReward(false);
                        }

                        @Override
                        public void onVideoPlayEnd() {
                            Log.i(TAG, "reward onVideoPlayEnd");
                        }

                        @Override
                        public void onVideoSkipToEnd(long pL) {

                        }

                        @Override
                        public void onVideoPlayStart() {
                            Log.i(TAG, "reward onVideoPlayStart");
                            AdManager.getInstance().onAdShowHandler(pAdBean);
                        }

                        @Override
                        public void onRewardVerify() {
                            Log.i(TAG, "reward onRewardVerify");
                            AdManager.getInstance().recordIsGetReward(true);
                        }
                    });
                }
            }
        });
    }


    /**
     * 加载全屏广告
     *
     * @param pAdBean
     */
    public void loadFullVideoAd(AdInfoEntity.AdBean pAdBean) {
        if (!KSAdMgHolder.hadInit) {
            Log.e(TAG, "full 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        KsScene scene = new KsScene.Builder(Long.parseLong(pAdBean.getAdId()))
                .screenOrientation(SdkConfig.SCREEN_ORIENTATION_PORTRAIT)
                .build();

        KsAdSDK.getLoadManager().loadFullScreenVideoAd(scene,
                new KsLoadManager.FullScreenVideoAdListener() {
                    @Override
                    public void onError(int code, String msg) {
                        Log.e(TAG, "full onError:" + code + " | " + msg);
                        AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    }

                    @Override
                    public void onRequestResult(int adNumber) {
                        Log.i(TAG, "full onRequestResult:" + adNumber);
                    }

                    @Override
                    public void onFullScreenVideoAdLoad(@Nullable List<KsFullScreenVideoAd> adList) {
                        Log.i(TAG, "full onRewardVideoAdLoad:");
                        KsFullScreenVideoAd lFullScreenVideoAd = adList.get(0);
                        if (lFullScreenVideoAd != null) {
                            AdManager.getInstance().onAdCacheHandler(lFullScreenVideoAd, pAdBean);
                            lFullScreenVideoAd.setFullScreenVideoAdInteractionListener(new FullScreenVideoAdInteractionListener() {
                                @Override
                                public void onAdClicked() {
                                    Log.i(TAG, "full onAdClicked");
                                    AdManager.getInstance().onAdClickHandler(pAdBean);
                                }

                                @Override
                                public void onPageDismiss() {
                                    Log.i(TAG, "full onPageDismiss");
                                    AdManager.getInstance().onAdClosedHandler(pAdBean);
                                }

                                @Override
                                public void onVideoPlayError(int pI, int pI1) {
                                    Log.e(TAG, "full onVideoPlayError:" + pI + " | " + pI1);
                                    AdManager.getInstance().onAdClosedHandler(pAdBean);
                                }

                                @Override
                                public void onVideoPlayEnd() {
                                    Log.i(TAG, "full onVideoPlayEnd");
                                }

                                @Override
                                public void onVideoPlayStart() {
                                    Log.i(TAG, "full onVideoPlayStart");
                                    AdManager.getInstance().onAdShowHandler(pAdBean);
                                }

                                @Override
                                public void onSkippedVideo() {
                                    Log.i(TAG, "full onSkippedVideo");
                                }
                            });
                        }
                    }
                });
    }

    /**
     * 加载draw广告
     *
     * @param pAdBean
     */
    public void loadDrawVideoAd(AdInfoEntity.AdBean pAdBean) {
        if (!KSAdMgHolder.hadInit) {
            Log.e(TAG, "draw 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        KsScene scene = new KsScene.Builder(Long.parseLong(pAdBean.getAdId()))
                .screenOrientation(SdkConfig.SCREEN_ORIENTATION_PORTRAIT)
                .build();

        KsAdSDK.getLoadManager().loadDrawAd(scene,
                new KsLoadManager.DrawAdListener() {
                    @Override
                    public void onError(int code, String msg) {
                        Log.e(TAG, "draw onError:" + code + " | " + msg);
                        AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    }

                    @Override
                    public void onDrawAdLoad(@Nullable List<KsDrawAd> pList) {
                        Log.i(TAG, "draw onRewardVideoAdLoad:");
                        KsDrawAd lKsDrawAd = pList.get(0);
                        if (lKsDrawAd != null) {
                            AdManager.getInstance().onAdCacheHandler(lKsDrawAd, pAdBean);
                        } else {
                            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                        }
                    }
                });
    }

    /**
     * 显示开屏广告
     *
     * @param pActivity
     * @param pAdBean
     */
    public void showSplash(AppCompatActivity pActivity, final AdInfoEntity.AdBean pAdBean) {
        if (!KSAdMgHolder.hadInit) {
            Log.e(TAG, "splash 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        KsScene scene = new KsScene.Builder(Long.parseLong(pAdBean.getAdId())).build(); // 此为测试posId，请联系快⼿平台申请正式posId
        KsAdSDK.getLoadManager().loadSplashScreenAd(scene,
                new KsLoadManager.SplashScreenAdListener() {
                    @Override
                    public void onError(int code, String msg) {
                        Log.e(TAG, "splash onError:" + code + " | " + msg);
                        AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    }

                    @Override
                    public void onRequestResult(int pI) {
                        Log.i(TAG, "splash onRequestResult:" + pI);
                    }

                    @Override
                    public void onSplashScreenAdLoad(@Nullable KsSplashScreenAd pKsSplashScreenAd) {
                        Log.i(TAG, "splash onSplashScreenAdLoad:");
                        if (pKsSplashScreenAd != null) {
                            AdManager.getInstance().onAdCacheHandler(pKsSplashScreenAd, pAdBean);
                            addFragment(pActivity, pKsSplashScreenAd, pAdBean);
                        }
                    }
                });
    }

    private void addFragment(AppCompatActivity pActivity, KsSplashScreenAd splashScreenAd, AdInfoEntity.AdBean pAdBean) {
        Fragment fragment = splashScreenAd.getFragment(new KsSplashScreenAd.SplashScreenAdInteractionListener() {
            @Override
            public void onAdClicked() {
                Log.i(TAG, "splash onAdClicked");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onAdShowError(int code, String extra) {
                Log.e(TAG, "splash onAdShowError:" + code + " | " + extra);
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onAdShowEnd() {
                Log.i(TAG, "splash onAdShowEnd");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onAdShowStart() {
                Log.i(TAG, "splash onAdShowStart");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onSkippedAd() {
                Log.i(TAG, "splash onSkippedAd");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onDownloadTipsDialogShow() {

            }

            @Override
            public void onDownloadTipsDialogDismiss() {

            }

            @Override
            public void onDownloadTipsDialogCancel() {

            }
        });

        if (AdManager.getInstance().mSplashFl!=null && !pActivity.isFinishing()) {
            pActivity.getSupportFragmentManager().beginTransaction().replace(AdManager.getInstance().mSplashFl.getId(), fragment).commitAllowingStateLoss();
        }
    }

    /**
     * 原生广告
     *
     * @param pAdBean
     */
    public void showNative(AdInfoEntity.AdBean pAdBean) {
        if (!KSAdMgHolder.hadInit) {
            Log.e(TAG, "native 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        KsScene scene = new KsScene.Builder(Long.parseLong(pAdBean.getAdId())).adNum(1).build();
        KsAdSDK.getLoadManager().loadNativeAd(scene, new KsLoadManager.NativeAdListener() {
            @Override
            public void onError(int code, String msg) {
                Log.e(TAG, "native onError:" + code + " | " + msg);
            }

            @Override
            public void onNativeAdLoad(@Nullable List<KsNativeAd> adList) {
                Log.i(TAG, "native onNativeAdLoad");
                if (!adList.isEmpty()) {
                    KsNativeAd lKsNativeAd = adList.get(0);
                    if (lKsNativeAd != null) {
                        initNativeAd(pAdBean, lKsNativeAd);
                    }
                }
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }
        });
    }

    private void initNativeAd(AdInfoEntity.AdBean pAdBean, KsNativeAd ad) {
        Context lContext = AdConfig.getInstance().getContext();
        if (lContext == null) {
            return;
        }

        RelativeLayout rootView = (RelativeLayout) View.inflate(lContext, R.layout.nativead_layout, null);


        RelativeLayout adContentRL = rootView.findViewById(R.id.native_content_rl);
        AnimationDrawable lAnimationDrawable = (AnimationDrawable) ContextCompat.getDrawable(lContext, R.drawable.ad_bg_anim);
        adContentRL.setBackground(lAnimationDrawable);
        lAnimationDrawable.start();

        RelativeLayout contentArea = rootView.findViewById(R.id.native_ad_content_image_area);
        TextView titleView = rootView.findViewById(R.id.native_ad_title);
        TextView descView = rootView.findViewById(R.id.native_ad_desc);
        TextView ctaView = rootView.findViewById(R.id.native_ad_install_btn);
        ImageView close = rootView.findViewById(R.id.closeIv);
        close.setOnClickListener(v -> AdManager.getInstance().hideNative());

        titleView.setText(ad.getAdDescription());
        descView.setText(ad.getAppName());
        ctaView.setText((TextUtils.isEmpty(ad.getActionDescription()) ? "立即浏览" : ad.getActionDescription()));

        if (AdManager.getInstance().getNativeRootFl() != null) {
            AdManager.getInstance().getNativeRootFl().removeAllViews();
            AdManager.getInstance().getNativeRootFl().addView(rootView);

            if (AdManager.getInstance().isShowNative()) {
                AdManager.getInstance().getNativeRootFl().setVisibility(View.VISIBLE);
            } else {
                AdManager.getInstance().getNativeRootFl().setVisibility(View.GONE);
            }
        }

        List<View> clickViewList = new ArrayList<>();
        clickViewList.add(rootView);
        // 注册View的点击，点击后触发转化
        ad.registerViewForInteraction(rootView, clickViewList, new KsNativeAd.AdInteractionListener() {
            @Override
            public void onAdClicked(View view, KsNativeAd ad) {
                if (ad != null) {
                    Log.i(TAG, "native onAdClicked");
                    AdManager.getInstance().onAdClickHandler(pAdBean);
                }
            }

            @Override
            public void onAdShow(KsNativeAd ad) {
                if (ad != null) {
                    Log.i(TAG, "native onAdShow");
                    AdManager.getInstance().onAdShowHandler(pAdBean);
                }
            }

            // 媒体自定义合规弹窗回调。
            // 如果不想使用自定义的合规弹窗，而使用SDK默认的，直接return false即可
            @Override
            public boolean handleDownloadDialog(DialogInterface.OnClickListener clickListener) {
                return false;
            }
        });

        KsAdVideoPlayConfig videoPlayConfig = new KsAdVideoPlayConfig.Builder()
                .videoSoundEnable(false) // 有声播放
                .dataFlowAutoStart(true) // 流量下自动播放
                .build();
        View videoView = ad.getVideoView(lContext, videoPlayConfig);
        if (videoView!=null) {
            Log.i(TAG, "native 视频");
            // SDK默认渲染的视频view
            if (videoView != null && videoView.getParent() == null) {
                contentArea.removeAllViews();
                contentArea.addView(videoView);
            }
        } else {
            Log.i(TAG, "native 图片");
            RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            lLayoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);

            ImageView imageView = new ImageView(lContext);
            Glide.with(lContext).load(ad.getImageList().get(0).getImageUrl()).into(imageView);
            contentArea.addView(imageView, lLayoutParams);
        }
    }


    /**
     * 显示插屏广告
     *
     * @param pActivity
     * @param pAdBean
     */
    public void showInteraction(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        KsScene scene = new KsScene.Builder(Long.valueOf(pAdBean.getAdId())).build();
        KsAdSDK.getLoadManager().loadInterstitialAd(scene, new KsLoadManager.InterstitialAdListener() {
            @Override
            public void onError(int pI, String pS) {
                Log.i(TAG, "interaction onError " + pS + " | " + pS);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onRequestResult(int adNumber) {
            }

            @Override
            public void onInterstitialAdLoad(@Nullable List<KsInterstitialAd> adList) {
                if (adList != null && adList.size() > 0) {
                    AdManager.getInstance().onAdCacheHandler(null, pAdBean);

                    KsInterstitialAd lInterstitialAd = adList.get(0);

                    KsVideoPlayConfig videoPlayConfig = new KsVideoPlayConfig.Builder().showLandscape(true).videoSoundEnable(true).build();
                    lInterstitialAd.showInterstitialAd(pActivity, videoPlayConfig);

                    lInterstitialAd.setAdInteractionListener(new KsInterstitialAd.AdInteractionListener() {
                        @Override
                        public void onAdClicked() {
                            Log.i(TAG, "interaction onAdClicked");
                            AdManager.getInstance().onAdClickHandler(pAdBean);
                        }

                        @Override
                        public void onAdShow() {
                            Log.i(TAG, "interaction onAdShow");
                            AdManager.getInstance().onAdShowHandler(pAdBean);
                        }

                        @Override
                        public void onAdClosed() {
                            Log.i(TAG, "interaction onAdClosed");
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                        }

                        @Override
                        public void onPageDismiss() {
                        }

                        @Override
                        public void onVideoPlayError(int pI, int pI1) {
                            Log.i(TAG, "interaction onVideoPlayError " + pI + " | " + pI1);
                            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                        }

                        @Override
                        public void onVideoPlayEnd() {
                            Log.i(TAG, "interaction onVideoPlayEnd");
                        }

                        @Override
                        public void onVideoPlayStart() {
                        }

                        @Override
                        public void onSkippedAd() {

                        }
                    });
                }
            }
        });
    }
}
