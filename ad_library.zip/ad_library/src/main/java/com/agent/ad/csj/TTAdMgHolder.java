package com.agent.ad.csj;

import android.content.Context;
import android.text.TextUtils;

import com.bytedance.sdk.openadsdk.TTAdConfig;
import com.bytedance.sdk.openadsdk.TTAdConstant;
import com.bytedance.sdk.openadsdk.TTAdSdk;
import com.agent.ad.AdConfig;
import com.agent.ad.utils.LogUtil;

public class TTAdMgHolder {
    private static String AppId_CSJ;
    public static boolean hadInit = false;

    public static void init(Context context, String app_id) {
        AppId_CSJ = app_id;
        if (TextUtils.isEmpty(AppId_CSJ)) {
            LogUtil.e("自定义中介 csj 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        TTAdSdk.init(context, buildConfig());
        LogUtil.i("自定义中介 csj 初始化");
    }

    private static TTAdConfig buildConfig() {
        return new TTAdConfig.Builder()
                .appId(AppId_CSJ)
                .useTextureView(true) //使用TextureView控件播放视频,默认为SurfaceView,当有SurfaceView冲突的场景，可以使用TextureView
                .appName(AdConfig.getInstance().getContext().getPackageName())
                .titleBarTheme(TTAdConstant.TITLE_BAR_THEME_DARK)
                .allowShowNotify(true) //是否允许sdk展示通知栏提示
                .allowShowPageWhenScreenLock(true) //是否在锁屏场景支持展示广告落地页
                .debug(AdConfig.getInstance().isTest()) //测试阶段打开，可以通过日志排查问题，上线时去除该调用
                .directDownloadNetworkType(TTAdConstant.NETWORK_STATE_WIFI, TTAdConstant.NETWORK_STATE_3G) //允许直接下载的网络状态集合
                .supportMultiProcess(true)//是否支持多进程
                .needClearTaskReset()
                .build();
    }
}
