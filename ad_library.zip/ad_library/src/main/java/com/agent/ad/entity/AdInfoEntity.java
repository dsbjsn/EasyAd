package com.agent.ad.entity;

import android.text.TextUtils;

import com.agent.ad.AdType;
import com.agent.ad.AdPlatform;

import java.io.Serializable;
import java.util.List;

/**
 * Created on 2021/4/10 15
 *
 * @author xjl
 */
public class AdInfoEntity implements Serializable {
    private String name;
    private Integer maxGDTError = 1;

    //优量汇最大展示次数
    private Integer ylbMaxNum = 15;
    //并发请求个数
    private Integer maxThreadNum = 3;
    //缓存个数
    private Integer concurrentLoadNum = 2;
    //banner 刷新频率
    private Integer bannerRefreshRate = 2;
    //native 刷新频率
    private Integer nativeRefreshRate = 2;

    private List<PlatformDataBean> platformData;

    private List<AdBean> rewardList;
    private List<AdBean> fullList;
    private List<AdBean> bannerList;
    private List<AdBean> nativeList;
    private List<AdBean> splashList;
    private List<AdBean> interactionList;
    private List<AdBean> drawList;

    public List<AdBean> getDrawList() {
        return drawList;
    }

    public void setDrawList(List<AdBean> pDrawList) {
        drawList = pDrawList;
    }

    public List<AdBean> getInteractionList() {
        return interactionList;
    }

    public void setInteractionList(List<AdBean> pInteractionList) {
        interactionList = pInteractionList;
    }

    public Integer getBannerRefreshRate() {
        return bannerRefreshRate;
    }

    public void setBannerRefreshRate(Integer pBannerRefreshRate) {
        bannerRefreshRate = pBannerRefreshRate;
    }

    public Integer getNativeRefreshRate() {
        return nativeRefreshRate;
    }

    public void setNativeRefreshRate(Integer pNativeRefreshRate) {
        nativeRefreshRate = pNativeRefreshRate;
    }

    public Integer getMaxThreadNum() {
        return maxThreadNum;
    }

    public void setMaxThreadNum(Integer pMaxThreadNum) {
        maxThreadNum = pMaxThreadNum;
    }

    public Integer getConcurrentLoadNum() {
        return concurrentLoadNum;
    }

    public void setConcurrentLoadNum(Integer pConcurrentLoadNum) {
        concurrentLoadNum = pConcurrentLoadNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMaxGDTError() {
        return maxGDTError;
    }

    public void setMaxGDTError(Integer maxGDTError) {
        this.maxGDTError = maxGDTError;
    }

    public Integer getYlbMaxNum() {
        return ylbMaxNum;
    }

    public void setYlbMaxNum(Integer ylbMaxNum) {
        this.ylbMaxNum = ylbMaxNum;
    }

    public List<PlatformDataBean> getPlatformData() {
        return platformData;
    }

    public void setPlatformData(List<PlatformDataBean> platformData) {
        this.platformData = platformData;
    }

    public List<AdBean> getRewardList() {
        return rewardList;
    }

    public void setRewardList(List<AdBean> rewardList) {
        this.rewardList = rewardList;
    }

    public List<AdBean> getFullList() {
        return fullList;
    }

    public void setFullList(List<AdBean> fullVideoList) {
        this.fullList = fullVideoList;
    }

    public List<AdBean> getBannerList() {
        return bannerList;
    }

    public void setBannerList(List<AdBean> bannerList) {
        this.bannerList = bannerList;
    }

    public List<AdBean> getNativeList() {
        return nativeList;
    }

    public void setNativeList(List<AdBean> nativeList) {
        this.nativeList = nativeList;
    }

    public List<AdBean> getSplashList() {
        return splashList;
    }

    public void setSplashList(List<AdBean> pSplashList) {
        splashList = pSplashList;
    }

    public static class PlatformDataBean implements Serializable {
        private String platform;
        private String app_id;
        private Boolean is_open;
        private String app_key;

        public String getPlatform() {
            return platform;
        }

        public void setPlatform(String platform) {
            this.platform = platform;
        }

        public String getApp_id() {
            return app_id;
        }

        public void setApp_id(String app_id) {
            this.app_id = app_id;
        }

        public Boolean isIs_open() {
            return is_open;
        }

        public void setIs_open(Boolean is_open) {
            this.is_open = is_open;
        }

        public String getApp_key() {
            return app_key;
        }

        public void setApp_key(String app_key) {
            this.app_key = app_key;
        }

        public AdPlatform getPlatformType() {
            if (platform.equals(AdPlatform.CSJ.getPlatformString())) {
                return AdPlatform.CSJ;
            } else if (platform.equals(AdPlatform.GM.getPlatformString())) {
                return AdPlatform.GM;
            } else if (platform.equals(AdPlatform.KS.getPlatformString())) {
                return AdPlatform.KS;
            } else if (platform.equals(AdPlatform.MT.getPlatformString())) {
                return AdPlatform.MT;
            } else if (platform.equals(AdPlatform.OW.getPlatformString())) {
                return AdPlatform.OW;
            } else if (platform.equals(AdPlatform.SM.getPlatformString())) {
                return AdPlatform.SM;
            } else if (platform.equals(AdPlatform.YLB.getPlatformString())) {
                return AdPlatform.YLB;
            } else if (platform.equals(AdPlatform.YLH.getPlatformString())) {
                return AdPlatform.YLH;
            } else if (platform.equals(AdPlatform.YKY.getPlatformString())) {
                return AdPlatform.YKY;
            } else {
                return AdPlatform.UN_KNOW;
            }
        }
    }

    public static class AdBean implements Serializable {
        private String type;
        private String adType = "";
        private String adId;
        private String adGroupId = "";
        private String platform;
        private float price;
        /**
         * 广告位是否有效
         */
        private boolean valid = true;

        public boolean isValid() {
            return valid;
        }

        public void setValid(boolean pValid) {
            valid = pValid;
        }

        public AdType getAdType() {
            if (adType.equals(AdType.REWARD.getType())) {
                return AdType.REWARD;
            } else if (adType.equals(AdType.NATIVE.getType())) {
                return AdType.NATIVE;
            } else if (adType.equals(AdType.BANNER.getType())) {
                return AdType.BANNER;
            } else if (adType.equals(AdType.SPLASH.getType())) {
                return AdType.SPLASH;
            } else if (adType.equals(AdType.FULL.getType())) {
                return AdType.FULL;
            } else if (adType.equals(AdType.INTERACTION.getType())) {
                return AdType.INTERACTION;
            } else if (adType.equals(AdType.DRAW.getType())) {
                return AdType.DRAW;
            }
            return AdType.UN_KNOW;
        }

        public void setAdType(String pAdType) {
            adType = pAdType;
        }

        public AdType getType() {
            if (type.equals(AdType.REWARD.getType())) {
                return AdType.REWARD;
            } else if (type.equals(AdType.NATIVE.getType())) {
                return AdType.NATIVE;
            } else if (type.equals(AdType.BANNER.getType())) {
                return AdType.BANNER;
            } else if (type.equals(AdType.SPLASH.getType())) {
                return AdType.SPLASH;
            } else if (type.equals(AdType.FULL.getType())) {
                return AdType.FULL;
            } else if (type.equals(AdType.INTERACTION.getType())) {
                return AdType.INTERACTION;
            } else if (type.equals(AdType.DRAW.getType())) {
                return AdType.DRAW;
            }
            return AdType.UN_KNOW;
        }

        public void setType(String pType) {
            type = pType;
        }

        public float getPrice() {
            return price;
        }

        public void setPrice(float pPrice) {
            price = pPrice;
        }

        public String getAdId() {
            return adId;
        }

        public void setAdId(String adId) {
            this.adId = adId;
        }

        public String getAdGroupId() {
            return adGroupId;
        }

        public void setAdGroupId(String pAdGroupId) {
            adGroupId = pAdGroupId;
        }

        public AdPlatform getPlatform() {
            if (platform.equals(AdPlatform.CSJ.getPlatformString())) {
                return AdPlatform.CSJ;
            } else if (platform.equals(AdPlatform.GM.getPlatformString())) {
                return AdPlatform.GM;
            } else if (platform.equals(AdPlatform.KS.getPlatformString())) {
                return AdPlatform.KS;
            } else if (platform.equals(AdPlatform.MT.getPlatformString())) {
                return AdPlatform.MT;
            } else if (platform.equals(AdPlatform.OW.getPlatformString())) {
                return AdPlatform.OW;
            } else if (platform.equals(AdPlatform.SM.getPlatformString())) {
                return AdPlatform.SM;
            } else if (platform.equals(AdPlatform.YLB.getPlatformString())) {
                return AdPlatform.YLB;
            } else if (platform.equals(AdPlatform.YLH.getPlatformString())) {
                return AdPlatform.YLH;
            } else if (platform.equals(AdPlatform.YKY.getPlatformString())) {
                return AdPlatform.YKY;
            } else {
                return AdPlatform.UN_KNOW;
            }
        }

        public void setPlatform(String platform) {
            this.platform = platform;
        }


        public int getTypeId() {
            if (TextUtils.isEmpty(adType)) {
                return getType().getId();
            } else {
                return getAdTypeId();
            }
        }

        private int getAdTypeId() {
            return getAdType().getId();
        }

        public int getPlatformId() {
            int p = 0;
            if (platform.equals(AdPlatform.CSJ.getPlatformString()) || platform.equals(AdPlatform.GM.getPlatformString())) {
                p = 1;
            } else if (platform.equals(AdPlatform.YLH.getPlatformString())) {
                p = 2;
            } else if (platform.equals(AdPlatform.YLB.getPlatformString())) {
                p = 3;
            } else if (platform.equals(AdPlatform.SM.getPlatformString())) {
                p = 4;
            } else if (platform.equals(AdPlatform.MT.getPlatformString())) {
                p = 5;
            } else if (platform.equals(AdPlatform.KS.getPlatformString())) {
                p = 6;
            } else if (platform.equals(AdPlatform.OW.getPlatformString())) {
                p = 7;
            } else if (platform.equals(AdPlatform.YKY.getPlatformString())) {
                p = 8;
            }
            return p;
        }

        @Override
        public String toString() {
            return "AdBean{" +
                    "type='" + type + '\'' +
                    ", adType='" + adType + '\'' +
                    ", adId='" + adId + '\'' +
                    ", adGroupId='" + adGroupId + '\'' +
                    ", platform='" + platform + '\'' +
                    ", price=" + price +
                    ", valid=" + valid +
                    '}';
        }
    }
}

