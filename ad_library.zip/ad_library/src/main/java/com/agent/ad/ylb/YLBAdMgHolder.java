package com.agent.ad.ylb;

import android.content.Context;
import android.text.TextUtils;

import com.wannuosili.sdk.WNAdConfig;
import com.wannuosili.sdk.WNAdSdk;
import com.agent.ad.AdConfig;
import com.agent.ad.utils.LogUtil;

public class YLBAdMgHolder {
    private static String AppId_YLB;
    public static boolean hadInit = false;

    public static void init(Context context, String app_id) {
        AppId_YLB = app_id;
        if (TextUtils.isEmpty(AppId_YLB)) {
            LogUtil.e("自定义中介 ylb 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        WNAdSdk.initialize(new WNAdConfig.Builder()
                .setAppId(AppId_YLB)
                .setDebug(AdConfig.getInstance().isTest()) // 设置是否是debug模式
                .setContext(context) // 上下文
                .supportMultiProcess(true)//支持多线程
                .build());
        LogUtil.i("自定义中介 ylb 初始化");
    }
}
