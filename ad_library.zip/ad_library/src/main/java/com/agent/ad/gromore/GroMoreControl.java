package com.agent.ad.gromore;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bytedance.msdk.adapter.TToast;
import com.bytedance.msdk.adapter.pangle.PangleNetworkRequestInfo;
import com.bytedance.msdk.api.AdError;
import com.bytedance.msdk.api.AdSlot;
import com.bytedance.msdk.api.NetworkPlatformConst;
import com.bytedance.msdk.api.TTAdConstant;
import com.bytedance.msdk.api.TTAdSize;
import com.bytedance.msdk.api.TTDislikeCallback;
import com.bytedance.msdk.api.TTNetworkRequestInfo;
import com.bytedance.msdk.api.banner.TTAdBannerListener;
import com.bytedance.msdk.api.banner.TTAdBannerLoadCallBack;
import com.bytedance.msdk.api.banner.TTBannerViewAd;
import com.bytedance.msdk.api.nativeAd.TTNativeAd;
import com.bytedance.msdk.api.nativeAd.TTNativeAdListener;
import com.bytedance.msdk.api.nativeAd.TTNativeAdLoadCallback;
import com.bytedance.msdk.api.nativeAd.TTUnifiedNativeAd;
import com.bytedance.msdk.api.nativeAd.TTViewBinder;
import com.bytedance.msdk.api.reward.RewardItem;
import com.bytedance.msdk.api.reward.TTRewardAd;
import com.bytedance.msdk.api.reward.TTRewardedAdListener;
import com.bytedance.msdk.api.reward.TTRewardedAdLoadCallback;
import com.bytedance.msdk.api.splash.TTSplashAd;
import com.bytedance.msdk.api.splash.TTSplashAdListener;
import com.bytedance.msdk.api.splash.TTSplashAdLoadCallback;
import com.agent.ad.AdConfig;
import com.agent.ad.AdManager;
import com.agent.ad.AdPlatform;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.utils.DpiUtils;
import com.agent.adlibrary.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2021/8/26 11
 *
 * @author xjl
 */
public class GroMoreControl {
    private static final String TAG = "自定义中介 GM";

    /**
     * 激励视频广告
     */
    public static void loadRewardAd(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        Log.e(TAG, "reward loadRewardAd");

        Map<String, String> customData = new HashMap<>();
        customData.put(AdSlot.CUSTOM_DATA_KEY_PANGLE, AdConfig.getInstance().getToken());
        customData.put(AdSlot.CUSTOM_DATA_KEY_GDT, AdConfig.getInstance().getToken());
        customData.put(AdSlot.CUSTOM_DATA_KEY_SIGMOB, AdConfig.getInstance().getToken());
        customData.put(AdSlot.CUSTOM_DATA_KEY_KS, AdConfig.getInstance().getToken());

        AdSlot adSlot = new AdSlot.Builder()
                .setAdStyleType(AdSlot.TYPE_EXPRESS_AD)
                .setUserID(AdConfig.getInstance().getToken())
                .setRewardName("coin")
                .setRewardAmount(10)
                .setOrientation(TTAdConstant.VERTICAL)
                .setCustomData(customData)
                .build();

        //请求广告
        TTRewardAd lTTRewardAd = new TTRewardAd(pActivity, pAdBean.getAdId());
        lTTRewardAd.loadRewardAd(adSlot, new TTRewardedAdLoadCallback() {
            @Override
            public void onRewardVideoLoadFail(AdError adError) {
                Log.e(TAG, "reward onVideoError:" + adError.code + " - " + adError.message);

                if (lTTRewardAd != null) {
                    Log.e(TAG, "reward ad loadInfos：" + lTTRewardAd.getAdLoadInfoList());
                }

                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onRewardVideoAdLoad() {
                if (lTTRewardAd != null) {
                    Log.e(TAG, "reward ad loadInfos：" + lTTRewardAd.getAdLoadInfoList());
                }

                AdManager.getInstance().onAdCacheHandler(lTTRewardAd, pAdBean);
            }

            @Override
            public void onRewardVideoCached() {
                Log.e(TAG, "reward onRewardVideoCached");
            }
        });
    }


    private static AdInfoEntity.AdBean realRewardAdBean = null;

    public static void showRewardAd(Activity pActivity, TTRewardAd pTTRewardAd, AdInfoEntity.AdBean gmAdBean) {
        pTTRewardAd.showRewardAd(pActivity, new TTRewardedAdListener() {
            @Override
            public void onRewardedAdShow() {
                int ptId = pTTRewardAd.getAdNetworkPlatformId();
                String adId = pTTRewardAd.getAdNetworkRitId();

                realRewardAdBean = new AdInfoEntity.AdBean();
                realRewardAdBean.setAdGroupId(gmAdBean.getAdGroupId());
                realRewardAdBean.setAdType(gmAdBean.getAdType().getType());
                realRewardAdBean.setType(gmAdBean.getType().getType());
                realRewardAdBean.setValid(gmAdBean.isValid());

                realRewardAdBean.setPrice(Float.parseFloat(pTTRewardAd.getPreEcpm()) / 100);
                Log.i("激励视频ecpm", realRewardAdBean.getPrice() + "");

                realRewardAdBean.setAdId(adId);

                Log.i("平台id", ptId + "");
                switch (ptId) {
                    case NetworkPlatformConst.SDK_NAME_PANGLE:
                        realRewardAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_GDT:
                        realRewardAdBean.setPlatform(AdPlatform.YLH.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_SIGMOB:
                        realRewardAdBean.setPlatform(AdPlatform.SM.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_KS:
                        realRewardAdBean.setPlatform(AdPlatform.KS.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_MT:
                        realRewardAdBean.setPlatform(AdPlatform.MT.getPlatformString());
                        break;
                    default:
                        realRewardAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                        break;
                }
                AdManager.getInstance().onAdShowHandler(realRewardAdBean);
            }

            @Override
            public void onRewardedAdShowFail(AdError pAdError) {

            }

            @Override
            public void onRewardClick() {
                AdManager.getInstance().onAdClickHandler(realRewardAdBean);
            }

            @Override
            public void onRewardedAdClosed() {
                AdManager.getInstance().onAdRemoveCacheHandler(gmAdBean);
                AdManager.getInstance().onAdClosedHandler(realRewardAdBean);
            }

            @Override
            public void onVideoComplete() {
            }

            @Override
            public void onVideoError() {
                AdManager.getInstance().onAdLoadFailHandler(gmAdBean);
            }

            @Override
            public void onRewardVerify(RewardItem pRewardItem) {
                AdManager.getInstance().recordIsGetReward(pRewardItem.rewardVerify());
            }

            @Override
            public void onSkippedVideo() {
            }
        });
    }


    /**
     * 开屏广告
     */
    private static AdInfoEntity.AdBean realSplashAdBean = null;

    public static void showSplashAd(Activity pActivity, AdInfoEntity.AdBean gmAdBean) {
        TTSplashAd mTTSplashAd = new TTSplashAd(pActivity, gmAdBean.getAdId());
        mTTSplashAd.setTTAdSplashListener(new TTSplashAdListener() {
            @Override
            public void onAdClicked() {
                Log.i(TAG, "splash onAdClicked");
                AdManager.getInstance().onAdClickHandler(gmAdBean);
            }

            @Override
            public void onAdShow() {
                Log.i(TAG, "splash onAdShow");
                int ptId = mTTSplashAd.getAdNetworkPlatformId();
                String adId = mTTSplashAd.getAdNetworkRitId();

                realSplashAdBean = new AdInfoEntity.AdBean();
                realSplashAdBean.setAdGroupId(gmAdBean.getAdGroupId());
                realSplashAdBean.setAdType(gmAdBean.getAdType().getType());
                realSplashAdBean.setType(gmAdBean.getType().getType());
                realSplashAdBean.setValid(gmAdBean.isValid());
                realSplashAdBean.setPrice(Float.parseFloat(mTTSplashAd.getPreEcpm()) / 100);

                realSplashAdBean.setAdId(adId);

                Log.i("平台id", ptId + "");
                switch (ptId) {
                    case NetworkPlatformConst.SDK_NAME_PANGLE:
                        realSplashAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_GDT:
                        realSplashAdBean.setPlatform(AdPlatform.YLH.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_SIGMOB:
                        realSplashAdBean.setPlatform(AdPlatform.SM.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_KS:
                        realSplashAdBean.setPlatform(AdPlatform.KS.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_MT:
                        realSplashAdBean.setPlatform(AdPlatform.MT.getPlatformString());
                        break;
                    default:
                        realSplashAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                        break;
                }

                AdManager.getInstance().onAdShowHandler(realSplashAdBean);
            }

            @Override
            public void onAdShowFail(AdError pAdError) {
                Log.i(TAG, "splash onAdShowFail");
                AdManager.getInstance().onAdRemoveCacheHandler(gmAdBean);
                AdManager.getInstance().onAdClosedHandler(realSplashAdBean);
            }

            @Override
            public void onAdSkip() {
                //开发者处理跳转到APP主页面逻辑
                Log.i(TAG, "splash onAdSkip");
                AdManager.getInstance().onAdClosedHandler(realSplashAdBean);
            }

            @Override
            public void onAdDismiss() {
                Log.i(TAG, "splash onAdDismiss");
                AdManager.getInstance().onAdClosedHandler(realSplashAdBean);
            }
        });

        //step3:创建开屏广告请求参数AdSlot,具体参数含义参考文档
        AdSlot adSlot = new AdSlot.Builder()
                .setImageAdSize(1080, 1920)
                .build();

        //注：自定义兜底方案 选择使用
        //穿山甲兜底，参数分别是appId和adn代码位。注意第二个参数是代码位，而不是广告位。
        TTNetworkRequestInfo ttNetworkRequestInfo = new PangleNetworkRequestInfo("5162601", "887550058");

        //step4:请求广告，调用开屏广告异步请求接口，对请求回调的广告作渲染处理
        mTTSplashAd.loadAd(adSlot, ttNetworkRequestInfo, new TTSplashAdLoadCallback() {
            @Override
            public void onSplashAdLoadFail(AdError adError) {
                Log.d(TAG, adError.message);
                AdManager.getInstance().onAdLoadFailHandler(gmAdBean);
            }

            @Override
            public void onSplashAdLoadSuccess() {

                Log.i(TAG, "splash onSplashAdLoad");
                if (AdManager.getInstance().mSplashFl != null) {
                    AdManager.getInstance().onAdCacheHandler(null, gmAdBean);
                    mTTSplashAd.showAd(AdManager.getInstance().mSplashFl);
                } else {
                    //开发者处理跳转到APP主页面逻辑
                    AdManager.getInstance().onAdLoadFailHandler(gmAdBean);
                }
            }

            @Override
            public void onAdLoadTimeout() {
                AdManager.getInstance().onAdLoadFailHandler(gmAdBean);
            }
        }, 3000);
    }


    /**
     * 原生广告
     */

    private static AdInfoEntity.AdBean realNativeAdBean;

    public static void showNativeAd(Activity pActivity, AdInfoEntity.AdBean gmAdBean) {
        TTUnifiedNativeAd mTTAdNative;
        mTTAdNative = new TTUnifiedNativeAd(pActivity, gmAdBean.getAdId());

        AdSlot adSlot = new AdSlot.Builder()
                // **必传，表示请求的模板广告还是原生广告，AdSlot.TYPE_EXPRESS_AD：模板广告 ； AdSlot.TYPE_NATIVE_AD：原生广告**
                //* 备注
                //* 1: 如果是信息流自渲染广告，设置广告图片期望的图片宽高 ，不能为0
                //* 2:如果是信息流模板广告，宽度设置为希望的宽度，高度设置为0(0为高度选择自适应参数)
                .setAdStyleType(AdSlot.TYPE_EXPRESS_AD)
                //注：必填字段，单位dp 详情见上面备注解释
                .setImageAdSize(DpiUtils.getDPWidth() - DpiUtils.dipTopx(15), DpiUtils.dipTopx(320))
                .setAdCount(1)
                .build();

        //step3:请求广告，调用feed广告异步请求接口，加载到广告后，拿到广告素材自定义渲染
        mTTAdNative.loadAd(adSlot, new TTNativeAdLoadCallback() {
            @Override
            public void onAdLoaded(List<TTNativeAd> ads) {
                if (ads == null || ads.isEmpty()) {
                    TToast.show(pActivity, "on FeedAdLoaded: ad is null!");
                    return;
                }

                TTNativeAd lNativeAd = ads.get(0);

                lNativeAd.setDislikeCallback(pActivity, new TTDislikeCallback() {
                    @Override
                    public void onSelected(int pI, String pS) {
                        AdManager.getInstance().hideNative();
                    }

                    @Override
                    public void onCancel() {

                    }

                    @Override
                    public void onRefuse() {

                    }

                    @Override
                    public void onShow() {

                    }
                });

                lNativeAd.setTTNativeAdListener(new TTNativeAdListener() {
                    @Override
                    public void onAdClick() {
                        AdManager.getInstance().onAdClickHandler(realNativeAdBean);
                    }

                    @Override
                    public void onAdShow() {
                        int ptId = lNativeAd.getAdNetworkPlatformId();
                        String adId = lNativeAd.getAdNetworkRitId();

                        realNativeAdBean = new AdInfoEntity.AdBean();
                        realNativeAdBean.setAdGroupId(gmAdBean.getAdGroupId());
                        realNativeAdBean.setAdType(gmAdBean.getAdType().getType());
                        realNativeAdBean.setType(gmAdBean.getType().getType());
                        realNativeAdBean.setValid(gmAdBean.isValid());
                        realNativeAdBean.setPrice(Float.parseFloat(lNativeAd.getPreEcpm()) / 100);
                        realNativeAdBean.setAdId(adId);

                        Log.i("native 平台id", ptId + "");
                        Log.i("native 广告id", adId + "");

                        switch (ptId) {
                            case NetworkPlatformConst.SDK_NAME_PANGLE:
                                realNativeAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                                break;
                            case NetworkPlatformConst.SDK_NAME_GDT:
                                realNativeAdBean.setPlatform(AdPlatform.YLH.getPlatformString());
                                break;
                            case NetworkPlatformConst.SDK_NAME_SIGMOB:
                                realNativeAdBean.setPlatform(AdPlatform.SM.getPlatformString());
                                break;
                            case NetworkPlatformConst.SDK_NAME_KS:
                                realNativeAdBean.setPlatform(AdPlatform.KS.getPlatformString());
                                break;
                            case NetworkPlatformConst.SDK_NAME_MT:
                                realNativeAdBean.setPlatform(AdPlatform.MT.getPlatformString());
                                break;
                            default:
                                realNativeAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                                break;
                        }
                        AdManager.getInstance().onAdShowHandler(realNativeAdBean);
                    }
                });

                AdManager.getInstance().onAdCacheHandler(null, gmAdBean);

                RelativeLayout rootView = (RelativeLayout) View.inflate(pActivity, R.layout.nativead_layout, null);

                RelativeLayout expressRl = rootView.findViewById(R.id.native_ad_model_content);
                RelativeLayout nativeRl = rootView.findViewById(R.id.native_content_rl);

                if (lNativeAd.getExpressView() == null) {
                    Log.i("native", "自渲染");
                    expressRl.setVisibility(View.GONE);

                    AnimationDrawable lAnimationDrawable = (AnimationDrawable) ContextCompat.getDrawable(pActivity, R.drawable.ad_bg_anim);
                    nativeRl.setBackground(lAnimationDrawable);
                    lAnimationDrawable.start();

                    List<View> clickViewList = new ArrayList<>();
                    clickViewList.add(rootView);

                    List<View> creativeViewList = new ArrayList<>();
                    creativeViewList.add(rootView);

                    TTViewBinder viewBinder = new TTViewBinder.Builder(R.layout.nativead_layout)
                            .titleId(R.id.native_ad_title)
                            .decriptionTextId(R.id.native_ad_desc)
                            .mainImageId(R.id.native_ad_content_image_area)
                            .callToActionId(R.id.native_ad_model_content)
                            .build();

                    RelativeLayout contentArea = rootView.findViewById(R.id.native_ad_content_image_area);
                    TextView titleView = rootView.findViewById(R.id.native_ad_title);
                    TextView descView = rootView.findViewById(R.id.native_ad_desc);
                    TextView ctaView = rootView.findViewById(R.id.native_ad_install_btn);
                    ImageView close = rootView.findViewById(R.id.closeIv);
                    close.setOnClickListener(v -> AdManager.getInstance().hideNative());

                    titleView.setText(lNativeAd.getDescription());
                    descView.setText(lNativeAd.getTitle());
                    ctaView.setText((TextUtils.isEmpty(lNativeAd.getActionText()) ? "立即浏览" : lNativeAd.getActionText()));

                    RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                    lLayoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);

                    ImageView imageView = new ImageView(pActivity);
                    if (!TextUtils.isEmpty(lNativeAd.getImageUrl())) {
                        Log.i("native", "自渲染 图片地址：" + lNativeAd.getImageUrl());
                        Glide.with(pActivity).load(lNativeAd.getImageUrl()).into(imageView);
                    } else if (!lNativeAd.getImageList().isEmpty()) {
                        Log.i("native", "自渲染 图片地址：" + lNativeAd.getImageList().get(0));
                        Glide.with(pActivity).load(lNativeAd.getImageList().get(0)).into(imageView);
                    }

                    contentArea.addView(imageView, lLayoutParams);

                    lNativeAd.registerView(rootView, clickViewList, creativeViewList, viewBinder);

                } else {
                    Log.i("native", "模版渲染");
                    nativeRl.setVisibility(View.GONE);
                    rootView.findViewById(R.id.native_ad_install_btn).setVisibility(View.GONE);

                    RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lLayoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
                    expressRl.addView(lNativeAd.getExpressView(), lLayoutParams);

                    int padding = DpiUtils.dipTopx(5);
                    expressRl.setPadding(padding, padding, padding, padding);

                    AnimationDrawable lAnimationDrawable = (AnimationDrawable) ContextCompat.getDrawable(pActivity, R.drawable.ad_bg_anim);
                    rootView.setBackground(lAnimationDrawable);
                    lAnimationDrawable.start();
                }

                AdManager.getInstance().nativeRootFl.removeAllViews();
                AdManager.getInstance().nativeRootFl.addView(rootView);
                if (AdManager.getInstance().isShowNative) {
                    AdManager.getInstance().nativeRootFl.setVisibility(View.VISIBLE);
                } else {
                    AdManager.getInstance().nativeRootFl.setVisibility(View.GONE);
                }
                lNativeAd.render();
            }

            @Override
            public void onAdLoadedFial(AdError adError) {
                AdManager.getInstance().onAdLoadFailHandler(gmAdBean);
            }
        });
    }


    /**
     * banner
     */
    private static AdInfoEntity.AdBean realBannerAdBean;

    public static void showBannerAd(Activity pActivity, AdInfoEntity.AdBean gmAdBean) {
        TTBannerViewAd mTTBannerViewAd = new TTBannerViewAd(pActivity, gmAdBean.getAdId());
        mTTBannerViewAd.setRefreshTime(30);//设置轮播时间30S
        mTTBannerViewAd.setAllowShowCloseBtn(true);//如果广告本身允许展示关闭按钮，这里设置为true就是展示。注：目前只有mintegral支持。
        mTTBannerViewAd.setTTAdBannerListener(new TTAdBannerListener() {
            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdLeftApplication() {
            }

            @Override
            public void onAdClosed() {
                AdManager.getInstance().onAdClosedHandler(gmAdBean);
            }

            @Override
            public void onAdClicked() {
                AdManager.getInstance().onAdClickHandler(realBannerAdBean);
            }

            @Override
            public void onAdShow() {
                int ptId = mTTBannerViewAd.getAdNetworkPlatformId();
                String adId = mTTBannerViewAd.getAdNetworkRitId();

                realBannerAdBean = new AdInfoEntity.AdBean();
                realBannerAdBean.setAdGroupId(gmAdBean.getAdGroupId());
                realBannerAdBean.setAdType(gmAdBean.getAdType().getType());
                realBannerAdBean.setType(gmAdBean.getType().getType());
                realBannerAdBean.setValid(gmAdBean.isValid());
                realBannerAdBean.setPrice(Float.parseFloat(mTTBannerViewAd.getPreEcpm()) / 100);
                realBannerAdBean.setAdId(adId);

                Log.i("banner 平台id", ptId + "");
                Log.i("banner 广告id", adId + "");

                switch (ptId) {
                    case NetworkPlatformConst.SDK_NAME_PANGLE:
                        realBannerAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_GDT:
                        realBannerAdBean.setPlatform(AdPlatform.YLH.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_SIGMOB:
                        realBannerAdBean.setPlatform(AdPlatform.SM.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_KS:
                        realBannerAdBean.setPlatform(AdPlatform.KS.getPlatformString());
                        break;
                    case NetworkPlatformConst.SDK_NAME_MT:
                        realBannerAdBean.setPlatform(AdPlatform.MT.getPlatformString());
                        break;
                    default:
                        realBannerAdBean.setPlatform(AdPlatform.CSJ.getPlatformString());
                        break;
                }
                AdManager.getInstance().onAdShowHandler(realBannerAdBean);
            }

            @Override
            public void onAdShowFail(AdError pAdError) {
                AdManager.getInstance().onAdClosedHandler(gmAdBean);
            }
        });

        //step4:创建广告请求参数AdSlot,具体参数含义参考文档
        AdSlot adSlot = new AdSlot.Builder()
                // banner暂时只支持模版类型，必须手动设置为AdSlot.TYPE_EXPRESS_AD
                .setAdStyleType(AdSlot.TYPE_EXPRESS_AD)
                .setBannerSize(TTAdSize.BANNER_320_100)
                // 使用TTAdSize.BANNER_CUSTOME，可以通过setImageAdSize设置自定义大小
//                .setBannerSize(TTAdSize.BANNER_CUSTOME)
//                .setImageAdSize(600, 100)
                .build();

        //step5:请求广告，对请求回调的广告作渲染处理
        mTTBannerViewAd.loadAd(adSlot, new TTAdBannerLoadCallBack() {
            @Override
            public void onAdFailedToLoad(AdError adError) {
                Log.e(TAG, "banner onError " + adError.code + " | " + adError.message);
                AdManager.getInstance().onAdLoadFailHandler(gmAdBean);
                mTTBannerViewAd.destroy();
            }

            @Override
            public void onAdLoaded() {
                Log.i(TAG, "banner onNativeExpressAdLoad");
                AdManager.getInstance().onAdCacheHandler(null, gmAdBean);

                ViewGroup lViewGroup = (ViewGroup) mTTBannerViewAd.getBannerView().getParent();
                if (lViewGroup != null) {
                    lViewGroup.removeView(mTTBannerViewAd.getBannerView());
                }

                AdManager.getInstance().bannerRootFl.removeAllViews();
                FrameLayout.LayoutParams lLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                AdManager.getInstance().bannerRootFl.addView(mTTBannerViewAd.getBannerView());

                if (AdManager.getInstance().isShowBanner) {
                    AdManager.getInstance().bannerRootFl.setVisibility(View.VISIBLE);
                } else {
                    AdManager.getInstance().bannerRootFl.setVisibility(View.GONE);
                }
            }
        });
    }
}