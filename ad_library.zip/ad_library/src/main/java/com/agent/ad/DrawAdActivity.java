package com.agent.ad;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bytedance.sdk.openadsdk.TTNativeExpressAd;
import com.bytedance.sdk.openadsdk.core.nativeexpress.NativeExpressDrawVideoView;
import com.kwad.sdk.api.KsDrawAd;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.utils.AppUtils;
import com.agent.ad.utils.LogUtil;
import com.agent.adlibrary.R;

public class DrawAdActivity extends AppCompatActivity {
    private static final String TAG = "CSJDrawAdActivity";
    private RelativeLayout rootRl;
    private RelativeLayout skipRl;
    private TextView skipTv;
    private ImageView soundIv;

    private RelativeLayout adInfoRl;

    private NativeExpressDrawVideoView mVideoView;
    private View mKSVideoView;

    private AdInfoEntity.AdBean mAdBean;

    private int skipTime = 0;
    private boolean canSkip = false;


    private int showAppInfoTime = 5000;
    private boolean hadShowAppInfo = false;


    private boolean isMute = false;

    private TTNativeExpressAd mCSJDrawAd;
    private KsDrawAd mKSDrawAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppUtils.setStatusBarMode(this, true);

        setContentView(R.layout.activity_csj_draw_ad);

        initView();

        ImageView appLogo = findViewById(R.id.app_logo);
//        appLogo.setImageResource();

        mAdBean = (AdInfoEntity.AdBean) getIntent().getSerializableExtra("ad_info");
        if (mAdBean != null) {
            if (mAdBean.getPlatform()== AdPlatform.CSJ) {
                playCSJAd();
            } else if (mAdBean.getPlatform()== AdPlatform.KS) {
                playKSAd();
            } else {
                AdManager.getInstance().onAdClosedHandler(mAdBean);
                onBackPressed();
            }
        } else {
            AdManager.getInstance().onAdClosedHandler(mAdBean);
            onBackPressed();
        }
    }

    private void initView() {
        rootRl = findViewById(R.id.root_view);

        adInfoRl = findViewById(R.id.ad_info_rl);
        adInfoRl.setVisibility(View.INVISIBLE);

        skipRl = findViewById(R.id.skip_rl);
        skipRl.setVisibility(View.INVISIBLE);
        skipTv = findViewById(R.id.skip_tv);
        skipRl.setOnClickListener(v -> {
            if (canSkip) {
                AdManager.getInstance().onAdClosedHandler(mAdBean);
                onBackPressed();
            }
        });

        soundIv = findViewById(R.id.mute);
        soundIv.setOnClickListener(v -> {
            if (mVideoView != null) {
                isMute = !isMute;
                mVideoView.a(isMute);
                if (isMute) {
                    soundIv.setImageResource(R.mipmap.mute);
                } else {
                    soundIv.setImageResource(R.mipmap.not_mute);
                }
            }
        });
    }

    private void playCSJAd() {
        mCSJDrawAd = null;
        mCSJDrawAd = AdManager.getInstance().getCSJDrawAd();
        if (mCSJDrawAd == null) {
            AdManager.getInstance().onAdClosedHandler(mAdBean);
            onBackPressed();
            return;
        }
        AdManager.getInstance().recordIsGetReward(false, false);

        mCSJDrawAd.setVideoAdListener(new TTNativeExpressAd.ExpressVideoAdListener() {
            @Override
            public void onVideoLoad() {
                LogUtil.d("onVideoLoad");
            }

            @Override
            public void onVideoError(int pI, int pI1) {
                LogUtil.d("onVideoError");
            }

            @Override
            public void onVideoAdStartPlay() {
                LogUtil.d("onVideoAdStartPlay");
                AdManager.getInstance().recordIsGetReward(true, false);
            }

            @Override
            public void onVideoAdPaused() {
                LogUtil.d("onVideoAdPaused");
            }

            @Override
            public void onVideoAdContinuePlay() {
                LogUtil.d("onVideoAdContinuePlay");
            }

            @Override
            public void onProgressUpdate(long curr, long total) {
                if (canSkip) {
                    String string = (int) (total - curr) / 1000 + "s 点击跳过";
                    skipTv.setText(string);
                } else {
                    if (skipTime == 0) {
                        if (total > 15000) {
                            skipTime = 15000;
                        } else {
                            skipTime = (int) total;
                        }
                    }

                    String string = (int) (skipTime - curr) / 1000 + "s 后获得奖励";
                    skipTv.setText(string);
                    skipRl.setVisibility(View.VISIBLE);

                    if (curr >= skipTime) {
                        canSkip = true;
                    }
                }
            }

            @Override
            public void onVideoAdComplete() {
                LogUtil.d("onVideoAdComplete");
                skipTv.setText("关闭");
            }

            @Override
            public void onClickRetry() {
                LogUtil.d("onClickRetry");
            }
        });

        mCSJDrawAd.setExpressInteractionListener(new TTNativeExpressAd.AdInteractionListener() {
            @Override
            public void onAdDismiss() {
                Log.i(TAG, "draw onAdDismiss");
                AdManager.getInstance().onAdClosedHandler(mAdBean);
            }

            @Override
            public void onAdClicked(View pView, int pI) {
                Log.i(TAG, "draw onAdClicked");
                AdManager.getInstance().onAdClickHandler(mAdBean);
            }

            @Override
            public void onAdShow(View pView, int pI) {
                Log.i(TAG, "draw onAdShow");
                AdManager.getInstance().onAdShowHandler(mAdBean);
            }

            @Override
            public void onRenderFail(View pView, String msg, int code) {
                Log.e(TAG, "draw onRenderFail " + code + " | " + msg);
                AdManager.getInstance().onAdLoadFailHandler(mAdBean);
            }

            @Override
            public void onRenderSuccess(View pView, float width, float height) {
                Log.e(TAG, "draw onRenderSuccess " + width + " | " + height);
                mVideoView = (NativeExpressDrawVideoView) pView;
                if (mVideoView == null) {
                    AdManager.getInstance().onAdClosedHandler(mAdBean);
                    onBackPressed();
                    return;
                }

                RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                rootRl.addView(mVideoView, 0, lLayoutParams);
            }
        });

        mCSJDrawAd.render();
    }

    private void playKSAd() {
        mKSDrawAd = null;
        mKSDrawAd = AdManager.getInstance().getKSDrawAd();
        mKSVideoView = mKSDrawAd.getDrawView(this);
        if (mKSDrawAd == null || mKSVideoView == null) {
            AdManager.getInstance().onAdClosedHandler(mAdBean);
            onBackPressed();
            return;
        }
        AdManager.getInstance().recordIsGetReward(false, false);

        soundIv.setVisibility(View.GONE);
        skipRl.setVisibility(View.GONE);


        RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        rootRl.addView(mKSVideoView, 0, lLayoutParams);
        mKSDrawAd.setAdInteractionListener(new KsDrawAd.AdInteractionListener() {
            @Override
            public void onAdClicked() {
                AdManager.getInstance().onAdClickHandler(mAdBean);
            }

            @Override
            public void onAdShow() {
                AdManager.getInstance().onAdShowHandler(mAdBean);
            }

            @Override
            public void onVideoPlayStart() {
                LogUtil.d("onVideoAdStartPlay");
                AdManager.getInstance().recordIsGetReward(true, false);
            }

            @Override
            public void onVideoPlayPause() {

            }

            @Override
            public void onVideoPlayResume() {

            }

            @Override
            public void onVideoPlayEnd() {
                canSkip = true;
                skipTv.setText("关闭");
                skipRl.setVisibility(View.VISIBLE);
            }

            @Override
            public void onVideoPlayError() {
                canSkip = true;
                skipTv.setText("关闭");
                skipRl.setVisibility(View.VISIBLE);
            }
        });
    }

    private void showAppInfo() {
        hadShowAppInfo = true;
        adInfoRl.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}