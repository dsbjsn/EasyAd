package com.agent.ad.interfaces;

/**
 * Created on 2021/7/22 14
 *
 * @author xjl
 */
public interface AdListener {
    /**
     * 显示广告
     */
    void show();

    /**
     * 点击广告
     */
    void click();

    /**
     * 关闭广告
     */
    void close();

    /**
     * 广告错误
     */
    void error(String msg);
}
