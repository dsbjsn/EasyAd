package com.agent.ad;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

import com.bytedance.msdk.api.reward.TTRewardAd;
import com.bytedance.sdk.openadsdk.TTFullScreenVideoAd;
import com.bytedance.sdk.openadsdk.TTNativeExpressAd;
import com.bytedance.sdk.openadsdk.TTRewardVideoAd;
import com.google.gson.Gson;
import com.kwad.sdk.api.KsDrawAd;
import com.kwad.sdk.api.KsFullScreenVideoAd;
import com.kwad.sdk.api.KsRewardVideoAd;
import com.kwad.sdk.api.KsVideoPlayConfig;
import com.mbridge.msdk.interstitialvideo.out.MBInterstitialVideoHandler;
import com.mbridge.msdk.out.MBRewardVideoHandler;
import com.qq.e.ads.interstitial3.ExpressInterstitialAD;
import com.qq.e.ads.rewardvideo.RewardVideoAD;
import com.sigmob.windad.interstitial.WindInterstitialAd;
import com.sigmob.windad.rewardedVideo.WindRewardedVideoAd;
import com.tencent.klevin.ads.ad.RewardAd;
import com.wannuosili.sdk.WNRewardVideoAd;
import com.agent.ad.csj.TTAdControl;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.gromore.GroMoreControl;
import com.agent.ad.interfaces.AdListener;
import com.agent.ad.interfaces.FullAdListener;
import com.agent.ad.interfaces.ResultCallBack;
import com.agent.ad.interfaces.RewardAdListener;
import com.agent.ad.ks.KSAdControl;
import com.agent.ad.mintegral.MTAdControl;
import com.agent.ad.network.NetWorkUtil;
import com.agent.ad.oneway.OWAdControl;
import com.agent.ad.sigmob.SIGAdControl;
import com.agent.ad.utils.AppUtils;
import com.agent.ad.utils.SharedPreferencesUtil;
import com.agent.ad.yky.YKYAdControl;
import com.agent.ad.ylb.YLBAdControl;
import com.agent.ad.ylh.YLHAdControl;

import java.util.ArrayList;
import java.util.List;

import mobi.oneway.export.Ad.OWInterstitialAd;
import mobi.oneway.export.Ad.OWRewardedAd;

import static com.qq.e.comm.util.VideoAdValidity.VALID;
import static com.agent.ad.AdPlatform.*;

public class AdManager {
    private static final AdManager adMgr = new AdManager();

    private AdManager() {
    }

    public static AdManager getInstance() {
        return adMgr;
    }

    public static final String TAG = "自定义中介";
    public static final String TAG_CallBack = "自定义中介:广告回调 ";
    public static final String TAG_Reward = "自定义中介-reward";
    public static final String TAG_Banner = "自定义中介-banner";
    public static final String TAG_Native = "自定义中介-native";
    public static final String TAG_Full = "自定义中介-full";
    public static final String TAG_Splash = "自定义中介-splash";
    public static final String TAG_Interaction = "自定义中介-interaction";

    /**
     * 广告平台是否开启
     */
    public static boolean isYLBOpen = true;
    public static boolean isYLHOpen = true;
    public static boolean isCSJOpen = true;
    public static boolean isSMOpen = true;
    public static boolean isMTOpen = true;
    public static boolean isKSOpen = true;
    public static boolean isOWOpen = true;
    public static boolean isGMOpen = true;
    public static boolean isYKYOpen = true;

    /**
     * 网络加载的广告信息
     */
    private AdInfoEntity mAdInfoEntity;
    /**
     * 能否请求广告
     */
    private boolean canShowAd = true;
    /**
     * 总请求数
     */
    private int totalCount = 9999;
    /**
     * 今日请求数
     */
    private int todayCount = 0;

    /**
     * 检测用户广告数
     */
    private void checkAdCount() {
        canShowAd = todayCount < totalCount;
    }

    /**
     * 添加用户广告次数
     */
    private void addAdCount() {
        todayCount++;
        SharedPreferencesUtil.putInt("TodayCount", todayCount);
        Log.i(TAG, "用户今日请求数：" + todayCount);
        checkAdCount();
    }

    /**
     * 加载本地广告文件
     */
    public void loadLocalAdInfo() {
        if (TextUtils.isEmpty(AdConfig.getInstance().getLocalAdInfoJsonPath())) {
            if (AdConfig.getInstance().getResultCallBack() != null) {
                AdConfig.getInstance().getResultCallBack().fail("未配置本地广告json文件路径");
            }
        } else {
            String localAdInfo = AppUtils.getFileFromAssets(AdConfig.getInstance().getContext(), AdConfig.getInstance().getLocalAdInfoJsonPath());
            Log.i(TAG, "本地广告文件：" + localAdInfo.toString());
            if (TextUtils.isEmpty(localAdInfo)) {
                if (AdConfig.getInstance().getResultCallBack() != null) {
                    AdConfig.getInstance().getResultCallBack().fail("加载本地广告json文件失败");
                }
            } else {
                AdInfoEntity lAdInfoEntity = new Gson().fromJson(localAdInfo, AdInfoEntity.class);
                setAdInfo(lAdInfoEntity);
            }
        }
    }

    /**
     * 广告文件加载成功
     *
     * @param pAdInfoEntity
     */
    public void setAdInfo(AdInfoEntity pAdInfoEntity) {
        Log.i(TAG, "广告信息加载成功");

        mAdInfoEntity = pAdInfoEntity;

        for (AdInfoEntity.PlatformDataBean lBean : mAdInfoEntity.getPlatformData()) {
            switch (lBean.getPlatformType()) {
                case CSJ:
                    isCSJOpen = lBean.isIs_open();
                    break;
                case YLB:
                    isYLBOpen = lBean.isIs_open();
                    break;
                case YLH:
                    isYLHOpen = lBean.isIs_open();
                    break;
                case SM:
                    isSMOpen = lBean.isIs_open();
                    break;
                case MT:
                    isMTOpen = lBean.isIs_open();
                    break;
                case OW:
                    isOWOpen = lBean.isIs_open();
                    break;
                case KS:
                    isKSOpen = lBean.isIs_open();
                    break;
                case GM:
                    isGMOpen = lBean.isIs_open();
                    break;
                case YKY:
                    isYKYOpen = lBean.isIs_open();
                    break;
                default:
                    break;
            }
        }

        //激励视频 列表
        rewardList = mAdInfoEntity.getRewardList();
        //激励视频一次加载个数
        maxThreadNum = mAdInfoEntity.getMaxThreadNum();
        //激励视频缓存个数
        maxCacheNum = mAdInfoEntity.getConcurrentLoadNum();
        //优量宝一天最多展示次数
        maxYLBNum = mAdInfoEntity.getYlbMaxNum();
        checkYLBIsOpen();

        //全屏视频 列表
        fullList = mAdInfoEntity.getFullList();
        //全屏视频一次加载个数
        maxThreadNum_full = mAdInfoEntity.getMaxThreadNum();
        //全屏视频缓存个数
        maxCacheNum_full = mAdInfoEntity.getConcurrentLoadNum();

        //banner 列表
        bannerList = mAdInfoEntity.getBannerList();
        bannerRefreshRate = mAdInfoEntity.getBannerRefreshRate();

        //native 列表
        nativeList = mAdInfoEntity.getNativeList();
        bannerRefreshRate = mAdInfoEntity.getNativeRefreshRate();

        //splash 列表
        splashList = mAdInfoEntity.getSplashList();

        //interaction 列表
        interactionList = mAdInfoEntity.getInteractionList();

        //draw 列表
//        drawList = mAdInfoEntity.getDrawList();

        //广告平台初始化
        AdPlatformHelper.init(AdConfig.getInstance().getActivity(), mAdInfoEntity.getPlatformData());

        /*初始化成功回调*/
        if (AdConfig.getInstance().getResultCallBack() != null) {
            AdConfig.getInstance().getResultCallBack().success();
        }

        prepareLoadAds();
    }


    /**
     * 开始预加载激励视频和全屏视频
     */
    public void prepareLoadAds() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        if (AdConfig.getInstance().isRewardNeedVerify() && TextUtils.isEmpty(AdConfig.getInstance().getToken())) {
            Log.e(TAG, "用户token为空,不能预加载广告");
            return;
        }

        if (mAdInfoEntity == null) {
            Log.e(TAG, "广告信息为空，不能预加载广告");
            return;
        }

        Log.e(TAG, "开始预加载广告");

        prepareLoadRewardAds();
        prepareLoadFullAds();
    }


    /**
     * ******************************
     * ******  激励视频 start   ******
     * ******************************
     */

    /**
     * 激励视频加载次数
     */
    private int loadTimes = 0;
    /**
     * 激励视频广告信息集合
     */
    private List<AdInfoEntity.AdBean> rewardList = null;
    /**
     * 激励视频缓存个数
     */
    private int maxCacheNum = 1;
    /**
     * 激励视频最大并发请求个数
     */
    private int maxThreadNum = 1;
    /**
     * 激励视频加载结果返回个数
     */
    private int returnNum = 0;
    /**
     * 当前并发 发起的请求次数
     */
    private int totalReturnNum = 0;
    /**
     * 当循环所有广告位都未返回时，再次循环次数
     */
    private int repeatNum = 1;
    /**
     * 当前循环次数
     */
    private int currRepeatNum = 0;
    /**
     * 当前请求的广告位下标
     */
    private int currRewardIndex = 0;
    /**
     * 激励视频 缓存 广告
     */
    private List<Object> cacheRewardAdList = new ArrayList<>();
    /**
     * 激励视频 缓存 广告信息
     */
    private List<AdInfoEntity.AdBean> cacheRewardAdInfoList = new ArrayList<>();
    /**
     * 优量宝最大展示次数
     */
    private int maxYLBNum = 15;
    /**
     * 当日优量宝展示次数
     */
    private int todayYLBNum = 0;

    /**
     * 预加载激励视频
     */
    private void prepareLoadRewardAds() {
        Log.e(TAG_Reward, "开始预加载激励视频广告");
        reLoadRewardAds();
    }

    /**
     * 重新开始加载激励视频
     */
    private long startTime = 0;
    private boolean isLoading = false;

    private void reLoadRewardAds() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        if (rewardList == null || rewardList.isEmpty()) {
            Log.e(TAG_Reward, "广告列表为空，请先请求广告信息");
            return;
        }

        if (isLoading) {
            Log.e(TAG_Reward, "广告正在请求");
            return;
        }

        isLoading = true;

        startTime = System.currentTimeMillis();
        loadTimes = 0;
        currRepeatNum = 0;
        loadRewardAds();
    }

    private void loadRewardAds() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        totalReturnNum = 0;
        returnNum = 0;
        loadTimes += 1;

        int offset = (loadTimes * maxThreadNum) - rewardList.size();
        if (offset > 0) {
            totalReturnNum = maxThreadNum - offset;
        } else {
            totalReturnNum = maxThreadNum;
        }

        Log.i(TAG_Reward, "第" + loadTimes + "次请求，请求个数为:" + totalReturnNum);
        for (int i = 0; i < totalReturnNum; i++) {
            currRewardIndex = (loadTimes - 1) * maxThreadNum + i;
            if (currRewardIndex < rewardList.size()) {
                loadRewardVideo(currRewardIndex);
            }
        }
    }

    /**
     * 加载激励视频
     *
     * @param rewardIndex 请求的广告位下标
     */
    private void loadRewardVideo(int rewardIndex) {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }


        if (rewardList != null && rewardIndex < rewardList.size()) {
            AdInfoEntity.AdBean videoData = rewardList.get(rewardIndex);
            if (videoData != null) {
                if (!videoData.isValid()) {
                    Log.i(TAG_Reward, "无效广告位：" + rewardIndex + " - " + videoData.toString());
                    onAdLoadFailHandler(videoData);
                    return;
                }

                //不能缓存同一个id的广告位
                for (AdInfoEntity.AdBean lAdBean : cacheRewardAdInfoList) {
                    if (lAdBean.getPlatform().equals(videoData.getPlatform()) && lAdBean.getAdId().equals(videoData.getAdId())) {
                        Log.e(TAG_Reward, "广告位已加载,跳过：" + videoData.toString());
                        onAdLoadFailHandler(videoData);
                        return;
                    }
                }

                Log.i(TAG_Reward, "请求广告位信息：" + rewardIndex + " - " + videoData.toString());
                switch (videoData.getPlatform()) {
                    case CSJ:
                        if (isCSJOpen) {
                            addAdCount();
                            if (videoData.getAdType() == AdType.UN_KNOW || videoData.getAdType() == AdType.REWARD) {
                                TTAdControl.getInstance().loadRewardVideoAd(videoData);
                            } else if (videoData.getAdType() == AdType.FULL) {
                                TTAdControl.getInstance().loadFullVideoAd(videoData);
                            } else if (videoData.getAdType() == AdType.DRAW) {
                                TTAdControl.getInstance().loadDrawAd(videoData);
                            } else {
                                onAdLoadFailHandler(videoData);
                                return;
                            }
                        } else {
                            Log.e(TAG_Reward, "csj 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case GM:
                        if (isGMOpen) {
                            addAdCount();
                            GroMoreControl.loadRewardAd(AdConfig.getInstance().getActivity(), videoData);
                        } else {
                            Log.e(TAG_Reward, "gm 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case YKY:
                        if (isYKYOpen) {
                            addAdCount();
                            YKYAdControl.getInstance().loadRewardVideoAd(videoData);
                        } else {
                            Log.e(TAG_Reward, "yky 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case YLH:
                        if (isYLHOpen) {
                            addAdCount();
                            if (videoData.getAdType() == AdType.UN_KNOW || videoData.getAdType() == AdType.REWARD) {
                                YLHAdControl.getInstance().loadRewardVideoAd(videoData);
                            } else if (videoData.getAdType() == AdType.FULL) {
                                YLHAdControl.getInstance().loadFullVideoAd(AdConfig.getInstance().getActivity(), videoData);
                            } else {
                                onAdLoadFailHandler(videoData);
                                return;
                            }
                        } else {
                            Log.e(TAG_Reward, "ylh 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case YLB:
                        if (isYLBOpen) {
                            addAdCount();
                            YLBAdControl.getInstance().loadRewardVideoAd(videoData);
                        } else {
                            Log.e(TAG_Reward, "ylb 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case SM:
                        if (isSMOpen) {
                            addAdCount();
                            if (videoData.getAdType() == AdType.UN_KNOW || videoData.getAdType() == AdType.REWARD) {
                                SIGAdControl.getInstance().loadRewardVideoAd(AdConfig.getInstance().getActivity(), videoData);
                            } else if (videoData.getAdType() == AdType.FULL) {
                                SIGAdControl.getInstance().loadFullVideoAd(AdConfig.getInstance().getActivity(), videoData);
                            } else {
                                onAdLoadFailHandler(videoData);
                                return;
                            }
                        } else {
                            Log.e(TAG_Reward, "sigmob 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case MT:
                        if (isMTOpen) {
                            addAdCount();
                            MTAdControl.getInstance().loadRewardVideoAd(AdConfig.getInstance().getActivity(), videoData);
                        } else {
                            Log.e(TAG_Reward, "mintegral 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case OW:
                        if (isOWOpen) {
                            addAdCount();
                            if (videoData.getAdType() == AdType.UN_KNOW || videoData.getAdType() == AdType.REWARD) {
                                OWAdControl.getInstance().loadRewardVideoAd(AdConfig.getInstance().getActivity(), videoData);
                            } else if (videoData.getAdType() == AdType.FULL) {
                                OWAdControl.getInstance().loadFullVideoAd(AdConfig.getInstance().getActivity(), videoData);
                            } else {
                                onAdLoadFailHandler(videoData);
                                return;
                            }
                        } else {
                            Log.e(TAG_Reward, "oneway 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case KS:
                        if (isKSOpen) {
                            addAdCount();
                            if (videoData.getAdType() == AdType.UN_KNOW || videoData.getAdType() == AdType.REWARD) {
                                KSAdControl.getInstance().loadRewardVideoAd(videoData);
                            } else if (videoData.getAdType() == AdType.FULL) {
                                KSAdControl.getInstance().loadFullVideoAd(videoData);
                            } else if (videoData.getAdType() == AdType.DRAW) {
                                KSAdControl.getInstance().loadDrawVideoAd(videoData);
                            } else {
                                onAdLoadFailHandler(videoData);
                                return;
                            }
                        } else {
                            Log.e(TAG_Reward, "ks 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    default:
                        Log.e(TAG_Reward, "未知广告平台，跳过请求下一个");
                        onAdLoadFailHandler(videoData);
                        return;
                }
                NetWorkUtil.sendADEvent(videoData, AdAction.AD_ACTION_REQ);
            }
        } else {
            Log.e(TAG_Reward, "视频列表为空或全部请求完");
        }
    }


    /**
     * 穿山甲draw广告实例
     */
    private TTNativeExpressAd sCSJDrawAd = null;

    public TTNativeExpressAd getCSJDrawAd() {
        return sCSJDrawAd;
    }

    /**
     * 快手draw广告实例
     */
    private KsDrawAd sKSDrawAd = null;

    public KsDrawAd getKSDrawAd() {
        return sKSDrawAd;
    }

    /**
     * 激励视频回调
     */
    private RewardAdListener mSRewardAdListener = null;

    public void showRewardAd(Activity pActivity, RewardAdListener pRewardAdListener) {
        mSRewardAdListener = pRewardAdListener;

        if (!canShowAd) {
            if (mSRewardAdListener != null) {
                mSRewardAdListener.error("无法播放广告");
                mSRewardAdListener = null;
            }
            return;
        }

        if (pActivity == null) {
            if (mSRewardAdListener != null) {
                mSRewardAdListener.error("Activity 为空");
                mSRewardAdListener = null;
            }
            return;
        }


        if (cacheRewardAdList.isEmpty() || cacheRewardAdInfoList.isEmpty()) {
            reLoadRewardAds();
            if (mSRewardAdListener != null) {
                mSRewardAdListener.error("视频加载中，请稍后再试");
                mSRewardAdListener = null;
            }
        } else {
            for (AdInfoEntity.AdBean lAdBean : cacheRewardAdInfoList) {
                Log.i(TAG_Reward, "已缓存的视频信息:" + lAdBean.toString());
            }

            Object ad = cacheRewardAdList.get(0);
            AdInfoEntity.AdBean adInfo = cacheRewardAdInfoList.get(0);
            if (ad != null) {
                Log.i(TAG_Reward, "播放视频信息:" + adInfo.toString());
                /* ylb */
                if (ad instanceof WNRewardVideoAd) {
                    WNRewardVideoAd lRewardVideoAD = (WNRewardVideoAd) ad;
                    lRewardVideoAD.showRewardVideoAd(pActivity);
                }

                /* sigmob reward*/
                else if (ad instanceof WindRewardedVideoAd) {
                    WindRewardedVideoAd lRewardVideoAD = (WindRewardedVideoAd) ad;
                    if (lRewardVideoAD.isReady()) {
                        lRewardVideoAD.show(pActivity, null);
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }
                /* sigmob full*/
                else if (ad instanceof WindInterstitialAd) {
                    WindInterstitialAd lVideoAd = (WindInterstitialAd) ad;
                    if (lVideoAd.isReady()) {
                        lVideoAd.show(pActivity, null);
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }

                /* csj reward*/
                else if (ad instanceof TTRewardVideoAd) {
                    TTRewardVideoAd lRewardVideoAD = (TTRewardVideoAd) ad;
                    lRewardVideoAD.showRewardVideoAd(pActivity);
                }
                /* csj full*/
                else if (ad instanceof TTFullScreenVideoAd) {
                    TTFullScreenVideoAd lVideoAd = (TTFullScreenVideoAd) ad;
                    lVideoAd.showFullScreenVideoAd(pActivity);
                }
                /* csj reward*/
                else if (ad instanceof TTNativeExpressAd) {
                    sCSJDrawAd = (TTNativeExpressAd) ad;
                    Intent lIntent = new Intent(pActivity, DrawAdActivity.class);
                    lIntent.putExtra("ad_info", adInfo);
                    pActivity.startActivity(lIntent);
                }

                /* gromore */
                else if (ad instanceof TTRewardAd) {
                    TTRewardAd lTTRewardAd = (TTRewardAd) ad;
                    GroMoreControl.showRewardAd(pActivity, lTTRewardAd, adInfo);
                }

                /* yky */
                else if (ad instanceof RewardAd) {
                    RewardAd lRewardAd = (RewardAd) ad;
                    if (lRewardAd != null && lRewardAd.isValid()) {
                        YKYAdControl.getInstance().showRewardAd(lRewardAd, adInfo);
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }

                /* ylh reward*/
                else if (ad instanceof RewardVideoAD) {
                    RewardVideoAD lRewardVideoAD = (RewardVideoAD) ad;
                    if (lRewardVideoAD.checkValidity() == VALID) {
                        lRewardVideoAD.showAD(pActivity);
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }
                /* ylh full*/
                else if (ad instanceof ExpressInterstitialAD) {
                    ExpressInterstitialAD lExpressInterstitialAD = (ExpressInterstitialAD) ad;
                    lExpressInterstitialAD.showFullScreenAD(pActivity);
                }

                /* mintegral */
                else if (ad instanceof MBRewardVideoHandler) {
                    MBRewardVideoHandler lRewardVideoAD = (MBRewardVideoHandler) ad;
                    if (lRewardVideoAD.isReady()) {
                        lRewardVideoAD.show("1", AdConfig.getInstance().getToken());
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }
                /* oneway reward*/
                else if (ad instanceof OWRewardedAd) {
                    OWRewardedAd lOWRewardedAd = (OWRewardedAd) ad;
                    if (lOWRewardedAd.isReady()) {
                        lOWRewardedAd.show(pActivity);
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }
                /* oneway full*/
                else if (ad instanceof OWInterstitialAd) {
                    OWInterstitialAd lOWInteractiveAd = (OWInterstitialAd) ad;
                    if (lOWInteractiveAd.isReady()) {
                        lOWInteractiveAd.show(pActivity);
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }

                /* ks reward*/
                else if (ad instanceof KsRewardVideoAd) {
                    KsRewardVideoAd lKsRewardVideoAd = (KsRewardVideoAd) ad;
                    if (lKsRewardVideoAd.isAdEnable()) {
                        lKsRewardVideoAd.showRewardVideoAd(pActivity, new KsVideoPlayConfig.Builder().showLandscape(false).videoSoundEnable(true).build());
                    } else {
                        removeCachedRewardAd(adInfo);
                        showRewardAd(pActivity, pRewardAdListener);
                    }
                }
                /* ks full*/
                else if (ad instanceof KsFullScreenVideoAd) {
                    KsFullScreenVideoAd lKsFullScreenVideoAd = (KsFullScreenVideoAd) ad;
                    lKsFullScreenVideoAd.showFullScreenVideoAd(pActivity, new KsVideoPlayConfig.Builder().showLandscape(false).videoSoundEnable(true).build());
                }
                /* ks draw*/
                else if (ad instanceof KsDrawAd) {
                    sKSDrawAd = (KsDrawAd) ad;
                    Intent lIntent = new Intent(pActivity, DrawAdActivity.class);
                    lIntent.putExtra("ad_info", adInfo);
                    pActivity.startActivity(lIntent);
                } else {
                    removeCachedRewardAd(adInfo);
                    showRewardAd(pActivity, pRewardAdListener);
                }
            } else {
                Log.e(TAG_Reward, "当前播放视频信息为空，跳过播放下一个");
                removeCachedRewardAd(adInfo);
                showRewardAd(pActivity, pRewardAdListener);
            }
        }
    }

    /**
     * 获取广告信息通过广告位id
     *
     * @param id 广告位id
     */
    public AdInfoEntity.AdBean getBeanFormId(String id) {
        if (rewardList == null || rewardList.isEmpty()) {
            return null;
        }
        if (TextUtils.isEmpty(id)) {
            return null;
        }
        for (AdInfoEntity.AdBean lAdBean : rewardList) {
            if (lAdBean.getAdId().equals(id)) {
                return lAdBean;
            }
        }

        return null;
    }

    /**
     * 移除缓存中的激励视频
     *
     * @param pAdBean
     */
    private void removeCachedRewardAd(AdInfoEntity.AdBean pAdBean) {
        Log.i(TAG_Reward, "removeCachedRewardAd");

        if (cacheRewardAdInfoList != null && !cacheRewardAdInfoList.isEmpty()) {
            int index = -1;
            for (int i = 0; i < cacheRewardAdInfoList.size(); i++) {
                if (cacheRewardAdInfoList.get(i).getAdId().equals(pAdBean.getAdId())) {
                    index = i;
                    break;
                }
            }
            Log.i(TAG_Reward, "删除缓存广告:" + index + " | " + pAdBean.toString());

            if (index >= 0 && cacheRewardAdInfoList.size() > index) {
                cacheRewardAdList.remove(index);
                cacheRewardAdInfoList.remove(index);
            }

            for (AdInfoEntity.AdBean lAdBean : cacheRewardAdInfoList) {
                Log.i(TAG_Reward, "剩余缓存的视频信息:" + lAdBean.toString());
            }
        }
    }

    private boolean hadGet = false;
    private boolean hadResult = false;

    /**
     * 激励视频奖励回调
     *
     * @param isGet 是否获得奖励
     */
    public void recordIsGetReward(boolean isGet) {
        recordIsGetReward(isGet, true);
    }

    /**
     * 激励视频奖励回调
     *
     * @param isGet     是否获得奖励
     * @param hadResult 是否有回调
     */
    public void recordIsGetReward(boolean isGet, boolean hadResult) {
        hadGet = isGet;
        this.hadResult = hadResult;
    }

    /**
     * 返回是否获得奖励
     *
     * @param pAdBean
     */
    private void returnIsGetReward(AdInfoEntity.AdBean pAdBean) {
        Log.i(TAG_Reward, "是否获得奖励：" + hadGet + "平台是否有回调：" + hadResult);

        if (!AdConfig.getInstance().isRewardNeedVerify()) {
            callBackRewardListener();
        } else {
            if (hadResult) {
                callBackRewardListener();
            } else {
                NetWorkUtil.getRewardAdIsValid(pAdBean, new ResultCallBack() {
                    @Override
                    public void success() {
                        callBackRewardListener();
                    }

                    @Override
                    public void fail(String msg) {
                        callBackRewardListener();
                    }
                });
            }
        }
    }

    private void callBackRewardListener() {
        if (mSRewardAdListener != null) {
            mSRewardAdListener.onRewardVerify(hadGet);
            mSRewardAdListener = null;
        }
    }

    /**
     * 优量宝显示次数累加
     */
    private void addTodayYLBNum() {
        todayYLBNum += 1;
        SharedPreferencesUtil.putInt("todayYLBNum", todayYLBNum);
        checkYLBIsOpen();
    }

    /**
     * 检查优量宝显示次数是否到顶
     */
    private void checkYLBIsOpen() {
//        if (TimeUtil.isTheSameDay()) {
//            todayYLBNum = SharedPreferencesUtil.getInt("todayYLBNum", 0);
//        } else {
//            todayYLBNum = 0;
//        }
//
//        if (todayYLBNum >= maxYLBNum) {
//            isYLBOpen = false;
//        } else {
//            isYLBOpen = true;
//        }

        Log.i(TAG_Reward, "ylb 总次数=" + maxYLBNum + " 今日次数=" + todayYLBNum + " isYLBOpen=" + isYLBOpen);
    }

    /**
     * ******************************
     * ******  激励视频 end   ********
     * ******************************
     */


    /**
     * ******************************
     * ******  banner start   *******
     * ******************************
     */

    /**
     * banner广告信息集合
     */
    private List<AdInfoEntity.AdBean> bannerList = null;
    /**
     * 是否已经展示banner广告
     */
    private boolean hadLoadedBanner = false;
    /**
     * 当前显示的banner下标
     */
    private int bannerIndex = 0;
    /**
     * banner当前展示信息
     */
    private AdInfoEntity.AdBean mBannerAdBean = null;
    /**
     * banner刷新频率
     */
    private int bannerRefreshRate = 2;
    /**
     * banner已展示次数
     */
    private int showBannerTime = 0;
    /**
     * 当前banner是否应该显示
     */
    public boolean isShowBanner = false;

    public boolean isShowBanner() {
        return isShowBanner;
    }

    public void setShowBanner(boolean pShowBanner) {
        isShowBanner = pShowBanner;
    }

    /**
     * banner 容器
     */
    public FrameLayout bannerRootFl;

    public FrameLayout getBannerRootFl() {
        return bannerRootFl;
    }

    private Activity bannerActivity;

    /**
     * 显示banner
     */
    public void showBannerAd(Activity pActivity, FrameLayout pBannerRootFl) {
        bannerActivity = pActivity;
        bannerRootFl = pBannerRootFl;
        Log.i(TAG_Banner, "显示");
        if (bannerList == null || bannerList.isEmpty()) {
            Log.e(TAG_Banner, "banner广告列表为空，请先请求广告信息");
            return;
        }

        isShowBanner = true;
        int off = showBannerTime % bannerRefreshRate;
        Log.e(TAG_Banner, "刷新频率 = " + bannerRefreshRate + " showBannerTime = " + off);

        loadBanner();
        showBannerTime++;
    }

    /**
     * 隐藏banner
     */
    public void hideBanner() {
        Log.i(TAG_Banner, "隐藏");
        isShowBanner = false;
        if (bannerRootFl != null) {
            bannerRootFl.setVisibility(View.INVISIBLE);
        }

        if (mBannerAdBean != null) {
            onAdClosedHandler(mBannerAdBean);
        }

        bannerIndex = 0;
        TTAdControl.getInstance().destroyBanner();
        YLHAdControl.getInstance().destroyBanner();
        MTAdControl.getInstance().destroyBanner();
    }

    /**
     * 加载banner
     */
    private void loadBanner() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        if (bannerIndex < bannerList.size()) {
            mBannerAdBean = bannerList.get(bannerIndex);
            if (!mBannerAdBean.isValid()) {
                Log.i(TAG_Banner, "无效广告位：" + mBannerAdBean.toString());
                onAdLoadFailHandler(mBannerAdBean);
                return;
            }

            if (mBannerAdBean != null) {
                Log.i(TAG_Banner, "请求广告信息:" + mBannerAdBean.toString());
                switch (mBannerAdBean.getPlatform()) {
                    case CSJ:
                        if (isCSJOpen) {
                            TTAdControl.getInstance().showBanner(bannerActivity, mBannerAdBean);
                        } else {
                            Log.e(TAG_Banner, "csj 已停用");
                            onAdLoadFailHandler(mBannerAdBean);
                            return;
                        }
                        break;
                    case GM:
                        if (isGMOpen) {
                            GroMoreControl.showBannerAd(bannerActivity, mBannerAdBean);
                        } else {
                            Log.e(TAG_Banner, "gm 已停用");
                            onAdLoadFailHandler(mBannerAdBean);
                            return;
                        }
                        break;
                    case YLH:
                        if (isYLHOpen) {
                            YLHAdControl.getInstance().showBanner(bannerActivity, mBannerAdBean);
                        } else {
                            Log.e(TAG_Banner, "ylh 已停用");
                            onAdLoadFailHandler(mBannerAdBean);
                            return;
                        }
                        break;
                    case MT:
                        if (isMTOpen) {
                            MTAdControl.getInstance().showBanner(AdConfig.getInstance().getActivity(), mBannerAdBean);
                        } else {
                            Log.e(TAG_Banner, "mintegral 已停用");
                            onAdLoadFailHandler(mBannerAdBean);
                            return;
                        }
                        break;
                    default:
                        Log.e(TAG_Banner, "未知广告平台，跳过请求下一个");
                        bannerIndex += 1;
                        loadBanner();
                        break;
                }
                NetWorkUtil.sendADEvent(mBannerAdBean, AdAction.AD_ACTION_REQ);
            }
        } else {
            Log.e(TAG_Banner, "全部请求完，未成功");
            showBannerTime = 0;
            bannerIndex = 0;
            return;
        }
    }

    /**
     * ******************************
     * ******  banner end     *******
     * ******************************
     */


    /**
     * ******************************
     * ******  native start   *******
     * ******************************
     */

    /**
     * native广告信息集合
     */
    private List<AdInfoEntity.AdBean> nativeList = null;
    /**
     * 当前显示的native下标
     */
    private int nativeIndex = 0;
    /**
     * native当前展示信息
     */
    private AdInfoEntity.AdBean mNativeAdBean = null;
    /**
     * native刷新频率
     */
    private int nativeRefreshRate = 2;
    /**
     * native已展示次数
     */
    private int showNativeTime = 0;
    /**
     * 当前native是否应该显示
     */
    public boolean isShowNative = false;

    public boolean isShowNative() {
        return isShowNative;
    }

    public void setShowNative(boolean pShowNative) {
        isShowNative = pShowNative;
    }

    /**
     * native 容器
     */
    public FrameLayout nativeRootFl;

    public FrameLayout getNativeRootFl() {
        return nativeRootFl;
    }

    public void setNativeRootFl(FrameLayout pNativeRootFl) {
        nativeRootFl = pNativeRootFl;
    }

    private Activity nativeActivity;

    /**
     * 展示原生广告
     *
     * @param pActivity
     * @param pNativeRootFl
     */
    public void showNativeAd(Activity pActivity, FrameLayout pNativeRootFl) {
        nativeActivity = pActivity;
        nativeRootFl = pNativeRootFl;

        if (nativeList == null || nativeList.isEmpty()) {
            Log.e(TAG_Native, "列表为空，请先请求广告信息");
            return;
        }

        isShowNative = true;

//            if (showNativeTime % nativeRefreshRate != 0 ) {
//                nativeRootFl.setVisibility(View.VISIBLE);
//                nativeIndex = 0;
//            } else {
        loadNative();
//            }
        showNativeTime++;
    }

    /**
     * 隐藏原生广告
     */
    public void hideNative() {
        Log.e(TAG_Native, "隐藏");
        isShowNative = false;

        if (nativeRootFl != null) {
            nativeRootFl.setVisibility(View.GONE);
        }

        if (mNativeAdBean != null) {
            onAdClosedHandler(mNativeAdBean);
        }

        nativeIndex = 0;
    }

    /**
     * 加载原生广告
     */
    private void loadNative() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        if (nativeIndex < nativeList.size()) {
            mNativeAdBean = nativeList.get(nativeIndex);

            if (!mNativeAdBean.isValid()) {
                Log.i(TAG_Native, "无效广告位：" + mNativeAdBean.toString());
                onAdLoadFailHandler(mNativeAdBean);
                return;
            }

            if (mNativeAdBean != null) {
                Log.i(TAG_Native, "请求广告信息:" + mNativeAdBean.toString());
                switch (mNativeAdBean.getPlatform()) {
                    case CSJ:
                        if (isCSJOpen) {
                            TTAdControl.getInstance().showNative(nativeActivity, mNativeAdBean);
                        } else {
                            Log.e(TAG_Native, "csj 已停用");
                            onAdLoadFailHandler(mNativeAdBean);
                            return;
                        }
                        break;
                    case GM:
                        if (isGMOpen) {
                            GroMoreControl.showNativeAd(nativeActivity, mNativeAdBean);
                        } else {
                            Log.e(TAG_Native, "gm 已停用");
                            onAdLoadFailHandler(mNativeAdBean);
                            return;
                        }
                        break;
                    case YLH:
                        if (isYLHOpen) {
                            YLHAdControl.getInstance().showNative(nativeActivity, mNativeAdBean);
                        } else {
                            Log.e(TAG_Native, "ylh 已停用");
                            onAdLoadFailHandler(mNativeAdBean);
                            return;
                        }
                        break;
                    case KS:
                        if (isKSOpen) {
                            KSAdControl.getInstance().showNative(mNativeAdBean);
                        } else {
                            Log.e(TAG_Native, "ks 已停用");
                            onAdLoadFailHandler(mNativeAdBean);
                            return;
                        }
                        break;
                    default:
                        Log.e(TAG_Native, "未知广告平台，跳过请求下一个");
                        nativeIndex += 1;
                        loadNative();
                        return;
                }
                NetWorkUtil.sendADEvent(mNativeAdBean, AdAction.AD_ACTION_REQ);
            }
        } else {
            Log.e(TAG_Native, "全部请求完，未成功");
            showNativeTime = 0;
            nativeIndex = 0;
            return;
        }
    }

    /**
     * ******************************
     * ******  native end   *******
     * ******************************
     */


    /**
     * ******************************
     * ******  full end   *******
     * ******************************
     */

    /**
     * 全屏视频加载次数
     */
    private int loadTimes_full = 0;
    /**
     * 全屏视频广告信息集合
     */
    private List<AdInfoEntity.AdBean> fullList = null;
    /**
     * 全屏视频缓存个数
     */
    private int maxCacheNum_full = 3;
    /**
     * 全屏视频最大并发请求个数
     */
    private int maxThreadNum_full = 3;
    /**
     * 全屏视频加载结果返回个数
     */
    private int returnNum_full = 0;
    /**
     * 当前并发 发起的请求次数
     */
    private int totalReturnNum_full = 0;
    /**
     * 当循环所有广告位都未返回时，再次循环次数
     */
    private int repeatNum_full = 1;
    /**
     * 当前循环次数
     */
    private int currRepeatNum_full = 0;
    /**
     * 当前请求的广告位下标
     */
    private int currIndex_full = 0;

    /**
     * 全屏视频 缓存 广告
     */
    private List<Object> cacheFullAdList = new ArrayList<>();
    /**
     * 全屏视频 缓存 广告信息
     */
    private List<AdInfoEntity.AdBean> cacheFullAdInfoList = new ArrayList<>();

    private FullAdListener mFullAdListener;

    /**
     * 预加全屏视频
     */
    private void prepareLoadFullAds() {
        Log.e(TAG_Full, "开始预加载插屏广告");
        reLoadFullAds();
    }

    /**
     * 重新开始加载全屏视频
     */
    private long startTime_full = 0;

    private void reLoadFullAds() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        if (fullList == null || fullList.isEmpty()) {
            Log.e(TAG_Full, "列表为空，请先请求广告信息");
            return;
        }

        startTime_full = System.currentTimeMillis();
        loadTimes_full = 0;
        currRepeatNum_full = 0;
        loadFullAds();
    }

    private void loadFullAds() {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        totalReturnNum_full = 0;
        returnNum_full = 0;
        loadTimes_full += 1;

        int offset = (loadTimes_full * maxThreadNum_full) - fullList.size();
        if (offset > 0) {
            totalReturnNum_full = maxThreadNum_full - offset;
        } else {
            totalReturnNum_full = maxThreadNum_full;
        }
        for (int i = 0; i < maxThreadNum_full; i++) {
            currIndex_full = (loadTimes_full - 1) * maxThreadNum_full + i;
            if (currIndex_full < fullList.size()) {
                loadFullVideo(currIndex_full);
            }
        }
    }

    /**
     * 加载全屏视频
     *
     * @param index 请求的广告位下标
     */
    private void loadFullVideo(int index) {
        if (!canShowAd) {
            Log.e(TAG, "用户今日请求广告次数已超过上限，不再请求广告");
            return;
        }

        if (fullList != null && index < fullList.size()) {
            AdInfoEntity.AdBean videoData = fullList.get(index);
            if (videoData != null) {
                if (!videoData.isValid()) {
                    Log.i(TAG_Full, "无效广告位：" + videoData.toString());
                    onAdLoadFailHandler(videoData);
                    return;
                }

                //穿山甲广告不能缓存同一个id的广告位
                for (AdInfoEntity.AdBean lAdBean : cacheFullAdInfoList) {
                    if (lAdBean.getPlatform().equals(videoData.getPlatform()) && lAdBean.getAdId().equals(videoData.getAdId())) {
                        Log.e(TAG_Full, "广告位已加载,跳过：" + videoData.toString());
                        onAdLoadFailHandler(videoData);
                        return;
                    }
                }

                Log.i(TAG_Full, "请求广告信息：" + videoData.toString());
                switch (videoData.getPlatform()) {
                    case CSJ:
                        if (isCSJOpen) {
                            TTAdControl.getInstance().loadFullVideoAd(videoData);
                        } else {
                            Log.e(TAG_Full, "csj 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case YLH:
                        if (isYLHOpen) {
                            YLHAdControl.getInstance().loadFullVideoAd(AdConfig.getInstance().getActivity(), videoData);
                        } else {
                            Log.e(TAG_Full, "ylh 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case SM:
                        if (isSMOpen) {
                            SIGAdControl.getInstance().loadFullVideoAd(AdConfig.getInstance().getActivity(), videoData);
                        } else {
                            Log.e(TAG_Full, "sigmob 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case MT:
                        if (isMTOpen) {
                            MTAdControl.getInstance().loadFullVideoAd(AdConfig.getInstance().getContext(), videoData);
                        } else {
                            Log.e(TAG_Full, "mintegral 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    case KS:
                        if (isKSOpen) {
                            KSAdControl.getInstance().loadFullVideoAd(videoData);
                        } else {
                            Log.e(TAG_Full, "ks 已停用");
                            onAdLoadFailHandler(videoData);
                            return;
                        }
                        break;
                    default:
                        Log.e(TAG_Full, "未知广告平台，跳过请求下一个：" + videoData.toString());
                        onAdLoadFailHandler(videoData);
                        return;
                }

                NetWorkUtil.sendADEvent(videoData, AdAction.AD_ACTION_REQ);
            }
        } else {
            Log.e(TAG_Full, "视频列表为空或全部请求完");
        }
    }

    /**
     * 显示全屏视频
     *
     * @param pActivity
     * @param pFullAdListener
     */
    public void showFullAd(Activity pActivity, FullAdListener pFullAdListener) {
        mFullAdListener = pFullAdListener;

        if (pActivity == null) {
            if (mFullAdListener != null) {
                mFullAdListener.error("Activity 为空");
                mFullAdListener = null;
            }
            return;
        }

        if (cacheFullAdList.isEmpty() || cacheFullAdInfoList.isEmpty()) {
            reLoadFullAds();
        } else {
            for (AdInfoEntity.AdBean lAdBean : cacheFullAdInfoList) {
                Log.i(TAG_Full, "已缓存的视频信息:" + lAdBean.toString());
            }

            Object ad = cacheFullAdList.get(0);
            AdInfoEntity.AdBean adInfo = cacheFullAdInfoList.get(0);
            if (ad != null) {
                Log.i(TAG_Full, "播放的视频信息:" + adInfo.toString());
                /* Sigmob */
                if (ad instanceof WindInterstitialAd) {
                    WindInterstitialAd lVideoAd = (WindInterstitialAd) ad;
                    if (lVideoAd.isReady()) {
                        lVideoAd.show(pActivity, null);
                    } else {
                        removeCachedFullAd(adInfo);
                        showFullAd(pActivity, pFullAdListener);
                    }
                }
                /* CSJ */
                else if (ad instanceof TTFullScreenVideoAd) {
                    TTFullScreenVideoAd lVideoAd = (TTFullScreenVideoAd) ad;
                    lVideoAd.showFullScreenVideoAd(pActivity);
                }
                /* YLH */
                else if (ad instanceof ExpressInterstitialAD) {
                    ExpressInterstitialAD lExpressInterstitialAD = (ExpressInterstitialAD) ad;
                    lExpressInterstitialAD.showFullScreenAD(pActivity);
                }
                /* mintegral */
                else if (ad instanceof MBInterstitialVideoHandler) {
                    MBInterstitialVideoHandler lMBInterstitialVideoHandler = (MBInterstitialVideoHandler) ad;
                    if (lMBInterstitialVideoHandler.isReady()) {
                        lMBInterstitialVideoHandler.show();
                    } else {
                        removeCachedFullAd(adInfo);
                        showFullAd(pActivity, pFullAdListener);
                    }
                }
                /* KS */
                else if (ad instanceof KsFullScreenVideoAd) {
                    KsFullScreenVideoAd lKsFullScreenVideoAd = (KsFullScreenVideoAd) ad;
                    lKsFullScreenVideoAd.showFullScreenVideoAd(pActivity, new KsVideoPlayConfig.Builder().showLandscape(false).videoSoundEnable(true).build());
                } else {
                    removeCachedFullAd(adInfo);
                    showFullAd(pActivity, pFullAdListener);
                }
            } else {
                Log.e(TAG_Full, "当前播放的视频信息为空，跳过播放下一个");
                removeCachedFullAd(adInfo);
                showFullAd(pActivity, pFullAdListener);
            }
        }
    }

    /**
     * 获取全屏广告信息 通过广告id
     *
     * @param id
     * @return
     */
    public AdInfoEntity.AdBean getFullBeanFormId(String id) {
        if (fullList == null || fullList.isEmpty()) {
            return null;
        }
        if (TextUtils.isEmpty(id)) {
            return null;
        }
        for (AdInfoEntity.AdBean lAdBean : fullList) {
            if (lAdBean.getAdId().equals(id)) {
                return lAdBean;
            }
        }

        return null;
    }

    /**
     * 删除全屏广告
     *
     * @param pAdBean
     */
    private void removeCachedFullAd(AdInfoEntity.AdBean pAdBean) {
        if (cacheFullAdInfoList != null && !cacheFullAdInfoList.isEmpty()) {
            int index = cacheFullAdInfoList.indexOf(pAdBean);
            Log.i(TAG_Full, "删除缓存广告 " + pAdBean.toString());
            if (index >= 0 && cacheFullAdInfoList.size() > index) {
                cacheFullAdList.remove(index);
                cacheFullAdInfoList.remove(index);
            }

            for (AdInfoEntity.AdBean lAdBean : cacheFullAdInfoList) {
                Log.i(TAG_Full, "剩余缓存的视频信息:" + lAdBean.toString());
            }
        }
    }


    /**
     * ******************************
     * ******  full end   *******
     * ******************************
     */


    /**
     * ******************************
     * ******  splash start   *******
     * ******************************
     */

    /**
     * 开屏广告信息集合
     */
    private List<AdInfoEntity.AdBean> splashList = null;
    public FrameLayout mSplashFl;

    public FrameLayout getSplashFl() {
        return mSplashFl;
    }

    private boolean canSkip = true;
    private int index = 0;


    public void setSplashFl(FrameLayout pFl) {
        mSplashFl = pFl;
    }

    public AdListener splashAdListener;

    /**
     * 显示开屏广告
     */
    public void showSplash(AdListener pAdListener, FrameLayout pSplashFl) {
        splashAdListener = pAdListener;
        mSplashFl = pSplashFl;
        if (mSplashFl == null) {
            if (splashAdListener != null) {
                splashAdListener.error("开屏广告容器未空");
                splashAdListener = null;
            }

            return;
        }

        if (splashList == null || splashList.isEmpty() || index >= splashList.size()) {
            Log.e(TAG_Splash, "未加载到广告，不再请求");
            if (splashAdListener != null) {
                splashAdListener.error("未加载到广告");
                splashAdListener = null;
            }
            return;
        } else {
            canSkip = false;
            AdInfoEntity.AdBean lAdBean = splashList.get(index);
            index += 1;

            if (!lAdBean.isValid()) {
                Log.i(TAG_Splash, "无效广告位：" + lAdBean.toString());
                onAdLoadFailHandler(lAdBean);
                return;
            }

            switch (lAdBean.getPlatform()) {
                case CSJ:
                    if (isCSJOpen) {
                        TTAdControl.getInstance().showSplash(lAdBean);
                    } else {
                        Log.e(TAG_Splash, "csj 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;
                case GM:
                    if (isGMOpen) {
                        GroMoreControl.showSplashAd(AdConfig.getInstance().getActivity(), lAdBean);
                    } else {
                        Log.e(TAG_Splash, "gm 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;
                case YKY:
                    if (isYKYOpen) {
                        YKYAdControl.getInstance().showSplashAd(AdConfig.getInstance().getActivity(), lAdBean);
                    } else {
                        Log.e(TAG_Splash, "yky 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;
                case YLH:
                    if (isYLHOpen) {
                        YLHAdControl.getInstance().showSplash(AdConfig.getInstance().getActivity(), lAdBean);
                    } else {
                        Log.e(TAG_Splash, "ylh 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;
                case MT:
                    if (isMTOpen) {
                        MTAdControl.getInstance().showSplash(lAdBean);
                    } else {
                        Log.e(TAG_Splash, "mintegral 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;
                case KS:
                    if (isKSOpen) {
                        KSAdControl.getInstance().showSplash(AdConfig.getInstance().getActivity(), lAdBean);
                    } else {
                        Log.e(TAG_Splash, "ks 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;
                case SM:
                    if (isSMOpen) {
                        SIGAdControl.getInstance().showSplash(AdConfig.getInstance().getActivity(), lAdBean);
                    } else {
                        Log.e(TAG_Splash, "sigmob 已停用");
                        onAdLoadFailHandler(lAdBean);
                        return;
                    }
                    break;

                default:
                    onAdLoadFailHandler(lAdBean);
                    return;
            }
            Log.i(TAG_Splash, "请求广告信息：" + lAdBean.toString());
            NetWorkUtil.sendADEvent(lAdBean, AdAction.AD_ACTION_REQ);
        }
    }

    /**
     * ******************************
     * ******  splash end   *******
     * ******************************
     */


    /**
     * ******************************
     * ******  interaction start   *******
     * ******************************
     */
    public List<AdInfoEntity.AdBean> interactionList = null;

    public int interactionRate = 2;
    public int showInteractionTimes = 0;

    private Activity interactionActivity = null;
    private int interactionAdIndex = 0;

    public boolean canShowInteractionAd() {
        showInteractionTimes += 1;
        boolean canShow = showInteractionTimes % interactionRate == 0;
        return canShow;
    }

    public void showInteractionAd(Activity pActivity) {
        interactionActivity = pActivity;
        loadInteractionAd();
    }

    public void hideInteractionAd() {
        interactionActivity = null;
        interactionAdIndex = 0;
    }

    private void loadInteractionAd() {
        if (interactionActivity == null) {
            return;
        }

        if (interactionList == null || interactionList.isEmpty()) {
            Log.e(TAG_Interaction, "未加载到广告，不再请求");
            return;
        }

        if (interactionAdIndex >= interactionList.size()) {
            interactionAdIndex = 0;
        }

        AdInfoEntity.AdBean interactionAdBean = interactionList.get(interactionAdIndex);
        interactionAdIndex += 1;

        if (!interactionAdBean.isValid()) {
            Log.i(TAG_Interaction, "无效广告位：" + interactionAdBean.toString());
            onAdLoadFailHandler(interactionAdBean);
            return;
        }

        Log.i(TAG_Interaction, "请求广告信息：" + interactionAdBean.toString());

        switch (interactionAdBean.getPlatform()) {
            case CSJ:
                if (isCSJOpen) {
                    TTAdControl.getInstance().showInteraction(interactionActivity, interactionAdBean);
                } else {
                    Log.e(TAG_Interaction, "csj 已停用");
                    onAdLoadFailHandler(interactionAdBean);
                    return;
                }
                break;
            case YLH:
                if (isYLHOpen) {
                    YLHAdControl.getInstance().showInteraction(interactionActivity, interactionAdBean);
                } else {
                    Log.e(TAG_Interaction, "ylh 已停用");
                    onAdLoadFailHandler(interactionAdBean);
                    return;
                }
                break;
            case KS:
                if (isKSOpen) {
                    KSAdControl.getInstance().showInteraction(interactionActivity, interactionAdBean);
                } else {
                    Log.e(TAG_Interaction, "ks 已停用");
                    onAdLoadFailHandler(interactionAdBean);
                    return;
                }
                break;
            default:
                onAdLoadFailHandler(interactionAdBean);
                return;
        }

        NetWorkUtil.sendADEvent(interactionAdBean, AdAction.AD_ACTION_REQ);
    }
    /**
     * ******************************
     * ******  interaction end   *******
     * ******************************
     */


//    /**
//     * ******************************
//     * ******  draw start   *******
//     * ******************************
//     */
//    public  List<AdInfoEntity.AdBean> drawList = null;
//
//    public  void showDrawAd(Activity pActivity) {
//        Log.e(TAG, "showDrawAd");
//        if (drawList != null && !drawList.isEmpty()) {
//            if (isCSJOpen) {
//                NetWorkUtil.postADEvent(drawList.get(0), AD_ACTION_REQ);
//                TTAdControl.getInstance().loadDrawAd(pActivity,drawList.get(0));
//            } else {
//                Log.e(TAG_Interaction, "csj 已停用");
//            }
//        }
//    }

    /**
     * 加载成功处理函数
     *
     * @param object  广告对象
     * @param pAdBean 广告信息
     */
    public void onAdCacheHandler(Object object, AdInfoEntity.AdBean pAdBean) {
        if (pAdBean == null) {
            return;
        }

        Log.i(TAG_CallBack, "广告返回成功 " + pAdBean.toString());
        NetWorkUtil.sendADEvent(pAdBean, AdAction.AD_ACTION_RETURN);
        switch (pAdBean.getType()) {
            case REWARD:
                returnNum++;
                if (cacheRewardAdInfoList.contains(pAdBean)) {
                    return;
                } else {
                    boolean hadAdd = false;
                    for (AdInfoEntity.AdBean lAdBean : cacheRewardAdInfoList) {
                        if (pAdBean.getPrice() >= lAdBean.getPrice()) {
                            int index = cacheRewardAdInfoList.indexOf(lAdBean);
                            cacheRewardAdInfoList.add(index, pAdBean);
                            cacheRewardAdList.add(index, object);
                            hadAdd = true;
                            break;
                        }
                    }

                    if (!hadAdd) {
                        cacheRewardAdInfoList.add(pAdBean);
                        cacheRewardAdList.add(object);
                    }

                    String lStringBuilder = "返回结果：成功" +
                            " 结果数：" + returnNum + " - 总结果数：" + totalReturnNum +
                            " 缓存数：" + cacheRewardAdList.size() + " - 总缓存数：" + maxCacheNum +
                            " 广告位下标：" + rewardList.indexOf(pAdBean) +
                            " 广告位信息：" + pAdBean.toString();
                    Log.i(TAG_Reward, lStringBuilder);

                    Log.i(TAG_Reward, "缓存个数 =" + cacheRewardAdList.size() + " 总缓存个数=" + maxCacheNum);

                    if (cacheRewardAdList.size() < maxCacheNum) {
                        if (returnNum == totalReturnNum) {
                            Log.i(TAG_Reward, "isLoading = false 1");
                            isLoading = false;
                            new Handler().postDelayed(() -> reLoadRewardAds(), 100);
                        }
                    } else {
                        if (returnNum == totalReturnNum) {
                            Log.i(TAG_Reward, "isLoading = false 2");
                            isLoading = false;
                            Log.i(TAG_Reward, "请求完成，所用时间=" + (System.currentTimeMillis() - startTime) + "ms");
                        }
                    }
                }
                break;
            case FULL:
                returnNum_full++;
                if (cacheFullAdInfoList.contains(pAdBean)) {
                    return;
                } else {
                    boolean hadAdd = false;
                    for (AdInfoEntity.AdBean lAdBean : cacheFullAdInfoList) {
                        if (pAdBean.getPrice() >= lAdBean.getPrice()) {
                            int index = cacheFullAdInfoList.indexOf(lAdBean);
                            cacheFullAdInfoList.add(index, pAdBean);
                            cacheFullAdList.add(index, object);
                            hadAdd = true;
                            break;
                        }
                    }

                    if (!hadAdd) {
                        cacheFullAdInfoList.add(pAdBean);
                        cacheFullAdList.add(object);
                    }

                    String lStringBuilder = "返回结果：成功" +
                            " 结果数：" + returnNum_full + " - 总结果数：" + totalReturnNum_full +
                            " 缓存数：" + cacheFullAdList.size() + " - 总缓存数：" + maxCacheNum_full +
                            " 广告位下标：" + fullList.indexOf(pAdBean) +
                            " 广告位信息：" + pAdBean.toString();
                    Log.i(TAG_Full, lStringBuilder);

                    if (cacheFullAdList.size() < maxCacheNum_full) {
                        if (returnNum_full == totalReturnNum_full) {
                            reLoadFullAds();
                        }
                    } else {
                        Log.i(TAG_Full, "请求完成，所用时间=" + (System.currentTimeMillis() - startTime_full) + "ms");
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * 广告拉取失败
     *
     * @param pAdBean 广告信息
     */
    public void onAdLoadFailHandler(AdInfoEntity.AdBean pAdBean) {
        if (pAdBean == null) {
            Log.e(TAG, "请求失败，广告信息为空");
            return;
        }

        Log.i(TAG_CallBack, "广告返回失败 " + pAdBean.toString());

        switch (pAdBean.getType()) {
            case REWARD:
                returnNum++;
                String lRewardResult = "返回结果：失败" +
                        " 结果数：" + returnNum + " - 总结果数：" + totalReturnNum +
                        " 缓存数：" + cacheRewardAdList.size() + " - 总存数：" + maxCacheNum +
                        " 广告位下标：" + rewardList.indexOf(pAdBean) +
                        " 广告位信息：" + pAdBean.toString();

                Log.e(TAG_Reward, lRewardResult);

                if (cacheRewardAdList.size() < maxCacheNum) {
                    if (returnNum == totalReturnNum) {
                        if (currRewardIndex < rewardList.size() - 1) {
                            loadRewardAds();
                        } else {
                            Log.e(TAG_Reward, "广告加载失败 全部请求完成，未获取任何广告");
                            if (currRepeatNum < repeatNum) {
                                currRepeatNum++;
                                loadTimes = 0;
                                loadRewardAds();
                            }

                            Log.i(TAG_Reward, "isLoading = false 3");
                            isLoading = false;
                            Log.e(TAG_Reward, "请求完成，所用时间=" + (System.currentTimeMillis() - startTime) + "ms");
                        }
                    }
                } else {
                    if (returnNum == totalReturnNum) {
                        Log.i(TAG_Reward, "isLoading = false 4");
                        isLoading = false;
                        Log.i(TAG_Reward, "请求完成，所用时间=" + (System.currentTimeMillis() - startTime) + "ms");
                    }
                }
                break;
            case FULL:
                returnNum_full++;
                String lFullResult = "返回结果：失败" +
                        " 结果数：" + returnNum_full + " - 总结果数：" + totalReturnNum_full +
                        " 缓存数：" + cacheFullAdList.size() + " - 总存数：" + maxCacheNum_full +
                        " 广告位下标：" + fullList.indexOf(pAdBean) +
                        " 广告位信息：" + pAdBean.toString();
                Log.e(TAG_Full, lFullResult);

                if (returnNum_full == totalReturnNum_full) {
                    if (cacheFullAdList.size() < maxCacheNum_full) {
                        if (currIndex_full < fullList.size() - 1) {
                            loadFullAds();
                        } else {
                            Log.e(TAG_Full, "广告加载失败 全部请求完成，未获取任何广告");
                            if (currRepeatNum_full < repeatNum_full) {
                                currRepeatNum_full++;
                                loadTimes_full = 0;
                                loadFullAds();
                            }
                        }
                    }
                }
                break;
            case NATIVE:
                Log.e(TAG_Native, "请求失败，请求下一个");
                nativeIndex += 1;
                loadNative();
                break;
            case BANNER:
                Log.e(TAG_Banner, "请求失败，请求下一个");
                bannerIndex += 1;
                loadBanner();
                break;
            case SPLASH:
                Log.e(TAG_Splash, "请求失败，请求下一个");
                showSplash(splashAdListener, mSplashFl);
                break;
            case INTERACTION:
                if (interactionAdIndex == interactionList.size()) {
                    Log.e(TAG_Interaction, "全部请求失败");
                } else {
                    Log.e(TAG_Interaction, "请求失败，请求下一个");
                    loadInteractionAd();
                }
                break;
            default:
                break;
        }
    }


    /**
     * 广告展示事件
     *
     * @param pAdBean 广告信息
     */
    public void onAdShowHandler(AdInfoEntity.AdBean pAdBean) {
        Log.i(TAG_CallBack, "展示广告:" + pAdBean.toString());
        NetWorkUtil.sendADEvent(pAdBean, AdAction.AD_ACTION_REVEAL);

        switch (pAdBean.getType()) {
            case REWARD:
                AppUtils.refreshOldList(AdConfig.getInstance().getActivity());
                if (pAdBean.getPlatform() == YLB) {
                    addTodayYLBNum();
                }

                if (pAdBean.getAdType() == AdType.FULL) {
                    recordIsGetReward(true, false);
                }

                /*展示回调*/
                if (mSRewardAdListener != null) {
                    mSRewardAdListener.show();
                }
                break;
            case FULL:
                /*展示回调*/
                if (mFullAdListener != null) {
                    mFullAdListener.show();
                }
                break;
            case INTERACTION:
                interactionAdIndex = 0;
                break;
            case SPLASH:
                /*展示回调*/
                if (splashAdListener != null) {
                    splashAdListener.show();
                }
                break;
            default:
                break;
        }
    }


    /**
     * 广告点击事件
     *
     * @param pAdBean 广告信息
     */
    public void onAdClickHandler(AdInfoEntity.AdBean pAdBean) {
        Log.i(TAG_CallBack, "点击广告 " + pAdBean.toString());

        NetWorkUtil.sendADEvent(pAdBean, AdAction.AD_ACTION_CLICK);

        switch (pAdBean.getType()) {
            case REWARD:
                /*点击回调*/
                if (mSRewardAdListener != null) {
                    mSRewardAdListener.click();
                }
                break;
            case FULL:
                /*点击回调*/
                if (mFullAdListener != null) {
                    mFullAdListener.click();
                }
                break;
            case SPLASH:
                /*点击回调*/
                if (splashAdListener != null) {
                    splashAdListener.click();
                }
                break;
            default:
                break;
        }
    }

    /**
     * 移除已播放的广告缓存
     *
     * @param pAdBean 广告信息
     */
    public void onAdRemoveCacheHandler(AdInfoEntity.AdBean pAdBean) {
        if (pAdBean == null) {
            return;
        }
        Log.i(TAG_CallBack, "移除广告 " + pAdBean.toString());
        switch (pAdBean.getType()) {
            case REWARD:
                removeCachedRewardAd(pAdBean);
                break;
            case FULL:
                removeCachedFullAd(pAdBean);
                break;
            default:
                break;
        }
    }

    /**
     * 广告展关闭事件
     *
     * @param pAdBean 广告信息
     */
    public void onAdClosedHandler(AdInfoEntity.AdBean pAdBean) {
        Log.i(TAG_CallBack, "关闭广告 " + pAdBean.getType());

        switch (pAdBean.getType()) {
            case REWARD:
                removeCachedRewardAd(pAdBean);
                if (cacheRewardAdList.size() < maxCacheNum) {
                    reLoadRewardAds();
                }
                returnIsGetReward(pAdBean);

                /*关闭回调*/
                if (mSRewardAdListener != null) {
                    mSRewardAdListener.close();
                }
                break;
            case FULL:
                removeCachedFullAd(pAdBean);
                if (cacheFullAdList.size() < maxCacheNum) {
                    reLoadFullAds();
                }

                /*关闭回调*/
                if (mFullAdListener != null) {
                    mFullAdListener.close();
                    mFullAdListener = null;
                }
                break;
            case DRAW:
                returnIsGetReward(pAdBean);
                break;
            case SPLASH:
                /*关闭回调*/
                if (splashAdListener != null) {
                    splashAdListener.close();
                    splashAdListener = null;
                }
                break;
            default:
                break;
        }
    }
}
