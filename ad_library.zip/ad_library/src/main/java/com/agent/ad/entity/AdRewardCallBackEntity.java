package com.agent.ad.entity;

/**
 * Created on 2021/5/14 16
 *
 * @author xjl
 */
public class AdRewardCallBackEntity {

    /**
     * isValid : false
     */

    private Boolean isValid;

    public Boolean isIsValid() {
        return isValid;
    }

    public void setIsValid(Boolean isValid) {
        this.isValid = isValid;
    }
}
