package com.agent.ad.yky;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.tencent.klevin.ads.ad.NativeAd;
import com.tencent.klevin.ads.ad.NativeAdRequest;
import com.tencent.klevin.ads.ad.RewardAd;
import com.tencent.klevin.ads.ad.RewardAdRequest;
import com.tencent.klevin.ads.ad.SplashAd;
import com.tencent.klevin.ads.ad.SplashAdRequest;
import com.agent.ad.AdManager;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.adlibrary.R;

import java.util.ArrayList;
import java.util.List;

public class YKYAdControl {
    private static final String TAG = "YKYAdControl";
    private volatile static YKYAdControl instance = null;

    private YKYAdControl() {
    }

    //安全线程单例
    public static YKYAdControl getInstance() {
        if (instance == null) {
            synchronized (YKYAdControl.class) {
                if (instance == null) {
                    instance = new YKYAdControl();
                }
            }
        }
        return instance;
    }

    /**
     * 播放开屏广告
     *
     * @param pActivity
     * @param pAdBean
     */
    public void showSplashAd(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YKYAdMgHolder.hadInit) {
            Log.e(TAG, "splash 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        SplashAdRequest.Builder splashAdBuilder = new SplashAdRequest.Builder();
        splashAdBuilder.setWaitTime(5000)// 【可选】默认不限制，可传值范围[3000-5000]
                .setAdCount(1)//【可选】广告个数，默认1
                .setPosId(Long.parseLong(pAdBean.getAdId()));

        //开屏广告加载回调
        SplashAd.load(splashAdBuilder.build(), new SplashAd.SplashAdLoadListener() {
            public void onTimeOut() { //加载超时
                Log.e(TAG, "splash ad load timeout");
            }

            public void onAdLoadError(int err, String msg) {
                // 加载失败，err是错误码，msg是描述信息
                Log.e(TAG, "splash ad load err: " + err + " " + msg);
            }

            public void onAdLoaded(SplashAd mSplashAd) {
                //加载成功，ad为开屏广告实例
                Log.i(TAG, "splash ad loaded");
                if (mSplashAd != null && mSplashAd.isValid()) {
                    //设置开屏广告展示回调
                    mSplashAd.setListener(new SplashAd.SplashAdListener() {
                        public void onAdSkip() {
                            Log.i(TAG, "splash onAdSkip");
                        }

                        public void onAdShow() {
                            Log.i(TAG, "splash onAdShow");
                            AdManager.getInstance().onAdShowHandler(pAdBean);
                        }

                        public void onAdClick() {
                            Log.i(TAG, "splash onAdClick");
                            AdManager.getInstance().onAdClickHandler(pAdBean);
                        }

                        public void onAdClosed() {
                            Log.i(TAG, "splash onAdClosed");
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                        }

                        public void onAdError(int err, String msg) {
                            Log.e(TAG, "splash onAdError err: " + err + " " + msg);
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                        }
                    });
                    mSplashAd.show();
                } else {
                    Log.e(TAG, "splash 广告未准备好");
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }
        });
    }

    /**
     * 加载激励视频
     *
     * @param pAdBean
     */
    public void loadRewardVideoAd(final AdInfoEntity.AdBean pAdBean) {
        if (!YKYAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        String adId = pAdBean.getAdId();

        RewardAdRequest.Builder rewardAdBuilder = new RewardAdRequest.Builder();
        rewardAdBuilder.autoMute(false)
                .setPosId(Long.parseLong(adId))
                .setAdCount(1);

        RewardAd.load(rewardAdBuilder.build(), new RewardAd.RewardAdLoadListener() {
            public void onAdLoadError(int err, String msg) {
                Log.e(TAG, "reward ad load err: " + err + " " + msg);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            public void onVideoPrepared(RewardAd ad) {
                Log.i(TAG, "reward video prepared");
            }

            public void onAdLoaded(RewardAd ad) {
                Log.i(TAG, "reward ad loaded");
                AdManager.getInstance().onAdCacheHandler(ad, pAdBean);
            }
        });
    }

    /**
     * 播放激励视频
     *
     * @param pRewardAd
     * @param pAdBean
     */
    public void showRewardAd(RewardAd pRewardAd, AdInfoEntity.AdBean pAdBean) {
        pRewardAd.setListener(new RewardAd.RewardAdListener() {
            @Override
            public void onAdSkip() {

            }

            @Override
            public void onReward() {
                Log.i(TAG, "reward");
                AdManager.getInstance().recordIsGetReward(true, false);
            }

            @Override
            public void onVideoComplete() {

            }

            @Override
            public void onAdShow() {
                Log.i(TAG, "reward onAdShow");
                AdManager.getInstance().onAdShowHandler(pAdBean);
            }

            @Override
            public void onAdClick() {
                Log.i(TAG, "reward onAdClick");
                AdManager.getInstance().onAdClickHandler(pAdBean);
            }

            @Override
            public void onAdClosed() {
                Log.i(TAG, "reward onAdClose");
                AdManager.getInstance().onAdClosedHandler(pAdBean);
            }

            @Override
            public void onAdError(int pI, String pS) {
                Log.e(TAG, "reward onVideoError");
                AdManager.getInstance().recordIsGetReward(false, false);
            }
        });

        pRewardAd.show();
    }

    /**
     * 显示原生广告
     *
     * @param pActivity
     * @param pAdBean
     */
    public void showNativeAd(Activity pActivity, AdInfoEntity.AdBean pAdBean) {
        if (!YKYAdMgHolder.hadInit) {
            Log.e(TAG, "native 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        NativeAdRequest.Builder builder = new NativeAdRequest.Builder();
        builder.setPosId(Long.parseLong(pAdBean.getAdId()))
                .setAdCount(1);

        NativeAd.load(builder.build(), new NativeAd.NativeAdLoadListener() {
            @Override
            public void onAdLoadError(int err, String msg) {
                //加载失败，err 是错误码，msg 是描述信息
                Log.e(TAG, "err: " + err + " " + msg);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onAdLoaded(List<NativeAd> ads) {
                //加载成功，参数 ads 为自渲染广告数组实例
                Log.i(TAG, "native ad loaded");

                if (ads != null && !ads.isEmpty()) {
                    AdManager.getInstance().onAdCacheHandler(null, pAdBean);

                    NativeAd lNativeAd = ads.get(0);
                    RelativeLayout rootView = (RelativeLayout) View.inflate(pActivity, R.layout.nativead_layout, null);

                    RelativeLayout expressRl = rootView.findViewById(R.id.native_ad_model_content);
                    RelativeLayout nativeRl = rootView.findViewById(R.id.native_content_rl);

                    expressRl.setVisibility(View.GONE);

                    AnimationDrawable lAnimationDrawable = (AnimationDrawable) ContextCompat.getDrawable(pActivity, R.drawable.ad_bg_anim);
                    nativeRl.setBackground(lAnimationDrawable);
                    lAnimationDrawable.start();

                    List<View> clickViewList = new ArrayList<>();
                    clickViewList.add(rootView);

                    RelativeLayout contentArea = rootView.findViewById(R.id.native_ad_content_image_area);
                    TextView titleView = rootView.findViewById(R.id.native_ad_title);
                    TextView descView = rootView.findViewById(R.id.native_ad_desc);
                    TextView ctaView = rootView.findViewById(R.id.native_ad_install_btn);
                    ImageView close = rootView.findViewById(R.id.closeIv);
                    close.setOnClickListener(v -> AdManager.getInstance().hideNative());

                    titleView.setText(lNativeAd.getDescription());
                    descView.setText(lNativeAd.getTitle());
                    ctaView.setText((TextUtils.isEmpty(lNativeAd.getDownloadButtonLabel()) ? "立即浏览" : lNativeAd.getDownloadButtonLabel()));

                    RelativeLayout.LayoutParams lLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                    lLayoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);

                    if (lNativeAd.getMediaMode() == NativeAd.MEDIA_MODE_IMAGE) {
                        ImageView imageView = new ImageView(pActivity);
                        if (!lNativeAd.getImageList().isEmpty()) {
                            Log.i("native", "自渲染 图片地址：" + lNativeAd.getImageList().get(0));
                            Glide.with(pActivity).load(lNativeAd.getImageList().get(0)).into(imageView);
                        } else {
                            Glide.with(pActivity).load(lNativeAd.getIcon()).into(imageView);
                        }
                        contentArea.addView(imageView, lLayoutParams);
                    } else {
                        contentArea.addView(lNativeAd.getAdView(), lLayoutParams);
                    }

                    lNativeAd.registerAdInteractionViews(pActivity, rootView, clickViewList, new NativeAd.AdInteractionListener() {
                        @Override
                        public void onAdShow(NativeAd pNativeAd) {
                            Log.i(TAG, "native show");
                            AdManager.getInstance().onAdShowHandler(pAdBean);
                        }

                        @Override
                        public void onAdClick(NativeAd pNativeAd, View pView) {
                            Log.i(TAG, "native click");
                            AdManager.getInstance().onAdClickHandler(pAdBean);
                        }

                        @Override
                        public void onAdError(NativeAd pNativeAd, int pI, String pS) {
                            Log.i(TAG, "native error");
                            AdManager.getInstance().onAdClosedHandler(pAdBean);
                        }
                    });

                    AdManager.getInstance().nativeRootFl.removeAllViews();
                    AdManager.getInstance().nativeRootFl.addView(rootView);

                    if (AdManager.getInstance().isShowNative) {
                        AdManager.getInstance().nativeRootFl.setVisibility(View.VISIBLE);
                    } else {
                        AdManager.getInstance().nativeRootFl.setVisibility(View.GONE);
                    }
                } else {
                    Log.i(TAG, "native ads isEmpty");
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                }
            }
        });
    }
}
