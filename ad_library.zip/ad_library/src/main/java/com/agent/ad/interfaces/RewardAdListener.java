package com.agent.ad.interfaces;

/**
 * @author xjl
 * @time 2020/12/3 19:00
 * @remark 激励视频播放完成回调
 */

public interface RewardAdListener extends AdListener {
    /**
     * 是否获得奖励
     *
     * @param isVerify
     */
    void onRewardVerify(boolean isVerify);
}
