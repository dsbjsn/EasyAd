package com.agent.ad.ylb;

import android.util.Log;

import com.wannuosili.sdk.WNAdConstant;
import com.wannuosili.sdk.WNAdSdk;
import com.wannuosili.sdk.WNAdSlot;
import com.wannuosili.sdk.WNRewardVideoAd;
import com.agent.ad.AdConfig;
import com.agent.ad.entity.AdInfoEntity;
import com.agent.ad.AdManager;

public class YLBAdControl {
    private static final String TAG = "YLB";
    private volatile static YLBAdControl instance = null;

    private YLBAdControl() {
    }

    //安全线程单例
    public static YLBAdControl getInstance() {
        if (instance == null) {
            synchronized (YLBAdControl.class) {
                if (instance == null) {
                    instance = new YLBAdControl();
                }
            }
        }
        return instance;
    }

    /**
     * 加载激励视频广告
     */
    public void loadRewardVideoAd(final AdInfoEntity.AdBean pAdBean) {
        if (!YLBAdMgHolder.hadInit) {
            Log.e(TAG, "reward 平台未初始化");
            AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            return;
        }

        String adId = pAdBean.getAdId();
        WNAdSlot.Builder lBuilder = new WNAdSlot.Builder();
        lBuilder.setSlotId(adId);
        lBuilder.setOrientation(WNAdConstant.REWARD_VIDEO_AD_PORTRAIT);
        lBuilder.setUserId(AdConfig.getInstance().getToken());
        lBuilder.setMediaExtra(AdConfig.getInstance().getToken());
        WNAdSlot slot = lBuilder.build();

        WNAdSdk.getAdManager().loadRewardVideoAd(slot, new WNRewardVideoAd.RewardVideoAdListener() {
            @Override
            public void onError(int code, String message) {
                Log.e(TAG, "reward onError " + code + " | " + message);
                AdManager.getInstance().onAdLoadFailHandler(pAdBean);
            }

            @Override
            public void onLoad(WNRewardVideoAd ad) {
                if (ad == null) {
                    AdManager.getInstance().onAdLoadFailHandler(pAdBean);
                    return;
                }

                Log.i(TAG, "reward onLoad");

                ad.setInteractionListener(new WNRewardVideoAd.InteractionListener() {
                    @Override
                    public void onAdShow() {
                        Log.i(TAG, "reward onAdShow");
                        AdManager.getInstance().onAdShowHandler(pAdBean);
                    }

                    @Override
                    public void onAdClick() {
                        Log.i(TAG, "reward onAdClick");
                        AdManager.getInstance().onAdClickHandler(pAdBean);
                    }

                    @Override
                    public void onAdClose() {
                        Log.i(TAG, "reward onAdClose");
                        AdManager.getInstance().onAdClosedHandler(pAdBean);
                    }

                    @Override
                    public void onVideoComplete() {
                        Log.i(TAG, "reward onVideoComplete");
                    }

                    /**
                     * 此方法在激励视频广告完播后触发，rewardVerify默认为true，如果接入方使用了
                     * 服务端奖励验证回调功能，rewardVerify由接入方控制，为接入方在优量宝控制台
                     * 配置的回调链接返回的判定结果
                     *
                     * @param rewardVerify 是否发放奖励，默认为true
                     * @param rewardAmount 优量宝控制台配置的奖励数量，比如100，默认为0
                     * @param rewardName 优量宝控制台配置的奖励名称，比如游戏币, 默认为空字符串
                     */
                    @Override
                    public void onRewardVerify(boolean rewardVerify, int rewardAmount, String rewardName) {
                        Log.i(TAG, "reward onRewardVerify " + rewardVerify);
                        AdManager.getInstance().recordIsGetReward(rewardVerify);
                    }
                });

                AdManager.getInstance().onAdCacheHandler(ad, pAdBean);
            }
        });
    }
}
