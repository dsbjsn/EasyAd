package com.agent.ad.ks;

import android.content.Context;
import android.text.TextUtils;

import com.kwad.sdk.api.KsAdSDK;
import com.kwad.sdk.api.SdkConfig;
import com.agent.ad.AdConfig;
import com.agent.ad.utils.LogUtil;
import com.agent.adlibrary.R;

/**
 * Created on 2021/4/23 09
 *
 * @author xjl
 */
public class KSAdMgHolder {
    private static String AppId;
    public static boolean hadInit = false;

    public static void init(Context context, String app_id) {
        AppId = app_id;
        if (TextUtils.isEmpty(AppId)) {
            LogUtil.e("自定义中介：ks 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        KsAdSDK.init(context, new SdkConfig.Builder()
                .appId(AppId)
                .appName(context.getString(R.string.app_name))
                .showNotification(true)
                .debug(AdConfig.getInstance().isTest())
                .build());

        LogUtil.i("自定义中介：ks 初始化");
    }
}
