package com.agent.ad.oneway;

import android.content.Context;
import android.text.TextUtils;

import com.agent.ad.AdConfig;
import com.agent.ad.utils.LogUtil;

import mobi.oneway.export.Ad.OnewaySdk;

/**
 * Created on 2021/4/23 09
 *
 * @author xjl
 */
public class OWAdMgHolder {
    private static String AppId;
    public static boolean hadInit = false;

    public static void init(Context context, String app_id) {
        AppId = app_id;
        if (TextUtils.isEmpty(AppId)) {
            LogUtil.e("自定义中介：ow 初始化失败，app id 为空");
        } else {
            doInit(context);
        }
    }

    private static void doInit(Context context) {
        hadInit = true;
        OnewaySdk.configure(context, AppId);
        OnewaySdk.setDebugMode(AdConfig.getInstance().isTest());

        LogUtil.i("自定义中介：ow 初始化");
    }
}
